import { useState, useEffect, useCallback } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth, API } from "../App";
import { 
  LayoutDashboard, 
  Settings, 
  LogOut,
  ChevronRight,
  FolderOpen,
  FileText,
  ClipboardList,
  PanelLeftClose,
  PanelLeftOpen,
  ArrowUp,
  ArrowDown,
  Sparkles,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { toast } from "sonner";

const ProjectTree = ({ collapsed }) => {
  const location = useLocation();
  const { user } = useAuth();
  const [projects, setProjects] = useState([]);
  const [scripts, setScripts] = useState({});

  const canEdit = user?.role === "admin" || user?.role === "editor";

  const fetchProjectsAndScripts = useCallback(async () => {
    try {
      const res = await fetch(`${API}/projects`, { credentials: "include" });
      if (!res.ok) return;
      const projs = await res.json();
      setProjects(projs);

      const entries = await Promise.all(
        projs.map(async (p) => {
          try {
            const r = await fetch(`${API}/projects/${p.project_id}/scripts`, { credentials: "include" });
            return [p.project_id, r.ok ? await r.json() : []];
          } catch { return [p.project_id, []]; }
        })
      );
      setScripts(Object.fromEntries(entries));
    } catch (e) {
      console.error("Failed to fetch projects:", e);
    }
  }, []);

  useEffect(() => { fetchProjectsAndScripts(); }, [fetchProjectsAndScripts]);

  const moveProject = async (index, direction) => {
    const newProjects = [...projects];
    const swapIndex = index + direction;
    if (swapIndex < 0 || swapIndex >= newProjects.length) return;
    [newProjects[index], newProjects[swapIndex]] = [newProjects[swapIndex], newProjects[index]];
    setProjects(newProjects);
    try {
      await fetch(`${API}/projects/reorder`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ project_ids: newProjects.map(p => p.project_id) }),
      });
    } catch (e) {
      toast.error("Failed to save order");
      fetchProjectsAndScripts();
    }
  };

  const isProjectActive = (projectId) => location.pathname === `/projects/${projectId}`;
  const isScriptActive = (scriptId) => location.pathname === `/scripts/${scriptId}`;
  const isProjectTaskSheet = (projectId) => location.pathname === `/projects/${projectId}/tasks`;

  if (collapsed) {
    return (
      <div className="space-y-1 px-1" data-testid="project-tree-collapsed">
        {projects.map((proj) => (
          <Link
            key={proj.project_id}
            to={`/projects/${proj.project_id}`}
            className={`flex items-center justify-center w-9 h-9 rounded-md transition-colors ${
              isProjectActive(proj.project_id)
                ? "bg-slate-100 text-amber-600"
                : "text-slate-400 hover:text-amber-500 hover:bg-slate-50"
            }`}
            title={proj.name}
            data-testid={`nav-project-${proj.project_id}`}
          >
            <FolderOpen className="w-4 h-4" />
          </Link>
        ))}
      </div>
    );
  }

  if (projects.length === 0) {
    return (
      <p className="px-3 py-2 text-xs text-slate-400">No projects yet</p>
    );
  }

  return (
    <div className="space-y-0.5" data-testid="project-tree">
      {projects.map((proj, index) => (
        <div key={proj.project_id}>
          <div className="flex items-center group">
            <Link
              to={`/projects/${proj.project_id}`}
              className={`flex items-center gap-2 px-2 py-1.5 rounded-md text-sm transition-colors truncate flex-1 min-w-0 ${
                isProjectActive(proj.project_id)
                  ? "bg-slate-100 text-slate-900 font-medium"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
              }`}
              data-testid={`nav-project-${proj.project_id}`}
            >
              <FolderOpen className="w-4 h-4 text-amber-500 shrink-0" />
              <span className="truncate">{proj.name}</span>
            </Link>
            {canEdit && projects.length > 1 && (
              <div className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity flex">
                <button
                  onClick={(e) => { e.preventDefault(); moveProject(index, -1); }}
                  disabled={index === 0}
                  className="w-5 h-5 flex items-center justify-center text-slate-400 hover:text-slate-700 disabled:opacity-20"
                  data-testid={`move-project-up-${proj.project_id}`}
                >
                  <ArrowUp className="w-3 h-3" />
                </button>
                <button
                  onClick={(e) => { e.preventDefault(); moveProject(index, 1); }}
                  disabled={index === projects.length - 1}
                  className="w-5 h-5 flex items-center justify-center text-slate-400 hover:text-slate-700 disabled:opacity-20"
                  data-testid={`move-project-down-${proj.project_id}`}
                >
                  <ArrowDown className="w-3 h-3" />
                </button>
              </div>
            )}
          </div>

          <div className="ml-4 pl-3 border-l border-slate-200 space-y-0.5 mt-0.5 mb-1">
            <Link
              to={`/projects/${proj.project_id}/tasks`}
              className={`flex items-center gap-2 px-2 py-1.5 rounded-md text-sm transition-colors truncate ${
                isProjectTaskSheet(proj.project_id)
                  ? "bg-emerald-50 text-emerald-800 font-medium"
                  : "text-emerald-600 hover:text-emerald-800 hover:bg-emerald-50/50"
              }`}
              data-testid={`nav-tasks-${proj.project_id}`}
            >
              <ClipboardList className="w-3.5 h-3.5 shrink-0 text-emerald-500" />
              <span className="truncate">Task Sheet</span>
            </Link>
            {!scripts[proj.project_id] ? (
              <p className="text-xs text-slate-400 py-1 pl-2">Loading...</p>
            ) : scripts[proj.project_id].length === 0 ? (
              <p className="text-xs text-slate-400 py-1 pl-2">No scripts</p>
            ) : (
              scripts[proj.project_id].map((script) => (
                <Link
                  key={script.script_id}
                  to={`/scripts/${script.script_id}`}
                  className={`flex items-center gap-2 px-2 py-1.5 rounded-md text-sm transition-colors truncate ${
                    isScriptActive(script.script_id)
                      ? "bg-slate-100 text-slate-900 font-medium"
                      : "text-slate-500 hover:text-slate-900 hover:bg-slate-50"
                  }`}
                  data-testid={`nav-script-${script.script_id}`}
                >
                  <FileText className="w-3.5 h-3.5 shrink-0" />
                  <span className="truncate">{script.name}</span>
                </Link>
              ))
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export const Layout = ({ children, breadcrumbs = [] }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [collapsed, setCollapsed] = useState(() => {
    return localStorage.getItem("sidebar-collapsed") === "true";
  });

  const toggleSidebar = () => {
    const next = !collapsed;
    setCollapsed(next);
    localStorage.setItem("sidebar-collapsed", String(next));
  };

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  const isActive = (path) => {
    return location.pathname === path || location.pathname.startsWith(path + "/");
  };

  return (
    <div className="min-h-screen bg-white">
      <aside className={collapsed ? "sidebar sidebar-collapsed" : "sidebar"}>
        <div className="sidebar-header">
          <div className="flex items-center justify-between gap-2">
            {!collapsed && (
              <Link to="/" className="block min-w-0 flex-1">
                <h1 className="text-lg font-bold text-slate-900 truncate" style={{ fontFamily: 'Manrope, sans-serif' }}>
                  Dime Magic Box
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">YouTube Production Toolkit</p>
              </Link>
            )}
            <button
              onClick={toggleSidebar}
              className="flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
              data-testid="sidebar-toggle"
              title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            >
              {collapsed ? <PanelLeftOpen className="w-4 h-4" /> : <PanelLeftClose className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <nav className="sidebar-nav">
          <div>
            <Link
              to="/dashboard"
              className={`sidebar-link ${isActive("/dashboard") || isActive("/projects") || isActive("/scripts") || isActive("/tasks") ? "active" : ""}`}
              data-testid="nav-projects"
              title="Script to Task"
            >
              <ClipboardList className="w-4 h-4 shrink-0" strokeWidth={1.5} />
              {!collapsed && "Script to Task"}
            </Link>
            <Link
              to="/media"
              className={`sidebar-link ${isActive("/media") ? "active" : ""}`}
              data-testid="nav-media"
              title="Script to Media"
            >
              <Sparkles className="w-4 h-4 shrink-0" strokeWidth={1.5} />
              {!collapsed && "Script to Media"}
            </Link>
            <div className={collapsed ? "mt-1" : "mt-1 ml-2"}>
              <div className="sidebar-project-scroll">
                <ProjectTree collapsed={collapsed} />
              </div>
            </div>
          </div>
        </nav>

        <div className="mt-auto pt-4 border-t border-slate-200">
          {user?.role === "admin" && (
            <Link
              to="/admin"
              className={`sidebar-link mb-2 ${isActive("/admin") ? "active" : ""}`}
              data-testid="nav-admin"
              title="Admin Settings"
            >
              <Settings className="w-4 h-4 shrink-0" strokeWidth={1.5} />
              {!collapsed && "Admin Settings"}
            </Link>
          )}
          
          {collapsed ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="w-full flex items-center justify-center p-2 rounded-md hover:bg-slate-100 transition-colors" data-testid="user-menu-trigger">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.picture} alt={user?.name} />
                    <AvatarFallback className="bg-slate-200 text-slate-600 text-xs">
                      {user?.name?.charAt(0)?.toUpperCase() || "U"}
                    </AvatarFallback>
                  </Avatar>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent side="right" align="end" className="w-56">
                <div className="px-2 py-1.5">
                  <p className="text-sm font-medium">{user?.name}</p>
                  <p className="text-xs text-slate-500">{user?.email}</p>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-600 cursor-pointer" data-testid="logout-btn">
                  <LogOut className="w-4 h-4 mr-2" />
                  Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="w-full flex items-center gap-3 p-2 rounded-md hover:bg-slate-100 transition-colors" data-testid="user-menu-trigger">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.picture} alt={user?.name} />
                    <AvatarFallback className="bg-slate-200 text-slate-600 text-xs">
                      {user?.name?.charAt(0)?.toUpperCase() || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 text-left overflow-hidden">
                    <p className="text-sm font-medium text-slate-900 truncate">{user?.name}</p>
                    <p className="text-xs text-slate-500 capitalize">{user?.role}</p>
                  </div>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="px-2 py-1.5">
                  <p className="text-sm font-medium">{user?.name}</p>
                  <p className="text-xs text-slate-500">{user?.email}</p>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-red-600 cursor-pointer" data-testid="logout-btn">
                  <LogOut className="w-4 h-4 mr-2" />
                  Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </aside>

      <main className={collapsed ? "main-content main-content-collapsed" : "main-content"}>
        {breadcrumbs.length > 0 && (
          <div className="border-b border-slate-100 bg-slate-50/50 px-8 py-3">
            <nav className="flex items-center gap-2 text-sm">
              {breadcrumbs.map((crumb, index) => (
                <div key={index} className="flex items-center gap-2">
                  {index > 0 && <ChevronRight className="w-3 h-3 text-slate-400" />}
                  {crumb.href ? (
                    <Link 
                      to={crumb.href} 
                      className="text-slate-500 hover:text-slate-900 transition-colors"
                    >
                      {crumb.label}
                    </Link>
                  ) : (
                    <span className="text-slate-900 font-medium">{crumb.label}</span>
                  )}
                </div>
              ))}
            </nav>
          </div>
        )}

        <div className="p-8">
          {children}
        </div>
      </main>
    </div>
  );
};
