import React, { useEffect, useRef, useState, createContext, useContext, useCallback } from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate, useNavigate, useLocation, Link } from "react-router-dom";
import { Toaster, toast } from "sonner";

// Error Boundary to prevent white-screen crashes
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, info) {
    console.error("App crash caught by ErrorBoundary:", error, info);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#f8fafc", padding: 24 }}>
          <div style={{ textAlign: "center", maxWidth: 400 }}>
            <h2 style={{ fontSize: 20, fontWeight: 700, color: "#0f172a", marginBottom: 8, fontFamily: "Manrope, sans-serif" }}>
              Something went wrong
            </h2>
            <p style={{ fontSize: 14, color: "#64748b", marginBottom: 16 }}>
              The app encountered an unexpected error. Please try refreshing.
            </p>
            <button
              onClick={() => { this.setState({ hasError: false, error: null }); window.location.href = "/"; }}
              style={{ padding: "10px 24px", background: "#0f172a", color: "#fff", border: "none", borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: "pointer" }}
              data-testid="error-boundary-reset"
            >
              Go to Dashboard
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// API Configuration
const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Auth Context
const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

// Auth Provider
const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const checkAuth = useCallback(async () => {
    // CRITICAL: If returning from OAuth callback, skip the /me check.
    // AuthCallback will exchange the session_id and establish the session first.
    if (window.location.hash?.includes("session_id=")) {
      setLoading(false);
      return;
    }

    const tryAuth = async () => {
      const response = await fetch(`${API}/auth/me`, {
        credentials: "include",
      });
      if (response.ok) {
        const text = await response.text();
        try { return JSON.parse(text); } catch { return null; }
      }
      return null;
    };

    try {
      let userData = await tryAuth();
      // Retry once after a short delay (handles backend restart / transient failures)
      if (!userData) {
        await new Promise(r => setTimeout(r, 1500));
        userData = await tryAuth();
      }
      setUser(userData);
    } catch (error) {
      // Retry once on network error
      try {
        await new Promise(r => setTimeout(r, 1500));
        const userData = await tryAuth();
        setUser(userData);
      } catch {
        setUser(null);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  const login = (userData) => {
    setUser(userData);
  };

  const logout = async () => {
    try {
      await fetch(`${API}/auth/logout`, {
        method: "POST",
        credentials: "include",
      });
    } catch (error) {
      console.error("Logout error:", error);
    }
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, checkAuth }}>
      {children}
    </AuthContext.Provider>
  );
};

// Auth Callback Component
const AuthCallback = () => {
  const hasProcessed = useRef(false);
  const navigate = useNavigate();
  const { login } = useAuth();

  useEffect(() => {
    if (hasProcessed.current) return;
    hasProcessed.current = true;

    const processAuth = async () => {
      const hash = window.location.hash;
      const sessionId = hash.split("session_id=")[1]?.split("&")[0];

      if (!sessionId) {
        navigate("/login");
        return;
      }

      try {
        const response = await fetch(`${API}/auth/session`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ session_id: sessionId }),
          credentials: "include",
        });

        if (response.ok) {
          const text = await response.text();
          let userData;
          try { userData = JSON.parse(text); } catch { userData = null; }
          if (!userData) { navigate("/login"); return; }
          login(userData);
          
          // Seed default data for new admins
          if (userData.role === "admin") {
            try {
              await fetch(`${API}/seed`, {
                method: "POST",
                credentials: "include",
              });
            } catch (e) {
              // Ignore seed errors
            }
          }
          
          navigate("/", { replace: true, state: { user: userData } });
        } else {
          const text = await response.text();
          let error;
          try { error = JSON.parse(text); } catch { error = {}; }
          toast.error(error.detail || "Login failed");
          navigate("/login");
        }
      } catch (error) {
        toast.error("Authentication failed");
        navigate("/login");
      }
    };

    processAuth();
  }, [navigate, login]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="text-center">
        <div className="w-8 h-8 border-2 border-slate-900 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-slate-600">Authenticating...</p>
      </div>
    </div>
  );
};

// Protected Route
const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-8 h-8 border-2 border-slate-900 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
};

// Login Page
const LoginPage = () => {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [step, setStep] = useState("email"); // "email" | "password" | "setup"

  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);

  const handleEmailLogin = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const body = { email: email.trim().toLowerCase() };
      if (step === "password") body.password = password;

      const response = await fetch(`${API}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        credentials: "include",
      });

      // Read as text first to avoid "body already used" errors from browser extensions
      const text = await response.text();
      let data;
      try { data = JSON.parse(text); } catch { data = {}; }
      
      if (!response.ok) {
        setError(data.detail || "Login failed");
        setLoading(false);
        return;
      }

      if (data.needs_password_setup) {
        setStep("setup");
        setLoading(false);
        return;
      }
      
      if (data.needs_password) {
        setStep("password");
        setLoading(false);
        return;
      }
      
      if (!data.user_id) {
        setError("Unexpected response from server");
        setLoading(false);
        return;
      }

      login(data);
      
      if (data.role === "admin") {
        try {
          await fetch(`${API}/seed`, { method: "POST", credentials: "include" });
        } catch (e) {}
      }
      
      toast.success(`Welcome, ${data.name}!`);
      navigate("/", { replace: true });
    } catch (error) {
      console.error("Login error:", error);
      setError("Unable to connect to server. Please check your internet and try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleSetPassword = async (e) => {
    e.preventDefault();
    setError("");
    
    if (password.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    
    setLoading(true);
    try {
      const res = await fetch(`${API}/auth/set-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim().toLowerCase(), password }),
        credentials: "include",
      });
      
      const text = await res.text();
      let data;
      try { data = JSON.parse(text); } catch { data = {}; }
      
      if (res.ok) {
        toast.success("Password set! Now sign in with your password.");
        setPassword("");
        setConfirmPassword("");
        setStep("password");
      } else {
        setError(data.detail || "Failed to set password");
      }
    } catch (e) {
      setError("Failed to set password. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const goBack = () => {
    setStep("email");
    setPassword("");
    setConfirmPassword("");
    setError("");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <div className="w-full max-w-sm">
        <div className="bg-white rounded-lg border border-slate-200 p-8 shadow-sm">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-slate-900 mb-2" style={{ fontFamily: 'Manrope, sans-serif' }}>
              Dime Magic Box
            </h1>
            <p className="text-slate-500 text-sm">
              Your YouTube production toolkit
            </p>
          </div>
          
          <form onSubmit={step === "setup" ? handleSetPassword : handleEmailLogin}>
            <div className="space-y-4">
              {step === "email" && (
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@company.com"
                    required
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-md text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    data-testid="email-input"
                  />
                </div>
              )}

              {step === "password" && (
                <>
                  <div className="text-center">
                    <p className="text-sm text-slate-500 mb-1">Logging in as</p>
                    <p className="text-sm font-semibold text-slate-900">{email}</p>
                    <button type="button" onClick={goBack} className="text-xs text-blue-600 hover:underline mt-1" data-testid="change-email-btn">
                      Change email
                    </button>
                  </div>
                  <div>
                    <label htmlFor="password" className="block text-sm font-medium text-slate-700 mb-1">
                      Password
                    </label>
                    <input
                      type="password"
                      id="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your password"
                      required
                      autoFocus
                      className="w-full px-3 py-2.5 border border-slate-200 rounded-md text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                      data-testid="password-input"
                    />
                  </div>
                </>
              )}

              {step === "setup" && (
                <>
                  <div className="text-center">
                    <p className="text-sm text-slate-500 mb-1">Set up your admin password</p>
                    <p className="text-sm font-semibold text-slate-900">{email}</p>
                  </div>
                  <div>
                    <label htmlFor="new-password" className="block text-sm font-medium text-slate-700 mb-1">
                      Create Password
                    </label>
                    <input
                      type="password"
                      id="new-password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Min 6 characters"
                      required
                      autoFocus
                      minLength={6}
                      className="w-full px-3 py-2.5 border border-slate-200 rounded-md text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                      data-testid="new-password-input"
                    />
                  </div>
                  <div>
                    <label htmlFor="confirm-password" className="block text-sm font-medium text-slate-700 mb-1">
                      Confirm Password
                    </label>
                    <input
                      type="password"
                      id="confirm-password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Confirm your password"
                      required
                      minLength={6}
                      className="w-full px-3 py-2.5 border border-slate-200 rounded-md text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                      data-testid="confirm-password-input"
                    />
                  </div>
                </>
              )}
              
              {error && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-md">
                  <p className="text-sm text-red-600" data-testid="login-error">{error}</p>
                </div>
              )}
              
              <button
                type="submit"
                disabled={loading || (step === "email" && !email.trim()) || (step === "password" && !password) || (step === "setup" && (!password || !confirmPassword))}
                className="w-full bg-slate-900 text-white rounded-md px-4 py-2.5 font-medium hover:bg-slate-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                data-testid="login-btn"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : step === "setup" ? (
                  "Set Password & Continue"
                ) : step === "password" ? (
                  "Sign In"
                ) : (
                  "Continue"
                )}
              </button>
            </div>
          </form>
          
          <p className="text-xs text-slate-400 text-center mt-6">
            Only whitelisted emails can access this app
          </p>
        </div>
      </div>
    </div>
  );
};

// App Router
const AppRouter = () => {
  const location = useLocation();

  // Check URL fragment for session_id (legacy Google OAuth)
  if (location.hash?.includes("session_id=")) {
    return <AuthCallback />;
  }

  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/shared/:token" element={<PublicScriptPage />} />
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <DashboardPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/projects/:projectId"
        element={
          <ProtectedRoute>
            <ProjectPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/projects/:projectId/tasks"
        element={
          <ProtectedRoute>
            <TaskSheetPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/scripts/:scriptId"
        element={
          <ProtectedRoute>
            <ScriptEditorPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/tasks"
        element={
          <ProtectedRoute>
            <TaskSheetPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/media"
        element={
          <ProtectedRoute>
            <ScriptToMediaPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/admin"
        element={
          <ProtectedRoute>
            <AdminPage />
          </ProtectedRoute>
        }
      />
      <Route path="/" element={<ProtectedRoute><HomePage /></ProtectedRoute>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

// Import pages
import { DashboardPage } from "./pages/Dashboard";
import { ProjectPage } from "./pages/Project";
import { ScriptEditorPage } from "./pages/ScriptEditor";
import { TaskSheetPage } from "./pages/TaskSheet";
import { AdminPage } from "./pages/Admin";
import { PublicScriptPage } from "./pages/PublicScript";
import { ScriptToMediaPage } from "./pages/ScriptToMedia";
import { HomePage } from "./pages/Home";

function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <AuthProvider>
          <Toaster position="top-right" richColors />
          <AppRouter />
        </AuthProvider>
      </BrowserRouter>
    </ErrorBoundary>
  );
}

export default App;

// Export API and hooks for use in other components
export { API, BACKEND_URL };
