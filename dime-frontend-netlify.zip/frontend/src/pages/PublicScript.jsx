import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { API } from "../App";
import { Lock, Paperclip, X, ExternalLink, Image, Link as LinkIcon, Volume2, FileText, Download } from "lucide-react";
import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Highlight from "@tiptap/extension-highlight";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../components/ui/dialog";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

export const PublicScriptPage = () => {
  const { token } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedTask, setSelectedTask] = useState(null);
  const [previewImg, setPreviewImg] = useState(null);

  const editor = useEditor({
    extensions: [
      StarterKit,
      Highlight.configure({ multicolor: true }),
    ],
    content: "",
    editable: false,
  });

  useEffect(() => {
    const fetchPublicData = async () => {
      try {
        const res = await fetch(`${API}/public/script/${token}`);
        if (res.ok) {
          setData(await res.json());
        } else {
          setError("This share link is invalid or has been revoked.");
        }
      } catch (e) {
        setError("Failed to load shared script.");
      } finally {
        setLoading(false);
      }
    };
    fetchPublicData();
  }, [token]);

  useEffect(() => {
    if (data && editor) {
      editor.commands.setContent(data.script.content || "<p></p>");
    }
  }, [data, editor]);

  // Handle clicks on highlighted text
  useEffect(() => {
    if (!editor || !data) return;

    const handleEditorClick = (event) => {
      const target = event.target;
      if (target.tagName === "MARK" || target.closest("mark")) {
        const markEl = target.tagName === "MARK" ? target : target.closest("mark");
        const markText = markEl.textContent.trim();
        const task = data.tasks.find(
          (t) => t.selected_text.trim() === markText || markText.includes(t.selected_text.trim()) || t.selected_text.trim().includes(markText)
        );
        if (task) {
          event.preventDefault();
          setSelectedTask(task);
        }
      }
    };

    const editorElement = editor.view.dom;
    editorElement.addEventListener("click", handleEditorClick);
    return () => editorElement.removeEventListener("click", handleEditorClick);
  }, [editor, data]);

  const getGdriveFileId = (url) => {
    if (!url) return null;
    const match = url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
    return match ? match[1] : null;
  };

  const getAttachmentUrl = (att, variant = "default") => {
    if (att.type === "link") return att.url;
    const gid = att.gdrive_file_id || getGdriveFileId(att.url);
    if (gid) {
      if (variant === "thumbnail") return `https://drive.google.com/thumbnail?id=${gid}&sz=w400`;
      if (variant === "full") return `https://drive.google.com/thumbnail?id=${gid}&sz=w1200`;
      if (variant === "download") return `${API}/drive/stream/${gid}?download=1`;
      if (variant === "audio") return `${API}/drive/stream/${gid}`;
      if (variant === "preview") return `https://drive.google.com/file/d/${gid}/preview`;
      return `${API}/drive/stream/${gid}`;
    }
    if (att.url.startsWith("http")) return att.url;
    return `${BACKEND_URL}${att.url}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-8 h-8 border-2 border-slate-900 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <Lock className="w-12 h-12 text-slate-300 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-slate-900 mb-2">Access Denied</h2>
          <p className="text-slate-500" data-testid="public-script-error">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-slate-900" style={{ fontFamily: "Manrope, sans-serif" }} data-testid="public-script-title">
              {data.script.name}
            </h1>
            <p className="text-sm text-slate-500 mt-0.5">Shared view (read-only)</p>
          </div>
          <span className="text-xs text-slate-400 bg-slate-100 px-2 py-1 rounded">Dime Script Flow Manager</span>
        </div>
      </header>

      <div className="max-w-4xl mx-auto p-6">
        <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
          <div className="p-1 border-b border-slate-100 bg-slate-50">
            <p className="text-xs text-slate-400 px-3 py-1">Click on any highlighted text to view task details</p>
          </div>
          <div className="p-6">
            <EditorContent editor={editor} className="tiptap-editor prose max-w-none public-script-editor" />
          </div>
        </div>

        {/* Task list summary */}
        {data.tasks.length > 0 && (
          <div className="mt-6">
            <h3 className="text-sm font-semibold text-slate-700 mb-3">{data.tasks.length} Task{data.tasks.length !== 1 ? "s" : ""}</h3>
            <div className="space-y-2">
              {data.tasks.map((task, index) => (
                <button
                  key={task.task_id}
                  onClick={() => setSelectedTask(task)}
                  className="w-full text-left p-3 bg-white border border-slate-200 rounded-lg hover:border-slate-300 transition-colors flex items-center gap-3"
                  data-testid={`public-task-item-${task.task_id}`}
                >
                  <span className="flex-shrink-0 w-6 h-6 rounded-full bg-slate-100 text-slate-500 text-xs font-semibold flex items-center justify-center">
                    {index + 1}
                  </span>
                  <span
                    className="px-2 py-0.5 rounded text-xs font-medium flex-shrink-0"
                    style={{
                      backgroundColor: task.category_bg_color || "#F1F5F9",
                      color: task.category_text_color || "#374151",
                      border: `1px solid ${task.category_border_color || "#E2E8F0"}`,
                    }}
                  >
                    {task.category_name || "Unknown"}
                  </span>
                  <span className="text-sm text-slate-700 truncate flex-1">
                    {task.selected_text.slice(0, 80)}{task.selected_text.length > 80 ? "..." : ""}
                  </span>
                  {task.attachments_count > 0 && (
                    <span className="flex items-center gap-1 text-xs text-slate-400">
                      <Paperclip className="w-3 h-3" /> {task.attachments_count}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Task Detail Dialog */}
      <Dialog open={!!selectedTask} onOpenChange={() => setSelectedTask(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto" data-testid="public-task-dialog">
          <DialogHeader>
            <DialogTitle>Task Details</DialogTitle>
          </DialogHeader>
          {selectedTask && (
            <div className="space-y-5">
              {/* Highlight text */}
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <p className="text-xs text-amber-600 font-medium mb-1">Highlighted Text</p>
                <p className="text-sm text-slate-800" data-testid="public-task-selected-text">"{selectedTask.selected_text}"</p>
              </div>

              {/* Category */}
              <div>
                <p className="text-xs text-slate-500 mb-1">Category</p>
                <span
                  className="px-2 py-0.5 rounded text-xs font-medium"
                  style={{
                    backgroundColor: selectedTask.category_bg_color || "#F1F5F9",
                    color: selectedTask.category_text_color || "#374151",
                    border: `1px solid ${selectedTask.category_border_color || "#E2E8F0"}`,
                  }}
                  data-testid="public-task-category"
                >
                  {selectedTask.category_name || "-"}
                </span>
              </div>

              {/* Description */}
              {selectedTask.description && (
                <div>
                  <p className="text-xs text-slate-500 mb-1">Description</p>
                  <p className="text-sm text-slate-700 bg-slate-50 p-3 rounded border border-slate-100" data-testid="public-task-description">
                    {selectedTask.description}
                  </p>
                </div>
              )}

              {/* Attachments */}
              <div>
                <p className="text-xs text-slate-500 mb-2">Attachments ({selectedTask.attachments?.length || 0})</p>
                {(!selectedTask.attachments || selectedTask.attachments.length === 0) ? (
                  <p className="text-sm text-slate-400 text-center py-4 bg-slate-50 rounded border border-slate-100">No attachments</p>
                ) : (
                  <div className="space-y-3">
                    {selectedTask.attachments.map((att) => (
                      <div key={att.attachment_id} className="border border-slate-200 rounded-lg overflow-hidden" data-testid={`public-attachment-${att.attachment_id}`}>
                        {att.type === "image" ? (
                          <div>
                            <div onClick={() => setPreviewImg(att)} className="block cursor-pointer">
                              <img src={getAttachmentUrl(att, "thumbnail")} alt={att.filename || "Image"} className="w-full max-h-64 object-contain bg-slate-100 hover:opacity-90 transition-opacity" />
                            </div>
                            <div className="flex items-center justify-between p-2 bg-white border-t border-slate-100">
                              <div className="flex items-center gap-2 min-w-0">
                                <Image className="w-4 h-4 text-slate-400 shrink-0" />
                                <span className="text-xs text-slate-600 truncate">{att.filename || "Image"}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <button onClick={() => setPreviewImg(att)} className="text-slate-500 hover:text-slate-700" title="Preview">
                                  <ExternalLink className="w-4 h-4" />
                                </button>
                                <a href={getAttachmentUrl(att, "download")} target="_blank" rel="noreferrer" className="text-blue-600 hover:text-blue-800" title="Download">
                                  <Download className="w-4 h-4" />
                                </a>
                              </div>
                            </div>
                          </div>
                        ) : att.type === "audio" ? (
                          <div className="p-3 bg-white">
                            <div className="flex items-center gap-2 mb-2">
                              <Volume2 className="w-4 h-4 text-slate-400 shrink-0" />
                              <span className="text-xs text-slate-600 truncate flex-1">{att.filename || "Audio"}</span>
                              <a href={getAttachmentUrl(att, "download")} target="_blank" rel="noreferrer" className="text-blue-600 hover:text-blue-800" title="Download">
                                <Download className="w-4 h-4" />
                              </a>
                            </div>
                            <audio controls src={getAttachmentUrl(att, "audio")} className="w-full" />
                          </div>
                        ) : att.type === "link" ? (
                          <div className="flex items-center gap-3 p-3 bg-white">
                            <LinkIcon className="w-4 h-4 text-slate-400 shrink-0" />
                            <a href={att.url} target="_blank" rel="noreferrer" className="text-sm text-blue-600 hover:underline truncate flex-1">
                              {att.url}
                            </a>
                            <ExternalLink className="w-4 h-4 text-blue-400 shrink-0" />
                          </div>
                        ) : (
                          <div className="flex items-center justify-between p-3 bg-white">
                            <div className="flex items-center gap-2 min-w-0">
                              <FileText className="w-4 h-4 text-slate-400 shrink-0" />
                              <span className="text-xs text-slate-600 truncate">{att.filename || "File"}</span>
                            </div>
                            <a href={getAttachmentUrl(att, "download")} target="_blank" rel="noreferrer" className="text-blue-600 hover:text-blue-800" title="Download">
                              <Download className="w-4 h-4" />
                            </a>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Image Preview Modal */}
      <Dialog open={!!previewImg} onOpenChange={() => setPreviewImg(null)}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden bg-black/95 border-slate-700" data-testid="public-image-preview">
          <DialogHeader className="sr-only"><DialogTitle>Image Preview</DialogTitle></DialogHeader>
          {previewImg && (
            <div className="relative">
              <button onClick={() => setPreviewImg(null)} className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black/80">
                <X className="w-4 h-4" />
              </button>
              <img src={getAttachmentUrl(previewImg, "full")} alt={previewImg.filename || "Image"} className="w-full max-h-[75vh] object-contain" />
              <div className="p-4 bg-slate-900 flex items-center justify-between">
                <span className="text-sm text-slate-300">{previewImg.filename || "Image"}</span>
                <a href={getAttachmentUrl(previewImg, "download")} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 px-4 py-2 bg-white text-slate-900 rounded-lg text-sm font-medium hover:bg-slate-100">
                  <Download className="w-4 h-4" />Download
                </a>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PublicScriptPage;
