import { useState, useEffect, useRef, useCallback } from "react";
import { useParams, useNavigate, useSearchParams } from "react-router-dom";
import { Layout } from "../components/Layout";
import { API, useAuth } from "../App";
import { toast } from "sonner";
import { 
  ArrowLeft, 
  Bold, 
  Italic, 
  List, 
  ListOrdered, 
  Quote,
  Heading1,
  Heading2,
  X,
  Save,
  Paperclip,
  Link as LinkIcon,
  Image,
  Upload,
  Trash2,
  ExternalLink,
  Navigation,
  CheckSquare,
  Square,
  Mic,
  MicOff,
  Volume2,
  Copy,
  Check,
  Download,
  Lock,
  Undo2,
  Redo2
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Label } from "../components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "../components/ui/alert-dialog";
import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Highlight from "@tiptap/extension-highlight";

export const ScriptEditorPage = () => {
  const { scriptId } = useParams();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { user } = useAuth();
  const [script, setScript] = useState(null);
  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tasks, setTasks] = useState([]);
  const [categories, setCategories] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [teamMembers, setTeamMembers] = useState([]);
  const [selectedTask, setSelectedTask] = useState(null);
  const [panelOpen, setPanelOpen] = useState(false);
  const [selectionPopup, setSelectionPopup] = useState(null);
  const [saving, setSaving] = useState(false);
  const [attachments, setAttachments] = useState([]);
  const [newAttachment, setNewAttachment] = useState({ type: "link", url: "" });
  const [selectedTaskIds, setSelectedTaskIds] = useState(new Set());
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deleteTaskConfirmOpen, setDeleteTaskConfirmOpen] = useState(false);
  const [workflowStages, setWorkflowStages] = useState([]);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const recordingTimerRef = useRef(null);
  const [shareToken, setShareToken] = useState(null);
  const [copied, setCopied] = useState(false);
  const [locks, setLocks] = useState([]);
  const lockPollRef = useRef(null);
  const lockRenewRef = useRef(null);
  const currentLockRef = useRef(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [pendingNavigation, setPendingNavigation] = useState(null);
  const hasUnsavedRef = useRef(false);
  const [scriptLock, setScriptLock] = useState(null); // { user_id, locked_by_name } or null
  const [isLockedByMe, setIsLockedByMe] = useState(false);
  const scriptLockPollRef = useRef(null);
  const scriptLockRenewRef = useRef(null);

  const canEdit = user?.role === "admin" || user?.role === "editor";

  // Keep ref in sync for use in event handlers
  useEffect(() => { hasUnsavedRef.current = hasUnsavedChanges; }, [hasUnsavedChanges]);

  // Safe navigate: shows dialog if unsaved changes
  const safeNavigate = useCallback((to) => {
    if (hasUnsavedRef.current) {
      setPendingNavigation(to);
    } else {
      navigate(to);
    }
  }, [navigate]);

  // Warn on browser tab close / refresh
  useEffect(() => {
    const handler = (e) => {
      if (hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [hasUnsavedChanges]);

  // Intercept browser back/forward button
  useEffect(() => {
    if (!hasUnsavedChanges) return;
    const handlePop = (e) => {
      if (hasUnsavedRef.current) {
        // Push the current state back to cancel the back navigation
        window.history.pushState(null, "", window.location.href);
        setPendingNavigation("__back__");
      }
    };
    window.history.pushState(null, "", window.location.href);
    window.addEventListener("popstate", handlePop);
    return () => window.removeEventListener("popstate", handlePop);
  }, [hasUnsavedChanges]);

  const getGdriveFileId = (url) => {
    if (!url) return null;
    const match = url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
    return match ? match[1] : null;
  };

  const getAttachmentUrl = (att, variant = "default") => {
    if (att.type === "link") return att.url;
    const gid = att.gdrive_file_id || getGdriveFileId(att.url);
    if (gid) {
      if (variant === "thumbnail") return `https://drive.google.com/thumbnail?id=${gid}&sz=w400`;
      if (variant === "full") return `${API}/drive/stream/${gid}`;
      if (variant === "download") return `https://drive.google.com/uc?id=${gid}&export=download`;
      if (variant === "audio") return `${API}/drive/stream/${gid}`;
      return `${API}/drive/stream/${gid}`;
    }
    if (att.url.startsWith("http")) return att.url;
    return `${process.env.REACT_APP_BACKEND_URL}${att.url}`;
  };
  const editorContainerRef = useRef(null);
  const isLoadingContentRef = useRef(false);

  // Function to find task by text position in editor
  const findTaskAtPosition = (pos) => {
    // Find a task whose highlight range contains this position
    return tasks.find(task => 
      pos >= task.highlight_start && pos <= task.highlight_end
    );
  };

  // Function to scroll to task highlight in editor using DOM search
  const scrollToTaskHighlight = (task) => {
    if (!editor || !task) return;
    
    try {
      const editorDom = editor.view.dom;
      const marks = editorDom.querySelectorAll('mark');
      
      // Find the mark element whose text matches the task's selected text
      let targetMark = null;
      for (const mark of marks) {
        if (mark.textContent.trim() === task.selected_text.trim()) {
          targetMark = mark;
          break;
        }
      }
      
      // Fallback: partial match if exact match not found
      if (!targetMark) {
        for (const mark of marks) {
          if (mark.textContent.includes(task.selected_text) || task.selected_text.includes(mark.textContent)) {
            targetMark = mark;
            break;
          }
        }
      }
      
      if (targetMark) {
        // Scroll the mark into view
        targetMark.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Add a flash animation to highlight the target
        targetMark.classList.add('highlight-flash');
        setTimeout(() => targetMark.classList.remove('highlight-flash'), 1500);
      } else {
        // Last resort: try the stored position
        try {
          const view = editor.view;
          const coords = view.coordsAtPos(Math.min(task.highlight_start, editor.state.doc.content.size - 1));
          if (editorContainerRef.current) {
            const containerRect = editorContainerRef.current.getBoundingClientRect();
            const scrollTop = coords.top - containerRect.top - 100;
            editorContainerRef.current.scrollTo({
              top: editorContainerRef.current.scrollTop + scrollTop,
              behavior: 'smooth'
            });
          }
        } catch (posErr) {
          console.warn("Could not scroll to stored position:", posErr);
        }
      }
    } catch (e) {
      console.error("Error scrolling to highlight:", e);
    }
  };

  // Initialize Tiptap editor — immediatelyRender: false prevents React 19 flushSync crash
  const editor = useEditor({
    extensions: [
      StarterKit,
      Highlight.configure({ multicolor: true }),
    ],
    content: "",
    editable: canEdit && isLockedByMe,
    immediatelyRender: false,
    onUpdate: ({ editor }) => {
      if (isLoadingContentRef.current) return;
      setHasUnsavedChanges(true);
    },
    onSelectionUpdate: ({ editor }) => {
      handleTextSelection(editor);
    },
  });

  // Ctrl+S keyboard shortcut to save
  useEffect(() => {
    const handler = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "s") {
        e.preventDefault();
        if (hasUnsavedRef.current && editor && canEdit) {
          saveContent(editor.getHTML());
        }
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [editor, canEdit]);


  // Handle clicks on highlighted text in editor
  useEffect(() => {
    if (!editor) return;
    
    const handleEditorClick = (event) => {
      // Check if click is on a highlight mark
      const target = event.target;
      if (target.tagName === 'MARK' || target.closest('mark')) {
        const view = editor.view;
        const pos = view.posAtCoords({ left: event.clientX, top: event.clientY });
        
        if (pos) {
          const task = findTaskAtPosition(pos.pos);
          if (task) {
            event.preventDefault();
            event.stopPropagation();
            openTaskPanel(task);
            setSelectionPopup(null); // Close any open popup
          }
        }
      } else {
        // Clicked outside of a highlight, close popup if no text is selected
        setTimeout(() => {
          const selection = window.getSelection();
          if (!selection || selection.isCollapsed) {
            setSelectionPopup(null);
          }
        }, 100);
      }
    };
    
    // Add click listener to editor DOM
    const editorElement = editor.view.dom;
    editorElement.addEventListener('click', handleEditorClick);
    
    return () => {
      editorElement.removeEventListener('click', handleEditorClick);
    };
  }, [editor, tasks]);

  // Handle ?highlight=task_id from TaskSheet navigation
  useEffect(() => {
    const highlightTaskId = searchParams.get("highlight");
    if (!highlightTaskId || !editor || tasks.length === 0) return;
    const task = tasks.find(t => t.task_id === highlightTaskId);
    if (task) {
      // Small delay to ensure editor content is fully rendered
      setTimeout(() => {
        setSelectedTask(task);
        setPanelOpen(true);
        scrollToTaskHighlight(task);
        // Clear the query param so it doesn't re-trigger
        setSearchParams({}, { replace: true });
      }, 500);
    }
  }, [editor, tasks, searchParams]);

  useEffect(() => {
    // Reset state when switching scripts
    isLoadingContentRef.current = true;
    setHasUnsavedChanges(false);
    setTasks([]);
    setSelectedTask(null);
    setPanelOpen(false);
    setSelectionPopup(null);
    setScriptLock(null);
    setIsLockedByMe(false);
    
    fetchScript();
    fetchCategories();
    fetchStatuses();
    fetchTeamMembers();
    fetchWorkflowStages();
    fetchShareLink();
  }, [scriptId]);

  // --- Script-level locking ---

  // Acquire lock on mount, poll status, renew, release on unmount
  useEffect(() => {
    if (!scriptId || !user) return;
    let cancelled = false;

    const initLock = async () => {
      if (canEdit) {
        try {
          const res = await fetch(`${API}/scripts/${scriptId}/lock`, {
            method: "POST",
            credentials: "include",
          });
          if (cancelled) return;
          if (res.ok) {
            setIsLockedByMe(true);
            setScriptLock(null);
          } else {
            // Lock denied — fetch status to get locker info
            const statusRes = await fetch(`${API}/scripts/${scriptId}/lock-status`, {
              credentials: "include",
            });
            if (cancelled) return;
            if (statusRes.ok) {
              const data = await statusRes.json();
              if (data.locked && data.locked_by?.user_id !== user.user_id) {
                setScriptLock(data.locked_by);
                setIsLockedByMe(false);
              }
            }
          }
        } catch {}
      } else {
        // Viewer — just check status
        try {
          const statusRes = await fetch(`${API}/scripts/${scriptId}/lock-status`, {
            credentials: "include",
          });
          if (cancelled) return;
          if (statusRes.ok) {
            const data = await statusRes.json();
            if (data.locked) {
              setScriptLock(data.locked_by);
              setIsLockedByMe(false);
            }
          }
        } catch {}
      }
    };

    initLock();

    // Poll lock status every 15 seconds
    scriptLockPollRef.current = setInterval(async () => {
      try {
        const res = await fetch(`${API}/scripts/${scriptId}/lock-status`, {
          credentials: "include",
        });
        if (cancelled) return;
        if (res.ok) {
          const data = await res.json();
          if (data.locked) {
            if (data.locked_by?.user_id === user?.user_id) {
              setIsLockedByMe(true);
              setScriptLock(null);
            } else {
              setIsLockedByMe(false);
              setScriptLock(data.locked_by);
            }
          } else {
            setScriptLock(null);
            if (canEdit && !cancelled) {
              const lockRes = await fetch(`${API}/scripts/${scriptId}/lock`, {
                method: "POST",
                credentials: "include",
              });
              if (!cancelled && lockRes.ok) {
                setIsLockedByMe(true);
              }
            }
          }
        }
      } catch {}
    }, 15000);

    // Renew own lock every 2 minutes
    scriptLockRenewRef.current = setInterval(async () => {
      try {
        await fetch(`${API}/scripts/${scriptId}/lock`, {
          method: "POST",
          credentials: "include",
        });
      } catch {}
    }, 120000);

    return () => {
      cancelled = true;
      clearInterval(scriptLockPollRef.current);
      clearInterval(scriptLockRenewRef.current);
      if (canEdit) {
        fetch(`${API}/scripts/${scriptId}/unlock`, {
          method: "DELETE",
          credentials: "include",
        }).catch(() => {});
      }
    };
  }, [scriptId, user]);

  // Release lock on browser tab close
  useEffect(() => {
    const handleUnload = () => {
      if (isLockedByMe) {
        navigator.sendBeacon(
          `${API}/scripts/${scriptId}/unlock-beacon`,
          new Blob([JSON.stringify({ user_id: user?.user_id })], { type: "application/json" })
        );
      }
    };
    window.addEventListener("beforeunload", handleUnload);
    return () => window.removeEventListener("beforeunload", handleUnload);
  }, [isLockedByMe, scriptId, user]);

  // Update editor editable state based on lock — defer to avoid flushSync
  useEffect(() => {
    if (editor) {
      queueMicrotask(() => editor.setEditable(canEdit && isLockedByMe));
    }
  }, [editor, canEdit, isLockedByMe]);

  // Close selection popup when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      // Don't close if clicking on the popup itself
      if (event.target.closest('.selection-popup')) return;
      // Don't close if clicking on category buttons
      if (event.target.closest('[data-testid^="category-btn"]')) return;
      
      // Close popup if clicking outside editor or on editor without selection
      const selection = window.getSelection();
      if (!selection || selection.isCollapsed || selection.toString().trim().length < 2) {
        setSelectionPopup(null);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (script && editor) {
      isLoadingContentRef.current = true;
      // Defer setContent to avoid React 19 flushSync crash in Tiptap
      queueMicrotask(() => {
        editor.commands.setContent(script.content || "<p>Start writing your script here...</p>");
        setTimeout(() => { isLoadingContentRef.current = false; }, 500);
      });
      fetchTasks();
    }
  }, [script, editor]);

  const fetchScript = async () => {
    try {
      const response = await fetch(`${API}/scripts/${scriptId}`, {
        credentials: "include",
      });
      if (response.ok) {
        const data = await response.json();
        setScript(data);
        // Fetch project
        const projResponse = await fetch(`${API}/projects/${data.project_id}`, {
          credentials: "include",
        });
        if (projResponse.ok) {
          setProject(await projResponse.json());
        }
      } else {
        toast.error("Script not found");
        navigate("/dashboard");
      }
    } catch (error) {
      toast.error("Failed to fetch script");
    } finally {
      setLoading(false);
    }
  };

  const fetchTasks = async () => {
    try {
      const response = await fetch(`${API}/scripts/${scriptId}/tasks`, {
        credentials: "include",
      });
      if (response.ok) {
        const data = await response.json();
        setTasks(data);
      }
    } catch (error) {
      console.error("Failed to fetch tasks:", error);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await fetch(`${API}/categories`, { credentials: "include" });
      if (response.ok) setCategories(await response.json());
    } catch (error) {
      console.error("Failed to fetch categories:", error);
    }
  };

  const fetchStatuses = async () => {
    try {
      const response = await fetch(`${API}/statuses`, { credentials: "include" });
      if (response.ok) setStatuses(await response.json());
    } catch (error) {
      console.error("Failed to fetch statuses:", error);
    }
  };

  const fetchTeamMembers = async () => {
    try {
      const response = await fetch(`${API}/team-members`, { credentials: "include" });
      if (response.ok) setTeamMembers(await response.json());
    } catch (error) {
      console.error("Failed to fetch team members:", error);
    }
  };

  const fetchAttachments = async (taskId) => {
    try {
      const response = await fetch(`${API}/tasks/${taskId}/attachments`, {
        credentials: "include",
      });
      if (response.ok) {
        setAttachments(await response.json());
      }
    } catch (error) {
      console.error("Failed to fetch attachments:", error);
    }
  };

  const saveContent = async (content) => {
    if (!canEdit) return;
    setSaving(true);
    try {
      await fetch(`${API}/scripts/${scriptId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ content }),
      });
      setHasUnsavedChanges(false);
      toast.success("Script saved");
    } catch (error) {
      console.error("Failed to save:", error);
      toast.error("Failed to save script");
    } finally {
      setSaving(false);
    }
  };

  const handleTextSelection = (editor) => {
    if (!canEdit || !isLockedByMe) return;
    
    const { from, to } = editor.state.selection;
    const selectedText = editor.state.doc.textBetween(from, to, " ");
    
    // Only show popup if there's actual selected text (minimum 2 characters)
    if (selectedText.trim().length >= 2 && from !== to) {
      // Check if ANY part of the selection contains highlighted text
      let hasHighlight = false;
      editor.state.doc.nodesBetween(from, to, (node, pos) => {
        if (node.marks) {
          for (const mark of node.marks) {
            if (mark.type.name === 'highlight') {
              hasHighlight = true;
            }
          }
        }
      });
      
      // Get selection coordinates - use END position to place popup to the right
      const view = editor.view;
      const endCoords = view.coordsAtPos(to);
      
      setSelectionPopup({
        text: selectedText,
        from,
        to,
        x: endCoords.right + 10,
        y: endCoords.top,
        isHighlighted: hasHighlight,
      });
    } else {
      setSelectionPopup(null);
    }
  };

  const createTaskFromSelection = async (categoryId) => {
    if (!selectionPopup || !categoryId || !isLockedByMe) return;
    if (selectionPopup.isHighlighted) {
      toast.error("This text is already highlighted.");
      return;
    }
    
    const category = categories.find(c => c.category_id === categoryId);
    if (!category) return;

    try {
      const response = await fetch(`${API}/tasks`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          script_id: scriptId,
          selected_text: selectionPopup.text,
          highlight_start: selectionPopup.from,
          highlight_end: selectionPopup.to,
          category_id: categoryId,
        }),
      });

      if (response.ok) {
        const newTask = await response.json();
        toast.success("Task created");
        setSelectionPopup(null);
        
        // Apply highlight to editor
        if (editor) {
          editor.chain()
            .focus()
            .setTextSelection({ from: selectionPopup.from, to: selectionPopup.to })
            .setHighlight({ color: category.bg_color })
            .run();
          saveContent(editor.getHTML());
        }
        
        fetchTasks();
        openTaskPanel(newTask);
      } else {
        const error = await response.json();
        toast.error(error.detail || "Failed to create task");
      }
    } catch (error) {
      toast.error("Failed to create task");
    }
  };

  // Remove all highlights in the selection and delete associated tasks
  const removeHighlight = async () => {
    if (!selectionPopup || !editor || !isLockedByMe) return;
    
    // Collect highlighted text segments within the selection
    const highlightedTexts = new Set();
    editor.state.doc.nodesBetween(selectionPopup.from, selectionPopup.to, (node) => {
      if (node.isText && node.marks.some(m => m.type.name === 'highlight')) {
        highlightedTexts.add(node.text);
      }
    });
    
    // Find all tasks whose selected_text matches any highlighted segment
    const matchedTasks = tasks.filter(t => 
      highlightedTexts.has(t.selected_text) || 
      [...highlightedTexts].some(ht => ht.includes(t.selected_text) || t.selected_text.includes(ht))
    );
    
    try {
      // Remove highlights from editor across the entire selection
      editor.chain()
        .focus()
        .setTextSelection({ from: selectionPopup.from, to: selectionPopup.to })
        .unsetHighlight()
        .run();
      saveContent(editor.getHTML());
      
      // Delete all matched tasks
      if (matchedTasks.length > 0) {
        await Promise.all(
          matchedTasks.map(task =>
            fetch(`${API}/tasks/${task.task_id}`, {
              method: "DELETE",
              credentials: "include",
            })
          )
        );
        toast.success(`${matchedTasks.length} highlight(s) and task(s) removed`);
        fetchTasks();
      } else {
        // No matching tasks — just clean up highlight from backend
        await fetch(`${API}/scripts/${scriptId}/remove-highlight`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({ selected_text: selectionPopup.text }),
        });
        toast.success("Highlight removed");
      }
      
      setSelectionPopup(null);
    } catch (error) {
      toast.error("Failed to remove highlight");
    }
  };

  // ---- Highlight Locking ----
  const fetchLocks = useCallback(async () => {
    try {
      const res = await fetch(`${API}/scripts/${scriptId}/locks`, { credentials: "include" });
      if (res.ok) setLocks(await res.json());
    } catch { /* ignore */ }
  }, [scriptId]);

  const acquireLock = async (taskId) => {
    try {
      const res = await fetch(`${API}/tasks/${taskId}/lock`, { method: "POST", credentials: "include" });
      if (res.ok) {
        currentLockRef.current = taskId;
        // Auto-renew every 4 minutes
        lockRenewRef.current = setInterval(async () => {
          await fetch(`${API}/tasks/${taskId}/lock/renew`, { method: "POST", credentials: "include" }).catch(() => {});
        }, 4 * 60 * 1000);
        return true;
      }
      const data = await res.json();
      if (res.status === 409) toast.error(data.detail || "Highlight is locked");
      return false;
    } catch { return false; }
  };

  const releaseLock = async (taskId) => {
    if (!taskId) return;
    if (lockRenewRef.current) { clearInterval(lockRenewRef.current); lockRenewRef.current = null; }
    currentLockRef.current = null;
    await fetch(`${API}/tasks/${taskId}/lock`, { method: "DELETE", credentials: "include" }).catch(() => {});
    fetchLocks();
  };

  // Poll locks every 8 seconds
  useEffect(() => {
    if (!scriptId) return;
    fetchLocks();
    lockPollRef.current = setInterval(fetchLocks, 8000);
    return () => { if (lockPollRef.current) clearInterval(lockPollRef.current); };
  }, [scriptId, fetchLocks]);

  // Cleanup lock on unmount
  useEffect(() => {
    return () => {
      if (currentLockRef.current) {
        fetch(`${API}/tasks/${currentLockRef.current}/lock`, { method: "DELETE", credentials: "include" }).catch(() => {});
      }
      if (lockRenewRef.current) clearInterval(lockRenewRef.current);
    };
  }, []);

  const getLockForTask = (taskId) => locks.find(l => l.task_id === taskId && l.user_id !== user?.user_id);

  const openTaskPanel = async (task, scrollToHighlight = false) => {
    // Release previous lock if switching tasks
    if (currentLockRef.current && currentLockRef.current !== task.task_id) {
      await releaseLock(currentLockRef.current);
    }

    // Try to acquire lock
    if (canEdit) {
      const locked = await acquireLock(task.task_id);
      if (!locked) {
        // Still open panel in read-only mode
      }
    }

    setSelectedTask(task);
    setPanelOpen(true);
    await fetchAttachments(task.task_id);
    fetchLocks();

    if (scrollToHighlight) {
      setTimeout(() => scrollToTaskHighlight(task), 100);
    }
  };

  const closeTaskPanel = async () => {
    if (currentLockRef.current) {
      await releaseLock(currentLockRef.current);
    }
    setPanelOpen(false);
    setSelectedTask(null);
    setAttachments([]);
  };

  const updateTask = async (updates) => {
    if (!selectedTask) return;
    
    try {
      const response = await fetch(`${API}/tasks/${selectedTask.task_id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(updates),
      });

      if (response.ok) {
        const updatedTask = await response.json();
        setSelectedTask(updatedTask);
        fetchTasks();
        toast.success("Task updated");
      } else {
        const error = await response.json();
        toast.error(error.detail || "Failed to update task");
      }
    } catch (error) {
      toast.error("Failed to update task");
    }
  };

  const deleteTask = async () => {
    if (!selectedTask) return;
    
    try {
      const response = await fetch(`${API}/tasks/${selectedTask.task_id}`, {
        method: "DELETE",
        credentials: "include",
      });

      if (response.ok) {
        // Also remove highlight from script
        if (selectedTask.script_id && selectedTask.selected_text) {
          try {
            await fetch(`${API}/scripts/${selectedTask.script_id}/remove-highlight`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              credentials: "include",
              body: JSON.stringify({ selected_text: selectedTask.selected_text }),
            });
          } catch (e) { /* best effort */ }
        }
        toast.success("Task deleted");
        setDeleteTaskConfirmOpen(false);
        closeTaskPanel();
        fetchScript();
        fetchTasks();
      } else {
        const error = await response.json();
        toast.error(error.detail || "Failed to delete task");
      }
    } catch (error) {
      toast.error("Failed to delete task");
    }
  };

  // Toggle task selection for bulk operations
  const toggleTaskSelection = (taskId, event) => {
    event.stopPropagation();
    setSelectedTaskIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(taskId)) {
        newSet.delete(taskId);
      } else {
        newSet.add(taskId);
      }
      return newSet;
    });
  };

  // Select/deselect all tasks
  const toggleSelectAll = () => {
    if (selectedTaskIds.size === tasks.length) {
      setSelectedTaskIds(new Set());
    } else {
      setSelectedTaskIds(new Set(tasks.map(t => t.task_id)));
    }
  };

  // Delete selected tasks
  const deleteSelectedTasks = async () => {
    if (selectedTaskIds.size === 0) return;
    
    try {
      let deleted = 0;
      for (const taskId of selectedTaskIds) {
        const response = await fetch(`${API}/tasks/${taskId}`, {
          method: "DELETE",
          credentials: "include",
        });
        if (response.ok) deleted++;
      }
      
      toast.success(`${deleted} task(s) deleted`);
      setSelectedTaskIds(new Set());
      setIsSelectionMode(false);
      setDeleteConfirmOpen(false);
      fetchTasks();
    } catch (error) {
      toast.error("Failed to delete some tasks");
      fetchTasks();
    }
  };

  // Cancel selection mode
  const cancelSelectionMode = () => {
    setIsSelectionMode(false);
    setSelectedTaskIds(new Set());
  };

  const addAttachment = async () => {
    if (!selectedTask || !newAttachment.url) return;
    
    try {
      const response = await fetch(`${API}/tasks/${selectedTask.task_id}/attachments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          task_id: selectedTask.task_id,
          type: newAttachment.type,
          url: newAttachment.url,
          filename: newAttachment.url.split("/").pop(),
        }),
      });

      if (response.ok) {
        toast.success("Attachment added");
        setNewAttachment({ type: "link", url: "" });
        fetchAttachments(selectedTask.task_id);
        fetchTasks();
      }
    } catch (error) {
      toast.error("Failed to add attachment");
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file || !selectedTask) return;
    
    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetch(`${API}/upload`, {
        method: "POST",
        credentials: "include",
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        // Add attachment record
        await fetch(`${API}/tasks/${selectedTask.task_id}/attachments`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({
            task_id: selectedTask.task_id,
            type: data.type,
            url: data.url,
            filename: data.filename,
            gdrive_file_id: data.gdrive_file_id || "",
          }),
        });
        toast.success("File uploaded");
        fetchAttachments(selectedTask.task_id);
        fetchTasks();
      }
    } catch (error) {
      toast.error("Failed to upload file");
    }
    e.target.value = "";
  };

  const deleteAttachment = async (attachmentId) => {
    try {
      const response = await fetch(`${API}/attachments/${attachmentId}`, {
        method: "DELETE",
        credentials: "include",
      });

      if (response.ok) {
        toast.success("Attachment removed");
        fetchAttachments(selectedTask.task_id);
        fetchTasks();
      }
    } catch (error) {
      toast.error("Failed to remove attachment");
    }
  };

  // Audio recording
  const startRecording = async () => {
    if (!selectedTask) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = async () => {
        stream.getTracks().forEach(t => t.stop());
        const blob = new Blob(audioChunksRef.current, { type: "audio/webm" });
        const file = new File([blob], `recording_${Date.now()}.webm`, { type: "audio/webm" });
        const formData = new FormData();
        formData.append("file", file);

        try {
          const uploadRes = await fetch(`${API}/upload`, { method: "POST", credentials: "include", body: formData });
          if (uploadRes.ok) {
            const data = await uploadRes.json();
            await fetch(`${API}/tasks/${selectedTask.task_id}/attachments`, {
              method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
              body: JSON.stringify({ task_id: selectedTask.task_id, type: "audio", url: data.url, filename: data.filename, gdrive_file_id: data.gdrive_file_id || "" }),
            });
            toast.success("Audio recorded and attached");
            fetchAttachments(selectedTask.task_id);
            fetchTasks();
          }
        } catch (err) {
          toast.error("Failed to upload recording");
        }
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
      recordingTimerRef.current = setInterval(() => setRecordingTime(t => t + 1), 1000);
    } catch (err) {
      toast.error("Microphone access denied");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
    clearInterval(recordingTimerRef.current);
    setRecordingTime(0);
  };

  const formatRecordingTime = (s) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;

  const fetchWorkflowStages = async () => {
    try {
      const response = await fetch(`${API}/workflow-stages`, { credentials: "include" });
      if (response.ok) setWorkflowStages(await response.json());
    } catch (error) {
      console.error("Failed to fetch workflow stages:", error);
    }
  };

  const fetchShareLink = async () => {
    try {
      const res = await fetch(`${API}/scripts/${scriptId}/share`, { credentials: "include" });
      if (res.ok) {
        const data = await res.json();
        if (data.token) setShareToken(data.token);
      }
    } catch (e) { /* ignore */ }
  };

  const copyShareLink = async () => {
    try {
      let token = shareToken;
      if (!token) {
        const res = await fetch(`${API}/scripts/${scriptId}/share`, {
          method: "POST", credentials: "include",
        });
        if (res.ok) {
          const data = await res.json();
          token = data.token;
          setShareToken(token);
        } else {
          toast.error("Failed to create share link");
          return;
        }
      }
      const url = `${window.location.origin}/shared/${token}`;
      await navigator.clipboard.writeText(url);
      setCopied(true);
      toast.success("Link copied to clipboard");
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      toast.error("Failed to copy link");
    }
  };

  const updateStage = async (stageId, field, value) => {
    if (!selectedTask) return;
    try {
      const response = await fetch(`${API}/tasks/${selectedTask.task_id}/stage`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ stage_id: stageId, [field]: value }),
      });
      if (response.ok) {
        // Refresh the task data
        const taskRes = await fetch(`${API}/tasks/${selectedTask.task_id}`, { credentials: "include" });
        if (taskRes.ok) {
          const updated = await taskRes.json();
          setSelectedTask(updated);
        }
        fetchTasks();
      } else {
        const err = await response.json();
        toast.error(err.detail || "Failed to update");
      }
    } catch (error) {
      toast.error("Failed to update");
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="w-8 h-8 border-2 border-slate-900 border-t-transparent rounded-full animate-spin"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout 
      breadcrumbs={[
        { label: "Projects", href: "/dashboard" },
        { label: project?.name || "Project", href: `/projects/${project?.project_id}` },
        { label: script?.name || "Script" }
      ]}
    >
      <div className={`transition-all duration-300 ${panelOpen ? "mr-80" : ""}`}>
        <div className="mb-6">
          <button 
            onClick={() => safeNavigate(`/projects/${script?.project_id}`)}
            className="flex items-center gap-2 text-sm text-slate-500 hover:text-slate-900 transition-colors mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Scripts
          </button>
        </div>

        <div className="flex items-center justify-between mb-6">
          <h1 className="page-title" data-testid="script-title">{script?.name}</h1>
          <div className="flex items-center gap-3">
            {hasUnsavedChanges && (
              <span className="text-sm text-amber-600 font-medium" data-testid="unsaved-indicator">Unsaved changes</span>
            )}
            <Button 
              onClick={() => saveContent(editor?.getHTML())}
              disabled={saving || !hasUnsavedChanges}
              variant={hasUnsavedChanges ? "default" : "outline"}
              size="sm"
              data-testid="save-script-btn"
            >
              <Save className="w-4 h-4 mr-2" />
              {saving ? "Saving..." : "Save"}
            </Button>
            {canEdit && (
              <Button
                onClick={copyShareLink}
                variant="outline"
                size="sm"
                data-testid="copy-share-link-btn"
              >
                {copied ? <Check className="w-4 h-4 mr-2 text-green-500" /> : <Copy className="w-4 h-4 mr-2" />}
                {copied ? "Copied!" : "Copy Link"}
              </Button>
            )}
            <span className="text-sm text-slate-500">
              {tasks.length} {tasks.length === 1 ? "task" : "tasks"}
            </span>
          </div>
        </div>

        {/* Lock banner */}
        {scriptLock && !isLockedByMe && (
          <div className="flex items-center gap-2 px-4 py-2.5 bg-amber-50 border border-amber-200 rounded-lg mb-4" data-testid="script-lock-banner">
            <Lock className="w-4 h-4 text-amber-600 flex-shrink-0" />
            <span className="text-sm text-amber-800 font-medium">
              {scriptLock.locked_by_name || "Someone"} is currently editing this script. You are in read-only mode.
            </span>
          </div>
        )}

        {/* Editor */}
        <div className="editor-container" ref={editorContainerRef}>
          {/* Toolbar */}
          <div className="editor-toolbar">
            <button
              onClick={() => { editor?.chain().focus().undo().run(); }}
              disabled={!editor?.can().undo()}
              className={`toolbar-btn ${!editor?.can().undo() ? "opacity-40 cursor-not-allowed" : ""}`}
              title="Undo"
              data-testid="toolbar-undo"
            >
              <Undo2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => { editor?.chain().focus().redo().run(); }}
              disabled={!editor?.can().redo()}
              className={`toolbar-btn ${!editor?.can().redo() ? "opacity-40 cursor-not-allowed" : ""}`}
              title="Redo"
              data-testid="toolbar-redo"
            >
              <Redo2 className="w-4 h-4" />
            </button>
            <div className="w-px h-5 bg-slate-200 mx-1"></div>
            <button
              onClick={() => editor?.chain().focus().toggleBold().run()}
              className={`toolbar-btn ${editor?.isActive("bold") ? "active" : ""}`}
              data-testid="toolbar-bold"
            >
              <Bold className="w-4 h-4" />
            </button>
            <button
              onClick={() => editor?.chain().focus().toggleItalic().run()}
              className={`toolbar-btn ${editor?.isActive("italic") ? "active" : ""}`}
              data-testid="toolbar-italic"
            >
              <Italic className="w-4 h-4" />
            </button>
            <div className="w-px h-5 bg-slate-200 mx-1"></div>
            <button
              onClick={() => editor?.chain().focus().toggleHeading({ level: 1 }).run()}
              className={`toolbar-btn ${editor?.isActive("heading", { level: 1 }) ? "active" : ""}`}
            >
              <Heading1 className="w-4 h-4" />
            </button>
            <button
              onClick={() => editor?.chain().focus().toggleHeading({ level: 2 }).run()}
              className={`toolbar-btn ${editor?.isActive("heading", { level: 2 }) ? "active" : ""}`}
            >
              <Heading2 className="w-4 h-4" />
            </button>
            <div className="w-px h-5 bg-slate-200 mx-1"></div>
            <button
              onClick={() => editor?.chain().focus().toggleBulletList().run()}
              className={`toolbar-btn ${editor?.isActive("bulletList") ? "active" : ""}`}
            >
              <List className="w-4 h-4" />
            </button>
            <button
              onClick={() => editor?.chain().focus().toggleOrderedList().run()}
              className={`toolbar-btn ${editor?.isActive("orderedList") ? "active" : ""}`}
            >
              <ListOrdered className="w-4 h-4" />
            </button>
            <button
              onClick={() => editor?.chain().focus().toggleBlockquote().run()}
              className={`toolbar-btn ${editor?.isActive("blockquote") ? "active" : ""}`}
            >
              <Quote className="w-4 h-4" />
            </button>
            <div className="flex-1"></div>
            <button
              onClick={() => saveContent(editor?.getHTML())}
              disabled={saving || !hasUnsavedChanges}
              className={`toolbar-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-semibold transition-colors ${
                hasUnsavedChanges
                  ? "bg-slate-900 text-white hover:bg-slate-800"
                  : "bg-slate-100 text-slate-400 cursor-not-allowed"
              }`}
              title={saving ? "Saving..." : hasUnsavedChanges ? "Save (Ctrl+S)" : "No changes to save"}
              data-testid="toolbar-save"
            >
              <Save className="w-4 h-4" />
              {saving ? "Saving..." : "Save"}
            </button>
          </div>

          {/* Editor Content */}
          <EditorContent editor={editor} className="tiptap-editor prose max-w-none" />
        </div>

        {/* Selection Popup */}
        {selectionPopup && canEdit && isLockedByMe && (
          <div 
            className="selection-popup"
            style={{ 
              left: `${selectionPopup.x}px`, 
              top: `${selectionPopup.y}px`,
              position: "fixed" 
            }}
          >
            {selectionPopup.isHighlighted && (
              <div className="mb-2">
                <div className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded px-2 py-1.5 mb-2" data-testid="overlap-warning">
                  This text is already highlighted.
                </div>
                <button
                  onClick={removeHighlight}
                  className="w-full px-3 py-1.5 rounded text-xs font-medium bg-red-50 text-red-600 border border-red-200 hover:bg-red-100 transition-colors flex items-center gap-1"
                  data-testid="remove-highlight-btn"
                >
                  <X className="w-3 h-3" />
                  Remove Highlight & Task
                </button>
              </div>
            )}
            {!selectionPopup.isHighlighted && (
              <>
                <div className="text-xs text-slate-500 mb-2 px-1">Create task:</div>
                <div className="flex gap-1 flex-wrap">
                  {categories.map((cat) => (
                    <button
                      key={cat.category_id}
                      onClick={() => createTaskFromSelection(cat.category_id)}
                      className="px-2 py-1 rounded text-xs font-medium transition-opacity hover:opacity-80"
                      style={{ 
                        backgroundColor: cat.bg_color, 
                        color: cat.text_color,
                        border: `1px solid ${cat.border_color}`
                      }}
                      data-testid={`category-btn-${cat.name}`}
                    >
                      {cat.name}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        )}

        {/* Tasks List */}
        {tasks.length > 0 && (
          <div className="mt-8">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-slate-900">Tasks ({tasks.length})</h3>
              {canEdit && (
                <div className="flex items-center gap-2">
                  {isSelectionMode ? (
                    <>
                      <span className="text-sm text-slate-500">
                        {selectedTaskIds.size} selected
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={toggleSelectAll}
                      >
                        {selectedTaskIds.size === tasks.length ? "Deselect All" : "Select All"}
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => setDeleteConfirmOpen(true)}
                        disabled={selectedTaskIds.size === 0}
                        data-testid="delete-selected-btn"
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        Delete Selected
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={cancelSelectionMode}
                      >
                        Cancel
                      </Button>
                    </>
                  ) : (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setIsSelectionMode(true)}
                      data-testid="select-tasks-btn"
                    >
                      <CheckSquare className="w-4 h-4 mr-1" />
                      Select
                    </Button>
                  )}
                </div>
              )}
            </div>
            <div className="space-y-2">
              {tasks.map((task, index) => {
                const category = categories.find(c => c.category_id === task.category_id);
                const isSelected = selectedTaskIds.has(task.task_id);
                const taskNumber = index + 1;
                const otherLock = getLockForTask(task.task_id);
                return (
                  <div
                    key={task.task_id}
                    onClick={() => !isSelectionMode && openTaskPanel(task, true)}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors flex items-center gap-3 ${
                      otherLock ? "border-orange-200 bg-orange-50/50" :
                      isSelected 
                        ? "border-blue-400 bg-blue-50" 
                        : "border-slate-200 hover:border-slate-300"
                    }`}
                    data-testid={`task-item-${task.task_id}`}
                  >
                    {isSelectionMode && (
                      <button
                        onClick={(e) => toggleTaskSelection(task.task_id, e)}
                        className="flex-shrink-0"
                      >
                        {isSelected ? (
                          <CheckSquare className="w-5 h-5 text-blue-600" />
                        ) : (
                          <Square className="w-5 h-5 text-slate-400" />
                        )}
                      </button>
                    )}
                    <span className="flex-shrink-0 w-7 h-7 rounded-full bg-slate-100 text-slate-500 text-xs font-semibold flex items-center justify-center" data-testid={`task-number-${taskNumber}`}>
                      {taskNumber}
                    </span>
                    <span 
                      className="px-2 py-1 rounded text-xs font-medium flex-shrink-0"
                      style={{ 
                        backgroundColor: category?.bg_color || "#F1F5F9", 
                        color: category?.text_color || "#374151"
                      }}
                    >
                      {category?.name || "Unknown"}
                    </span>
                    <span className="text-sm text-slate-700 truncate flex-1">
                      {task.selected_text.slice(0, 60)}{task.selected_text.length > 60 ? "..." : ""}
                    </span>
                    {task.attachments_count > 0 && (
                      <span className="flex items-center gap-1 text-xs text-slate-500">
                        <Paperclip className="w-3 h-3" />
                        {task.attachments_count}
                      </span>
                    )}
                    <span className="status-badge status-pending text-xs">
                      {task.status_name || "Pending"}
                    </span>
                    {otherLock && (
                      <span className="flex items-center gap-1 text-xs text-orange-600 bg-orange-100 px-1.5 py-0.5 rounded" title={`Being edited by ${otherLock.user_name}`} data-testid={`lock-indicator-${task.task_id}`}>
                        <Lock className="w-3 h-3" />
                        <span className="truncate max-w-[60px]">{otherLock.user_name?.split(" ")[0]}</span>
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Task Panel */}
      {panelOpen && selectedTask && (
        <div className="task-panel slide-in-right">
          <div className="task-panel-header">
            <h3 className="font-semibold text-slate-900">Task Details</h3>
            <button onClick={closeTaskPanel} className="btn-icon" data-testid="close-task-panel">
              <X className="w-4 h-4" />
            </button>
          </div>
          {(() => {
            const otherLock = getLockForTask(selectedTask.task_id);
            return otherLock ? (
              <div className="px-4 py-2 bg-orange-50 border-b border-orange-200 flex items-center gap-2 text-xs text-orange-700" data-testid="lock-banner">
                <Lock className="w-3.5 h-3.5" />
                <span>Being edited by <strong>{otherLock.user_name}</strong> — view only</span>
              </div>
            ) : null;
          })()}
          <div className="task-panel-content space-y-4">
            {/* Selected Text */}
            <div>
              <Label className="text-xs text-slate-500 uppercase tracking-wider">Selected Text</Label>
              <div 
                className="text-sm text-slate-700 mt-1 p-2 bg-slate-50 rounded border border-slate-100 cursor-pointer hover:bg-slate-100 transition-colors"
                onClick={() => scrollToTaskHighlight(selectedTask)}
                title="Click to go to highlight in script"
              >
                <span className="flex items-center justify-between">
                  <span>"{selectedTask.selected_text}"</span>
                  <span className="text-xs text-blue-600 hover:text-blue-800">Go to highlight →</span>
                </span>
              </div>
            </div>

            {/* Category */}
            <div>
              <Label>Category</Label>
              {(() => {
                const cat = categories.find(c => c.category_id === selectedTask.category_id);
                return (
                  <div 
                    className="px-3 py-2 rounded border border-slate-200 bg-slate-50 text-sm mt-1 flex items-center gap-2"
                    data-testid="task-category-display"
                  >
                    {cat && (
                      <span 
                        className="w-3 h-3 rounded-full shrink-0"
                        style={{ backgroundColor: cat.bg_color }}
                      />
                    )}
                    <span className="font-medium" style={{ color: cat?.text_color || "#374151" }}>
                      {cat?.name || "Unknown"}
                    </span>
                  </div>
                );
              })()}
            </div>

            {/* Description */}
            <div>
              <Label>Description</Label>
              <Textarea
                value={selectedTask.description || ""}
                onChange={(e) => setSelectedTask({ ...selectedTask, description: e.target.value })}
                onBlur={() => updateTask({ description: selectedTask.description })}
                placeholder="Add task description..."
                rows={3}
                disabled={!canEdit}
                data-testid="task-description"
              />
            </div>

            {/* Assigned By */}
            <div>
              <Label>Assigned By</Label>
              {(() => {
                const member = teamMembers.find(m => m.member_id === selectedTask.assigned_by);
                return (
                  <div 
                    className="px-3 py-2 rounded border border-slate-200 bg-slate-50 text-sm mt-1 font-medium text-slate-700"
                    data-testid="task-assigned-by"
                  >
                    {member?.name || user?.name || "You"}
                  </div>
                );
              })()}
            </div>

            {/* Dynamic Workflow Stage Assignments */}
            {workflowStages.map((ws) => {
              const stageData = selectedTask.stage_assignments?.[ws.stage_id] || {};
              return (
                <div key={ws.stage_id}>
                  <Label>{ws.name} Assigned To</Label>
                  <Select
                    value={stageData.assigned_to || "none"}
                    onValueChange={(value) => updateStage(ws.stage_id, "assigned_to", value === "none" ? "" : value)}
                    disabled={!canEdit}
                  >
                    <SelectTrigger data-testid={`stage-assigned-${ws.stage_id}`}>
                      <SelectValue placeholder={`Assign ${ws.name.toLowerCase()}`} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Unassigned</SelectItem>
                      {teamMembers.map((m) => (
                        <SelectItem key={m.member_id} value={m.member_id}>{m.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              );
            })}

            {/* Attachments */}
            <div>
              <Label className="flex items-center gap-2">
                <Paperclip className="w-4 h-4" />
                Attachments ({attachments.length})
              </Label>
              
              {/* Attachments List */}
              <div className="mt-2 space-y-2">
                {attachments.map((att) => (
                  <div key={att.attachment_id} className="p-2 bg-slate-50 rounded border border-slate-100" data-testid={`attachment-${att.attachment_id}`}>
                    {att.type === "image" ? (
                      <div>
                        <a href={getAttachmentUrl(att, "full")} target="_blank" rel="noopener noreferrer" className="block">
                          <img
                            src={getAttachmentUrl(att, "thumbnail")}
                            alt={att.filename || "Image"}
                            className="w-full max-h-40 object-contain bg-white rounded border border-slate-200 cursor-pointer hover:opacity-90 transition-opacity"
                          />
                        </a>
                        <div className="flex items-center justify-between mt-1.5">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <Image className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span className="text-xs text-slate-500 truncate">{att.filename || "Image"}</span>
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            <a href={getAttachmentUrl(att, "download")} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-blue-600" title="Download">
                              <Download className="w-3.5 h-3.5" />
                            </a>
                            {canEdit && (
                              <button onClick={() => deleteAttachment(att.attachment_id)} className="btn-icon text-red-400 hover:text-red-600">
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    ) : att.type === "audio" ? (
                      <div>
                        <div className="flex items-center gap-1.5 mb-1.5">
                          <Volume2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="text-xs text-slate-500 truncate flex-1">{att.filename || "Audio"}</span>
                          <a href={getAttachmentUrl(att, "download")} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-blue-600 shrink-0" title="Download">
                            <Download className="w-3.5 h-3.5" />
                          </a>
                          {canEdit && (
                            <button onClick={() => deleteAttachment(att.attachment_id)} className="btn-icon text-red-400 hover:text-red-600 shrink-0">
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                        <audio controls src={getAttachmentUrl(att, "audio")} className="w-full h-8" data-testid={`audio-player-${att.attachment_id}`} />
                      </div>
                    ) : att.type === "link" ? (
                      <div className="flex items-center gap-2">
                        <LinkIcon className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <a href={att.url} target="_blank" rel="noopener noreferrer" className="text-sm text-blue-600 hover:underline truncate flex-1">
                          {att.filename || att.url}
                        </a>
                        <a href={att.url} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-blue-600 shrink-0" title="Open">
                          <Download className="w-3.5 h-3.5" />
                        </a>
                        {canEdit && (
                          <button onClick={() => deleteAttachment(att.attachment_id)} className="btn-icon text-red-400 hover:text-red-600 shrink-0">
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <FileText className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="text-sm text-slate-600 truncate flex-1">{att.filename || att.url}</span>
                        <a href={getAttachmentUrl(att, "download")} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-blue-600 shrink-0" title="Download">
                          <Download className="w-3.5 h-3.5" />
                        </a>
                        {canEdit && (
                          <button onClick={() => deleteAttachment(att.attachment_id)} className="btn-icon text-red-400 hover:text-red-600 shrink-0">
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Add Attachment */}
              {canEdit && (
                <div className="mt-3 space-y-2">
                  {/* Record Audio */}
                  <div>
                    {isRecording ? (
                      <Button
                        variant="destructive"
                        size="sm"
                        className="w-full"
                        onClick={stopRecording}
                        data-testid="stop-recording-btn"
                      >
                        <MicOff className="w-4 h-4 mr-2" />
                        Stop Recording ({formatRecordingTime(recordingTime)})
                      </Button>
                    ) : (
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full"
                        onClick={startRecording}
                        data-testid="start-recording-btn"
                      >
                        <Mic className="w-4 h-4 mr-2" />
                        Record Audio
                      </Button>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Select
                      value={newAttachment.type}
                      onValueChange={(value) => setNewAttachment({ ...newAttachment, type: value })}
                    >
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="link">Link</SelectItem>
                        <SelectItem value="image">Image</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      value={newAttachment.url}
                      onChange={(e) => setNewAttachment({ ...newAttachment, url: e.target.value })}
                      placeholder="Enter URL..."
                      className="flex-1"
                    />
                    <Button onClick={addAttachment} size="sm" variant="outline">
                      <LinkIcon className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="relative">
                    <input
                      type="file"
                      onChange={handleFileUpload}
                      className="hidden"
                      id="file-upload"
                      accept=".jpg,.jpeg,.png,.gif,.webp,.pdf,.doc,.docx,.txt,.csv,.xlsx,.mp3,.wav,.webm,.ogg,.m4a"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full"
                      onClick={() => document.getElementById("file-upload").click()}
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Upload File
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* Submit & Delete Buttons */}
            {canEdit && (
              <div className="pt-4 border-t border-slate-100 space-y-2">
                <Button 
                  className="w-full"
                  onClick={() => {
                    toast.success("Task saved successfully");
                    closeTaskPanel();
                  }}
                  data-testid="submit-task-btn"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Submit
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full text-red-600 border-red-200 hover:bg-red-50"
                  onClick={() => setDeleteTaskConfirmOpen(true)}
                  data-testid="delete-task-btn"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Task
                </Button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Delete Confirmation Dialogs */}
      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Tasks</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete {selectedTaskIds.size} selected task(s)? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={deleteSelectedTasks} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={deleteTaskConfirmOpen} onOpenChange={setDeleteTaskConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Task</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this task? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={deleteTask} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Unsaved changes navigation blocker */}
      <AlertDialog open={!!pendingNavigation} onOpenChange={(open) => { if (!open) setPendingNavigation(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Unsaved Changes</AlertDialogTitle>
            <AlertDialogDescription>
              You have unsaved changes. Are you sure you want to leave? Your changes will be lost.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setPendingNavigation(null)}>Stay</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                setHasUnsavedChanges(false);
                const target = pendingNavigation;
                setPendingNavigation(null);
                if (target === "__back__") {
                  window.history.back();
                } else {
                  navigate(target);
                }
              }}
              className="bg-red-600 hover:bg-red-700"
              data-testid="confirm-leave-btn"
            >
              Leave
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Layout>
  );
};

export default ScriptEditorPage;
