import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Layout } from "../components/Layout";
import { API, useAuth } from "../App";
import { toast } from "sonner";
import {
  FileText, Highlighter, Palette, Brain, ImageIcon, Sparkles, Download,
  Plus, Trash2, Loader2, ArrowLeft, Zap, History, X, Upload,
  Play, Pause, Square, Pencil, Check, Clock, Settings2,
  Image as ImageLucide, Users, Camera, UserCircle, RefreshCw, DownloadCloud,
  Video, CheckSquare, Square as SquareIcon, Eye, ChevronDown,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Label } from "../components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "../components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "../components/ui/select";
import { Badge } from "../components/ui/badge";
import { ScrollArea } from "../components/ui/scroll-area";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

// Placeholder for broken/missing images
const BROKEN_IMG_PLACEHOLDER = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200' viewBox='0 0 200 200'%3E%3Crect width='200' height='200' fill='%23f1f5f9'/%3E%3Ctext x='50%25' y='45%25' text-anchor='middle' fill='%2394a3b8' font-family='system-ui' font-size='14'%3EImage unavailable%3C/text%3E%3Ctext x='50%25' y='60%25' text-anchor='middle' fill='%23cbd5e1' font-family='system-ui' font-size='11'%3ERegenerate to restore%3C/text%3E%3C/svg%3E";
const handleImgError = (e) => { e.target.src = BROKEN_IMG_PLACEHOLDER; e.target.onerror = null; };

const CAMERA_ANGLES = [
  "Wide Shot", "Medium Shot", "Close-up", "Extreme Close-up",
  "Over-the-shoulder", "Bird's Eye View", "Low Angle", "High Angle",
  "Dutch Angle", "Establishing Shot",
];

const STEPS = [
  { key: "script", label: "Script", icon: FileText, color: "bg-slate-800" },
  { key: "characters", label: "Characters", icon: Users, color: "bg-rose-600" },
  { key: "references", label: "References", icon: ImageLucide, color: "bg-teal-600" },
  { key: "scenes", label: "Scenes", icon: Highlighter, color: "bg-amber-500" },
  { key: "style", label: "Style", icon: Palette, color: "bg-violet-600" },
  { key: "generate", label: "Generate", icon: Brain, color: "bg-blue-600" },
  { key: "output", label: "Output", icon: ImageIcon, color: "bg-slate-900" },
];

const formatTime = (s) => (s < 60 ? `${s}s` : `${Math.floor(s / 60)}m ${s % 60}s`);
const toFilename = (text, i) => {
  const slug = text.replace(/<[^>]+>/g, '').replace(/[^a-zA-Z0-9\s]/g, '').trim().replace(/\s+/g, '_').slice(0, 60);
  return slug ? `${slug}.png` : `scene_${i + 1}.png`;
};

// Pipeline indicator
const PipelineIndicator = ({ activeStep }) => (
  <div className="flex items-center gap-1 overflow-x-auto pb-2" data-testid="pipeline-indicator">
    {STEPS.map((step, i) => {
      const Icon = step.icon;
      const isActive = activeStep === step.key;
      const isPast = STEPS.findIndex(s => s.key === activeStep) > i;
      return (
        <div key={step.key} className="flex items-center gap-1">
          <div className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${isActive ? `${step.color} text-white shadow-md scale-105` : isPast ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
            <Icon className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{step.label}</span>
          </div>
          {i < STEPS.length - 1 && <div className={`w-4 h-0.5 ${isPast ? "bg-emerald-400" : "bg-slate-200"}`} />}
        </div>
      );
    })}
  </div>
);

// Styles Master Dialog
const StylesMaster = ({ styles, onAdd, onUpdate, onDelete, onRefresh, isAdmin }) => {
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({ name: "", description: "", headshot_prompt: "" });
  const [newForm, setNewForm] = useState({ name: "", description: "", headshot_prompt: "" });
  const [uploadingGuide, setUploadingGuide] = useState(null);
  const guideInputRef = useRef(null);
  const startEdit = (s) => { setEditingId(s.style_id); setEditForm({ name: s.name, description: s.description, headshot_prompt: s.headshot_prompt || "" }); };
  const saveEdit = () => { if (!editForm.name.trim()) return; onUpdate(editingId, editForm); setEditingId(null); };
  const handleCreate = (e) => { e.preventDefault(); if (!newForm.name.trim()) return; onAdd(newForm); setNewForm({ name: "", description: "", headshot_prompt: "" }); };

  const uploadGuideImage = async (styleId, file) => {
    setUploadingGuide(styleId);
    const fd = new FormData(); fd.append("file", file);
    try {
      const r = await fetch(`${BACKEND_URL}/api/media/styles/${styleId}/guide-images`, {
        method: "POST", credentials: "include", body: fd,
      });
      if (r.ok) { onRefresh(); toast.success("Guide image uploaded"); }
      else toast.error("Upload failed");
    } catch (e) { toast.error("Upload failed"); }
    setUploadingGuide(null);
    if (guideInputRef.current) guideInputRef.current.value = "";
  };

  const deleteGuideImage = async (styleId, url) => {
    try {
      const r = await fetch(`${BACKEND_URL}/api/media/styles/${styleId}/guide-images`, {
        method: "DELETE", credentials: "include", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });
      if (r.ok) { onRefresh(); toast.success("Guide image removed"); }
    } catch (e) { toast.error("Delete failed"); }
  };

  return (
    <>
      <Button variant="outline" size="sm" onClick={() => setOpen(true)} data-testid="styles-master-btn"><Settings2 className="w-4 h-4 mr-1.5" />Styles</Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Visual Styles</DialogTitle>
            <DialogDescription>{isAdmin ? "Create, edit and manage visual styles. Upload style guide images for consistent headshot generation." : "Browse available visual styles."}</DialogDescription>
          </DialogHeader>

          {isAdmin && (
            <form onSubmit={handleCreate} className="rounded-lg border border-dashed border-slate-300 bg-slate-50/50 p-4 space-y-3" data-testid="new-style-form">
              <p className="text-xs font-semibold text-slate-700 uppercase tracking-wide">New Style</p>
              <Input placeholder="Style name (e.g. Cinematic Warm)" value={newForm.name} onChange={(e) => setNewForm({ ...newForm, name: e.target.value })} required data-testid="new-style-name" className="bg-white" />
              <Textarea placeholder="Paste or type the full style description...&#10;&#10;e.g. Cinematic warm tones, soft golden-hour lighting, 35mm film grain, shallow depth of field, rich earth tones with amber highlights" value={newForm.description} onChange={(e) => setNewForm({ ...newForm, description: e.target.value })} required data-testid="new-style-desc" className="min-h-[100px] text-sm bg-white" />
              <div>
                <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide mb-1 block">Headshot Prompt <span className="text-slate-400 normal-case font-normal">(optional — custom prompt template for generating character headshots)</span></label>
                <Textarea placeholder="e.g. Close-up portrait, clean white background, sharp studio lighting, 1:1 square ratio, soft cel-shading with bold outlines..." value={newForm.headshot_prompt} onChange={(e) => setNewForm({ ...newForm, headshot_prompt: e.target.value })} data-testid="new-style-headshot-prompt" className="min-h-[80px] text-sm bg-white" />
              </div>
              <Button type="submit" size="sm" data-testid="add-style-btn"><Plus className="w-4 h-4 mr-1" />Add Style</Button>
            </form>
          )}

          <ScrollArea className="max-h-[400px] mt-2">
            <div className="space-y-3">
              {styles.map((s) => (
                <div key={s.style_id} className={`rounded-lg border transition-colors ${editingId === s.style_id ? "border-blue-300 bg-blue-50/30" : "border-slate-200 bg-white"}`}>
                  {editingId === s.style_id ? (
                    <div className="p-4 space-y-3">
                      <div>
                        <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide mb-1 block">Style Name</label>
                        <Input value={editForm.name} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} className="text-sm font-medium" placeholder="Style name" autoFocus data-testid={`edit-style-name-${s.style_id}`} />
                      </div>
                      <div>
                        <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide mb-1 block">Description</label>
                        <Textarea value={editForm.description} onChange={(e) => setEditForm({ ...editForm, description: e.target.value })} className="min-h-[100px] text-sm" placeholder="Style description..." data-testid={`edit-style-desc-${s.style_id}`} />
                      </div>
                      <div>
                        <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide mb-1 block">Headshot Prompt <span className="text-slate-400 normal-case font-normal">(custom prompt for character headshots)</span></label>
                        <Textarea value={editForm.headshot_prompt} onChange={(e) => setEditForm({ ...editForm, headshot_prompt: e.target.value })} className="min-h-[80px] text-sm" placeholder="e.g. Close-up portrait, clean white background, sharp studio lighting..." data-testid={`edit-style-headshot-prompt-${s.style_id}`} />
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" onClick={saveEdit} className="h-8 text-xs" data-testid={`save-style-${s.style_id}`}><Check className="w-3.5 h-3.5 mr-1" />Save Changes</Button>
                        <Button size="sm" variant="outline" onClick={() => setEditingId(null)} className="h-8 text-xs">Cancel</Button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm font-semibold text-slate-900">{s.name}</h4>
                          <p className="text-xs text-slate-500 mt-1.5 leading-relaxed whitespace-pre-wrap">{s.description}</p>
                          {s.headshot_prompt && (
                            <div className="mt-2 p-2 bg-slate-50 rounded-md border border-slate-100">
                              <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wide mb-0.5">Headshot Prompt</p>
                              <p className="text-[11px] text-slate-600 whitespace-pre-wrap">{s.headshot_prompt}</p>
                            </div>
                          )}
                        </div>
                        {isAdmin && (
                          <div className="flex items-center gap-1 shrink-0">
                            <button onClick={() => startEdit(s)} className="p-2 text-slate-400 hover:text-blue-600 rounded-md hover:bg-blue-50 transition-colors" title="Edit style" data-testid={`edit-style-${s.style_id}`}><Pencil className="w-4 h-4" /></button>
                            <button onClick={() => { if (window.confirm(`Delete "${s.name}"?`)) onDelete(s.style_id); }} className="p-2 text-slate-400 hover:text-red-600 rounded-md hover:bg-red-50 transition-colors" title="Delete style" data-testid={`delete-style-${s.style_id}`}><Trash2 className="w-4 h-4" /></button>
                          </div>
                        )}
                      </div>
                      {/* Guide Images */}
                      {((s.guide_images && s.guide_images.length > 0) || isAdmin) && (
                        <div className="mt-3 pt-3 border-t border-slate-100">
                          <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide mb-2">Style Guide Images</p>
                          <div className="flex gap-2 flex-wrap">
                            {(s.guide_images || []).map((img, gi) => (
                              <div key={gi} className="relative group">
                                <img src={`${BACKEND_URL}${img.url}`} alt="" className="w-16 h-16 object-cover rounded-md border border-slate-200" onError={handleImgError} />
                                {isAdmin && (
                                  <button onClick={() => deleteGuideImage(s.style_id, img.url)} className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-[10px]"><X className="w-2.5 h-2.5" /></button>
                                )}
                              </div>
                            ))}
                            {isAdmin && (
                              <button
                                onClick={() => { setUploadingGuide(s.style_id); guideInputRef.current?.click(); }}
                                className="w-16 h-16 rounded-md border-2 border-dashed border-slate-300 flex items-center justify-center text-slate-400 hover:border-slate-400 hover:text-slate-500 transition-colors"
                                data-testid={`upload-guide-${s.style_id}`}
                              >
                                {uploadingGuide === s.style_id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                              </button>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
              {styles.length === 0 && <p className="text-sm text-slate-500 text-center py-8">No styles yet.{isAdmin ? " Create your first style above." : " Ask admin to add styles."}</p>}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
      <input ref={guideInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => {
        const file = e.target.files?.[0];
        if (file && uploadingGuide) uploadGuideImage(uploadingGuide, file);
      }} />
    </>
  );
};

// ---- Main Page ----
export const ScriptToMediaPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const refImgInputRef = useRef(null);

  const [scripts, setScripts] = useState([]);
  const [styles, setStyles] = useState([]);
  const [selectedScript, setSelectedScript] = useState(null);
  const [scriptContent, setScriptContent] = useState("");

  // Characters
  const [characters, setCharacters] = useState([]);
  const [editingChar, setEditingChar] = useState(null);
  const [editCharForm, setEditCharForm] = useState({ name: "", description: "" });
  const [detectingChars, setDetectingChars] = useState(false);

  // Headshots in Reference panel
  const [headshots, setHeadshots] = useState([]);
  const [headshotBatchId, setHeadshotBatchId] = useState(null);
  const [headshotProgress, setHeadshotProgress] = useState(null);
  const [selectedCharIdsForHeadshot, setSelectedCharIdsForHeadshot] = useState(new Set());

  // Reference images
  const [referenceImages, setReferenceImages] = useState([]);

  // Scene blocks (highlights)
  const [highlights, setHighlights] = useState([]);
  const [editingHighlight, setEditingHighlight] = useState(null);
  const [editText, setEditText] = useState("");
  const [customText, setCustomText] = useState("");

  // Style
  const [selectedStyleId, setSelectedStyleId] = useState("");
  // Text model now controlled by admin AI settings (no frontend selector)

  // Pipeline
  const [activeStep, setActiveStep] = useState("script");
  const [isGenerating, setIsGenerating] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const pauseRef = useRef(false);
  const [batchResults, setBatchResults] = useState([]);
  const [currentHighlightIdx, setCurrentHighlightIdx] = useState(-1);
  const [currentSubStep, setCurrentSubStep] = useState("");
  const [elapsedTime, setElapsedTime] = useState(0);
  const [estimatedRemaining, setEstimatedRemaining] = useState(null);
  const timerRef = useRef(null);
  const sceneStartTimeRef = useRef(null);
  const sceneDurationsRef = useRef([]);

  // Dialogs
  const [scriptDialogOpen, setScriptDialogOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [generations, setGenerations] = useState([]);
  const [previewImage, setPreviewImage] = useState(null);

  // Video generation
  const [selectedForVideo, setSelectedForVideo] = useState(new Set());
  const [isGeneratingVideos, setIsGeneratingVideos] = useState(false);
  const [videoPollingIds, setVideoPollingIds] = useState([]);
  const videoPollingRef = useRef(null);

  // Upload-to-video
  const [uploadVideos, setUploadVideos] = useState([]);
  const [uploadVideoPrompt, setUploadVideoPrompt] = useState("");
  const [isUploadingVideo, setIsUploadingVideo] = useState(false);
  const uploadVideoPollingRef = useRef(null);
  const uploadFileRef = useRef(null);

  useEffect(() => { fetchProjects(); fetchStyles(); }, []);

  const fetchProjects = async () => {
    try {
      const res = await fetch(`${API}/projects`, { credentials: "include" });
      if (!res.ok) return;
      const projs = await res.json();
      const all = [];
      for (const p of projs) {
        const sr = await fetch(`${API}/projects/${p.project_id}/scripts`, { credentials: "include" });
        if (sr.ok) { const ss = await sr.json(); all.push(...ss.map(s => ({ ...s, project_name: p.name }))); }
      }
      setScripts(all);
    } catch (e) { console.error(e); }
  };

  const fetchStyles = async () => {
    try { const r = await fetch(`${API}/media/styles`, { credentials: "include" }); if (r.ok) setStyles(await r.json()); } catch (e) { console.error(e); }
  };

  const fetchCharacters = async (scriptId) => {
    try { const r = await fetch(`${API}/media/scripts/${scriptId}/characters`, { credentials: "include" }); if (r.ok) setCharacters(await r.json()); } catch (e) { console.error(e); }
  };

  const fetchHeadshots = async (scriptId) => {
    try { const r = await fetch(`${API}/media/scripts/${scriptId}/headshots`, { credentials: "include" }); if (r.ok) setHeadshots(await r.json()); } catch (e) { console.error(e); }
  };

  const generateHeadshots = async (charIds, force = false) => {
    if (!selectedScript || !selectedStyleId || charIds.length === 0) return;
    try {
      const r = await fetch(`${API}/media/scripts/${selectedScript.script_id}/generate-headshots`, {
        method: "POST", credentials: "include", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ style_id: selectedStyleId, character_ids: charIds, force }),
      });
      if (r.ok) {
        const data = await r.json();
        if (data.batch_id) {
          setHeadshotBatchId(data.batch_id);
          setHeadshotProgress({ completed: 0, total: data.generating, status: "generating", label: "Generating headshots" });
          toast.success(`Generating ${data.generating} headshot(s)...`);
        } else {
          toast.info(data.message || "Headshots already exist");
          fetchHeadshots(selectedScript.script_id);
        }
      } else { toast.error("Failed to start headshot generation"); }
    } catch (e) { toast.error("Failed to generate headshots"); }
  };

  // Poll headshot batch progress
  useEffect(() => {
    if (!headshotBatchId) return;
    const interval = setInterval(async () => {
      try {
        const r = await fetch(`${API}/media/headshot-batch/${headshotBatchId}`, { credentials: "include" });
        if (r.ok) {
          const batch = await r.json();
          setHeadshotProgress(prev => ({ completed: batch.completed, total: batch.total, failed: batch.failed, status: batch.status, label: prev?.label || "Generating headshots" }));
          if (batch.status === "completed") {
            clearInterval(interval);
            setHeadshotBatchId(null);
            setHeadshotProgress(null);
            fetchHeadshots(selectedScript?.script_id);
            toast.success(`${batch.completed} headshots generated!`);
          }
        }
      } catch (e) { /* ignore */ }
    }, 3000);
    return () => clearInterval(interval);
  }, [headshotBatchId]); // eslint-disable-line

  // When style changes, refresh headshots for that style
  useEffect(() => {
    if (selectedStyleId && selectedScript) {
      fetchHeadshots(selectedScript.script_id);
    }
  }, [selectedStyleId]); // eslint-disable-line

  const fetchGenerations = async () => {
    try {
      const url = selectedScript ? `${API}/media/generations?script_id=${selectedScript.script_id}` : `${API}/media/generations`;
      const r = await fetch(url, { credentials: "include" }); if (r.ok) setGenerations(await r.json());
    } catch (e) { console.error(e); }
  };

  const loadPreviousResults = async (scriptId) => {
    try {
      const r = await fetch(`${API}/media/generations?script_id=${scriptId}`, { credentials: "include" });
      if (r.ok) {
        const gens = await r.json();
        const completed = gens.filter(g => g.status === "completed" && g.image_url);
        if (completed.length > 0) {
          setBatchResults(completed.map(g => ({ ...g, highlight: { text: g.selected_text } })));
          setActiveStep("output");
        }
      }
    } catch (e) { console.error(e); }
  };

  // Script selection
  const handleSelectScript = async (script) => {
    try {
      const r = await fetch(`${API}/scripts/${script.script_id}`, { credentials: "include" });
      if (r.ok) {
        const full = await r.json();
        setSelectedScript(full);
        setScriptContent(full.content || "");
        setScriptDialogOpen(false);
        setHighlights([]);
        setReferenceImages([]);
        setBatchResults([]);
        setActiveStep("characters");
        fetchCharacters(full.script_id);
        fetchHeadshots(full.script_id);
        loadPreviousResults(full.script_id);
      }
    } catch (e) { toast.error("Failed to load script"); }
  };

  // ---- CHARACTERS ----
  const detectAllCharacters = async () => {
    if (!selectedScript) return;
    setDetectingChars(true);
    try {
      const r = await fetch(`${API}/media/detect-characters`, {
        method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ script_id: selectedScript.script_id }),
      });
      if (r.ok) {
        const data = await r.json();
        const detected = data.characters;
        if (data.model_used) toast.info(`Model used: ${data.model_used}`);
        const sr = await fetch(`${API}/media/scripts/${selectedScript.script_id}/characters`, {
          method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
          body: JSON.stringify(detected),
        });
        if (sr.ok) {
          const saved = await sr.json();
          setCharacters(prev => {
            const m = new Map(prev.map(c => [c.character_id, c]));
            saved.forEach(c => m.set(c.character_id, c));
            return Array.from(m.values());
          });
          toast.success(`Detected ${saved.length} character(s)`);
        }
      } else toast.error("Detection failed");
    } catch (e) { toast.error("Detection failed"); }
    setDetectingChars(false);
  };

  const clearAllCharacters = async () => {
    if (!selectedScript) return;
    try {
      const r = await fetch(`${API}/media/scripts/${selectedScript.script_id}/clear-all-characters`, {
        method: "POST", credentials: "include", headers: { "Content-Type": "application/json" },
      });
      if (r.ok) { setCharacters([]); setHeadshots([]); toast.success("All characters and headshots cleared"); }
      else toast.error("Failed to clear");
    } catch (e) { toast.error("Failed"); }
  };

  const updateCharacter = async (charId, data) => {
    try {
      const r = await fetch(`${API}/media/characters/${charId}`, { method: "PUT", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify(data) });
      if (r.ok) { const u = await r.json(); setCharacters(p => p.map(c => c.character_id === charId ? u : c)); toast.success("Updated"); }
    } catch (e) { toast.error("Failed"); }
    setEditingChar(null);
  };

  const deleteCharacter = async (charId) => {
    try {
      await fetch(`${API}/media/characters/${charId}`, { method: "DELETE", credentials: "include" });
      setCharacters(p => p.filter(c => c.character_id !== charId));
      setHighlights(p => p.map(h => ({ ...h, characterIds: (h.characterIds || []).filter(x => x !== charId) })));
      toast.success("Character removed");
    } catch (e) { toast.error("Failed"); }
  };

  // ---- HIGHLIGHTS (Scene Blocks) ----
  const handleTextSelection = () => {
    const sel = window.getSelection();
    const text = sel?.toString()?.trim();
    if (text && text.length > 2) {
      if (!highlights.some(h => h.text === text)) {
        setHighlights(p => [...p, { id: `hl_${Date.now()}`, text, isCustom: false, cameraAngle: "", aspectRatio: "16:9", characterIds: [] }]);
        sel.removeAllRanges();
        toast.success("Scene block added — select characters below");
      } else toast.info("Already highlighted");
    }
  };

  const removeHighlight = (id) => setHighlights(p => p.filter(h => h.id !== id));
  const startEditHighlight = (h) => { setEditingHighlight(h.id); setEditText(h.text); };
  const saveEditHighlight = () => { setHighlights(p => p.map(h => h.id === editingHighlight ? { ...h, text: editText } : h)); setEditingHighlight(null); };
  const addCustomHighlight = () => {
    if (!customText.trim()) return;
    setHighlights(p => [...p, { id: `hl_${Date.now()}`, text: customText.trim(), isCustom: true, cameraAngle: "", aspectRatio: "16:9", characterIds: [] }]);
    setCustomText("");
  };
  const setCameraAngle = (hlId, angle) => setHighlights(p => p.map(h => h.id === hlId ? { ...h, cameraAngle: angle } : h));
  const setAspectRatio = (hlId, ratio) => setHighlights(p => p.map(h => h.id === hlId ? { ...h, aspectRatio: ratio } : h));
  const toggleCharInScene = (hlId, charId) => {
    setHighlights(p => p.map(h => {
      if (h.id !== hlId) return h;
      const ids = h.characterIds || [];
      return { ...h, characterIds: ids.includes(charId) ? ids.filter(x => x !== charId) : [...ids, charId] };
    }));
  };

  // ---- REF IMAGES ----
  const handleRefImageUpload = async (e) => {
    const file = e.target.files?.[0]; if (!file) return;
    const fd = new FormData(); fd.append("file", file);
    try { const r = await fetch(`${API}/upload`, { method: "POST", credentials: "include", body: fd }); if (r.ok) { const d = await r.json(); setReferenceImages(p => [...p, { url: d.url, filename: d.filename }]); toast.success("Uploaded"); } } catch (e) { toast.error("Upload failed"); }
    if (refImgInputRef.current) refImgInputRef.current.value = "";
  };

  // ---- STYLES ----
  const addStyle = async (form) => { try { const r = await fetch(`${API}/media/styles`, { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify(form) }); if (r.ok) { const created = await r.json(); setStyles(p => [created, ...p]); toast.success("Style created"); } } catch (e) { toast.error("Failed"); } };
  const updateStyle = async (id, form) => { try { const r = await fetch(`${API}/media/styles/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify(form) }); if (r.ok) { const s = await r.json(); setStyles(p => p.map(x => x.style_id === id ? s : x)); toast.success("Updated"); } } catch (e) { toast.error("Failed"); } };
  const deleteStyle = async (id) => { try { await fetch(`${API}/media/styles/${id}`, { method: "DELETE", credentials: "include" }); setStyles(p => p.filter(s => s.style_id !== id)); if (selectedStyleId === id) setSelectedStyleId(""); toast.success("Deleted"); } catch (e) { toast.error("Failed"); } };

  // ---- TIMER ----
  const startTimer = () => { setElapsedTime(0); timerRef.current = setInterval(() => setElapsedTime(p => p + 1), 1000); };
  const stopTimer = () => { if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; } };

  // ---- BATCH GENERATION ----
  const startGeneration = async () => {
    if (!selectedScript || highlights.length === 0 || !selectedStyleId) { toast.error("Select a script, add scenes, and choose a style"); return; }
    setIsGenerating(true); setIsPaused(false); pauseRef.current = false;
    setBatchResults([]); setCurrentHighlightIdx(0); setActiveStep("generate"); startTimer();
    setEstimatedRemaining(null);
    sceneDurationsRef.current = [];
    const refUrls = referenceImages.map(r => r.url);
    const results = [];
    for (let i = 0; i < highlights.length; i++) {
      while (pauseRef.current) await new Promise(r => setTimeout(r, 500));
      setCurrentHighlightIdx(i); setCurrentSubStep("claude"); setActiveStep("generate");
      sceneStartTimeRef.current = Date.now();
      const hl = highlights[i];
      let charIds = hl.characterIds || [];
      // No auto-detection — only use manually selected characters
      try {
        const r = await fetch(`${API}/media/generate`, {
          method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
          body: JSON.stringify({ script_id: selectedScript.script_id, selected_text: hl.text, style_id: selectedStyleId, reference_image_urls: refUrls, character_ids: charIds, camera_angle: hl.cameraAngle || null, aspect_ratio: hl.aspectRatio || "16:9" }),
        });
        if (r.ok) {
          const result = await r.json();
          if (result.image_prompt) { setCurrentSubStep("nanoBanana"); }
          results.push({ ...result, highlight: hl });
        } else {
          results.push({ status: "failed", error: `Server error (${r.status})`, highlight: hl });
        }
        setBatchResults([...results]);
      } catch (e) {
        // Network timeout — backend may still be processing. Mark as pending recovery.
        results.push({ status: "recovering", error: null, highlight: hl });
        setBatchResults([...results]);
      }
      // Track scene duration and estimate remaining
      const sceneDuration = Math.round((Date.now() - sceneStartTimeRef.current) / 1000);
      sceneDurationsRef.current.push(sceneDuration);
      const avgDuration = Math.round(sceneDurationsRef.current.reduce((a, b) => a + b, 0) / sceneDurationsRef.current.length);
      const remaining = (highlights.length - i - 1) * avgDuration;
      setEstimatedRemaining(remaining > 0 ? remaining : null);
    }
    stopTimer(); setIsGenerating(false); setCurrentHighlightIdx(-1); setCurrentSubStep(""); setActiveStep("output"); setEstimatedRemaining(null);

    // Reconcile: fetch latest generations from DB to recover any timed-out results
    const hasRecovering = results.some(r => r.status === "recovering");
    if (hasRecovering) {
      toast.info("Some images timed out — checking server for completed results...");
      await new Promise(r => setTimeout(r, 5000)); // wait 5s for backend to finish
      try {
        const genResp = await fetch(`${API}/media/generations`, { credentials: "include" });
        if (genResp.ok) {
          const allGens = await genResp.json();
          const reconciledResults = results.map((r, idx) => {
            if (r.status !== "recovering") return r;
            // Find matching generation by selected_text
            const match = allGens.find(g =>
              g.selected_text === r.highlight?.text && g.script_id === selectedScript.script_id
            );
            if (match && match.status === "completed") {
              return { ...match, highlight: r.highlight };
            } else if (match) {
              return { ...match, highlight: r.highlight };
            }
            return { ...r, status: "failed", error: "Request timed out — image may still be generating on server. Check History." };
          });
          setBatchResults(reconciledResults);
          const recovered = reconciledResults.filter((r, i) => results[i].status === "recovering" && r.status === "completed").length;
          if (recovered > 0) toast.success(`${recovered} image(s) recovered from server`);
        }
      } catch (e) { console.error("Reconciliation failed:", e); }
    }
    // Play completion sound
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const playTone = (freq, start, dur) => { const o = ctx.createOscillator(); const g = ctx.createGain(); o.connect(g); g.connect(ctx.destination); o.type = "sine"; o.frequency.value = freq; g.gain.setValueAtTime(0.5, ctx.currentTime + start); g.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + start + dur); o.start(ctx.currentTime + start); o.stop(ctx.currentTime + start + dur); };
      playTone(523, 0, 0.15); playTone(659, 0.15, 0.15); playTone(784, 0.3, 0.3);
    } catch (e) { /* audio not available */ }
  };

  const togglePause = () => { pauseRef.current = !pauseRef.current; setIsPaused(!isPaused); if (pauseRef.current) stopTimer(); else startTimer(); };
  const stopGeneration = () => { pauseRef.current = false; setIsPaused(false); setIsGenerating(false); stopTimer(); setActiveStep("output"); };

  const downloadAll = () => {
    batchResults.filter(r => r.image_url).forEach((r, i) => {
      const fname = toFilename(r.highlight?.text || '', i);
      const a = document.createElement("a"); a.href = `${BACKEND_URL}${r.image_url}`; a.download = fname; a.target = "_blank"; document.body.appendChild(a); a.click(); document.body.removeChild(a);
    });
  };

  const canGenerate = selectedScript && highlights.length > 0 && selectedStyleId && !isGenerating;

  const toggleVideoSelection = (idx) => {
    setSelectedForVideo(prev => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  };

  const selectAllForVideo = () => {
    const completedIdxs = batchResults.map((r, i) => r.status === "completed" && r.generation_id ? i : null).filter(i => i !== null);
    if (selectedForVideo.size === completedIdxs.length) setSelectedForVideo(new Set());
    else setSelectedForVideo(new Set(completedIdxs));
  };

  const startVideoGeneration = async () => {
    const genIds = [...selectedForVideo].map(i => batchResults[i]?.generation_id).filter(Boolean);
    if (genIds.length === 0) { toast.error("Select images to generate videos"); return; }

    setIsGeneratingVideos(true);
    // Mark selected items as video generating
    setBatchResults(prev => prev.map((r, i) => selectedForVideo.has(i) ? { ...r, video_status: "generating" } : r));

    try {
      const resp = await fetch(`${API}/media/generate-videos`, {
        method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ generation_ids: genIds }),
      });
      if (!resp.ok) throw new Error("Failed to start video generation");
      const data = await resp.json();
      toast.success(`Started ${data.results.length} video generation(s). 8s videos, processing takes ~30-60s.`);
      setVideoPollingIds(genIds);
      startVideoPolling(genIds);
    } catch (e) {
      toast.error("Video generation failed: " + e.message);
      setIsGeneratingVideos(false);
    }
  };

  const startVideoPolling = (genIds) => {
    if (videoPollingRef.current) clearInterval(videoPollingRef.current);
    videoPollingRef.current = setInterval(async () => {
      try {
        const resp = await fetch(`${API}/media/poll-videos`, {
          method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
          body: JSON.stringify({ generation_ids: genIds }),
        });
        if (!resp.ok) return;
        const data = await resp.json();

        // Update batchResults with video status
        if (data.results.length > 0) {
          setBatchResults(prev => prev.map(r => {
            const update = data.results.find(u => u.generation_id === r.generation_id);
            if (update) return { ...r, ...update };
            return r;
          }));
        }

        // Check if all done
        const allDone = data.results.every(r => r.video_status !== "generating");
        if (allDone && data.results.length > 0) {
          clearInterval(videoPollingRef.current);
          videoPollingRef.current = null;
          setIsGeneratingVideos(false);
          setSelectedForVideo(new Set());
          const completed = data.results.filter(r => r.video_status === "completed").length;
          toast.success(`${completed}/${data.results.length} videos completed!`);
          // Play completion sound
          try { const ac = new (window.AudioContext || window.webkitAudioContext)(); const o = ac.createOscillator(); const g = ac.createGain(); o.connect(g); g.connect(ac.destination); o.frequency.value = 880; g.gain.value = 0.3; o.start(); o.stop(ac.currentTime + 0.3); } catch {}
        }
      } catch (e) { console.error("Video poll error:", e); }
    }, 8000);
  };

  // Cleanup polling on unmount
  useEffect(() => () => {
    if (videoPollingRef.current) clearInterval(videoPollingRef.current);
    if (uploadVideoPollingRef.current) clearInterval(uploadVideoPollingRef.current);
  }, []);

  // Upload image → Veo 3 video
  const handleUploadVideoFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingVideo(true);

    const formData = new FormData();
    formData.append("file", file);
    formData.append("prompt", uploadVideoPrompt || "Animate this scene with cinematic movement and atmosphere");

    try {
      const resp = await fetch(`${API}/media/generate-video-from-upload`, {
        method: "POST", credentials: "include", body: formData,
      });
      if (!resp.ok) throw new Error((await resp.json()).detail || "Upload failed");
      const data = await resp.json();
      setUploadVideos(prev => [data, ...prev]);
      toast.success("8s video generation started! Processing takes ~30-60s.");
      startUploadVideoPolling([data.upload_video_id, ...uploadVideos.filter(v => v.video_status === "generating").map(v => v.upload_video_id)]);
    } catch (err) {
      toast.error("Failed: " + err.message);
    } finally {
      setIsUploadingVideo(false);
      if (uploadFileRef.current) uploadFileRef.current.value = "";
    }
  };

  const startUploadVideoPolling = (ids) => {
    if (uploadVideoPollingRef.current) clearInterval(uploadVideoPollingRef.current);
    uploadVideoPollingRef.current = setInterval(async () => {
      try {
        const resp = await fetch(`${API}/media/poll-upload-videos`, {
          method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
          body: JSON.stringify({ upload_video_ids: ids }),
        });
        if (!resp.ok) return;
        const data = await resp.json();
        if (data.results.length > 0) {
          setUploadVideos(prev => prev.map(v => {
            const update = data.results.find(u => u.upload_video_id === v.upload_video_id);
            return update ? { ...v, ...update } : v;
          }));
        }
        const allDone = data.results.every(r => r.video_status !== "generating");
        if (allDone && data.results.length > 0) {
          clearInterval(uploadVideoPollingRef.current);
          uploadVideoPollingRef.current = null;
          const completed = data.results.filter(r => r.video_status === "completed").length;
          if (completed > 0) toast.success(`${completed} upload video(s) completed!`);
          try { const ac = new (window.AudioContext || window.webkitAudioContext)(); const o = ac.createOscillator(); const g = ac.createGain(); o.connect(g); g.connect(ac.destination); o.frequency.value = 880; g.gain.value = 0.3; o.start(); o.stop(ac.currentTime + 0.3); } catch {}
        }
      } catch (err) { console.error("Upload video poll error:", err); }
    }, 8000);
  };

  // Load existing upload videos on mount
  useEffect(() => {
    (async () => {
      try {
        const r = await fetch(`${API}/media/upload-videos`, { credentials: "include" });
        if (r.ok) {
          const items = await r.json();
          setUploadVideos(items);
          const pending = items.filter(v => v.video_status === "generating").map(v => v.upload_video_id);
          if (pending.length > 0) startUploadVideoPolling(pending);
        }
      } catch {}
    })();
  }, []);

  const regenerateScene = async (result, idx) => {
    if (!selectedScript || !selectedStyleId) return;
    const hl = result.highlight;
    let charIds = hl?.characterIds || [];
    // No auto-detection — only use manually selected characters
    const refUrls = referenceImages.map(r => r.url);
    setBatchResults(prev => prev.map((r, i) => i === idx ? { ...r, status: "generating", image_url: null, error: null } : r));
    try {
      const r = await fetch(`${API}/media/generate`, {
        method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ script_id: selectedScript.script_id, selected_text: hl?.text || '', style_id: selectedStyleId, reference_image_urls: refUrls, character_ids: charIds, camera_angle: hl?.cameraAngle || null, aspect_ratio: hl?.aspectRatio || "16:9" }),
      });
      if (r.ok) {
        const newResult = await r.json();
        setBatchResults(prev => prev.map((r, i) => i === idx ? { ...newResult, highlight: hl } : r));
        if (newResult.status === "completed") toast.success(`Scene ${idx + 1} regenerated`);
        else toast.error(`Scene ${idx + 1} failed: ${newResult.error || "Unknown error"}`);
      } else {
        setBatchResults(prev => prev.map((r, i) => i === idx ? { ...r, status: "failed", error: `Server error (${r.status})` } : r));
      }
    } catch (e) {
      toast.info(`Scene ${idx + 1} timed out — checking server in a few seconds...`);
      setBatchResults(prev => prev.map((r, i) => i === idx ? { ...r, status: "recovering" } : r));
      await new Promise(r => setTimeout(r, 8000));
      try {
        const genResp = await fetch(`${API}/media/generations`, { credentials: "include" });
        if (genResp.ok) {
          const allGens = await genResp.json();
          const match = allGens.find(g => g.selected_text === (hl?.text || '') && g.script_id === selectedScript.script_id);
          if (match) {
            setBatchResults(prev => prev.map((r, i) => i === idx ? { ...match, highlight: hl } : r));
            if (match.status === "completed") toast.success(`Scene ${idx + 1} recovered from server`);
            return;
          }
        }
      } catch {}
      setBatchResults(prev => prev.map((r, i) => i === idx ? { ...r, status: "failed", error: "Timed out — check History" } : r));
    }
  };

  return (
    <Layout breadcrumbs={[{ label: "Projects", href: "/dashboard" }, { label: "Script to Media" }]}>
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")} data-testid="back-to-dashboard"><ArrowLeft className="w-4 h-4" /></Button>
          <div>
            <h1 className="text-xl font-bold text-slate-900" data-testid="page-title">Script to Media</h1>
            <p className="text-xs text-slate-500">Character-driven scene generation</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => { fetchGenerations(); setHistoryOpen(true); }} data-testid="history-btn"><History className="w-4 h-4 mr-1.5" />History</Button>
          {isGenerating ? (
            <div className="flex items-center gap-1.5">
              <Button size="sm" variant={isPaused ? "default" : "outline"} onClick={togglePause} data-testid="pause-resume-btn">{isPaused ? <><Play className="w-4 h-4 mr-1" />Resume</> : <><Pause className="w-4 h-4 mr-1" />Pause</>}</Button>
              <Button size="sm" variant="destructive" onClick={stopGeneration} data-testid="stop-btn"><Square className="w-4 h-4 mr-1" />Stop</Button>
              <Badge variant="secondary" className="font-mono text-xs" data-testid="timer"><Clock className="w-3 h-3 mr-1" />{estimatedRemaining !== null ? `~${formatTime(estimatedRemaining)} left` : formatTime(elapsedTime)}</Badge>
            </div>
          ) : (
            <Button onClick={startGeneration} disabled={!canGenerate} className="bg-slate-900 hover:bg-slate-800" data-testid="generate-btn"><Zap className="w-4 h-4 mr-1.5" />Generate All ({highlights.length})</Button>
          )}
        </div>
      </div>

      <PipelineIndicator activeStep={activeStep} />

      <div className="flex gap-4 mt-3" style={{ height: "calc(100vh - 230px)" }}>
        {/* LEFT: Script Panel */}
        <div className="w-[320px] shrink-0 flex flex-col border border-slate-200 rounded-xl bg-white overflow-hidden" data-testid="script-panel">
          <div className="p-3 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900 truncate">{selectedScript ? selectedScript.name : "Select Script"}</h3>
            <Button variant="ghost" size="sm" onClick={() => setScriptDialogOpen(true)} data-testid="change-script-btn">{selectedScript ? "Change" : "Select"}</Button>
          </div>
          {selectedScript ? (
            <div className="flex-1 overflow-y-auto p-4">
              <p className="text-xs text-slate-500 mb-2">Select text to create scene blocks:</p>
              <div className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap cursor-text select-text" onMouseUp={handleTextSelection} dangerouslySetInnerHTML={{ __html: scriptContent }} data-testid="script-content-panel" />
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center"><button onClick={() => setScriptDialogOpen(true)} className="text-sm text-slate-400 hover:text-slate-600" data-testid="select-script-prompt">Click to select a script...</button></div>
          )}
        </div>

        {/* RIGHT: Pipeline panels in order */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-1">

          {/* 1. STYLE SELECTION (dropdown + manage button) */}
          <div className="border border-slate-200 rounded-xl bg-white p-4" data-testid="style-section">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-6 h-6 rounded-md bg-violet-600 flex items-center justify-center"><Palette className="w-3.5 h-3.5 text-white" /></div>
              <h3 className="text-sm font-semibold text-slate-900">Style</h3>
              <div className="ml-auto">
                <StylesMaster styles={styles} onAdd={addStyle} onUpdate={updateStyle} onDelete={deleteStyle} onRefresh={fetchStyles} isAdmin={isAdmin} />
              </div>
            </div>
            <Select value={selectedStyleId} onValueChange={setSelectedStyleId}>
              <SelectTrigger className="w-full" data-testid="style-dropdown"><SelectValue placeholder="Choose a style..." /></SelectTrigger>
              <SelectContent>{styles.map(s => (<SelectItem key={s.style_id} value={s.style_id}><span className="font-medium">{s.name}</span><span className="text-slate-400 ml-2 text-xs">{s.description?.slice(0, 40)}</span></SelectItem>))}</SelectContent>
            </Select>
          </div>

          {/* 2. CHARACTERS (text only — names and descriptions) */}
          <div className="border border-slate-200 rounded-xl bg-white p-4" data-testid="characters-section">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-md bg-rose-600 flex items-center justify-center"><Users className="w-3.5 h-3.5 text-white" /></div>
                <h3 className="text-sm font-semibold text-slate-900">Characters</h3>
                {characters.length > 0 && <Badge variant="secondary" className="text-xs">{characters.length}</Badge>}
              </div>
              <div className="flex gap-1.5">
                {characters.length > 0 && (
                  <Button size="sm" variant="ghost" className="h-7 text-xs text-red-500 hover:text-red-700 hover:bg-red-50" onClick={clearAllCharacters} data-testid="clear-all-chars-btn"><Trash2 className="w-3 h-3 mr-1" />Clear All</Button>
                )}
                <Button size="sm" className="h-7 text-xs" onClick={detectAllCharacters} disabled={detectingChars || !selectedScript} data-testid="detect-chars-btn">
                  {detectingChars ? <><Loader2 className="w-3 h-3 mr-1 animate-spin" />Detecting...</> : <><Brain className="w-3 h-3 mr-1" />Detect Characters</>}
                </Button>
              </div>
            </div>
            {characters.length === 0 && !detectingChars && <p className="text-xs text-slate-400">Click "Detect Characters" to find all characters in the script</p>}
            {characters.length > 0 && (
              <div className="space-y-1.5">
                {characters.map(c => {
                  const hasHeadshot = headshots.some(h => h.character_id === c.character_id && h.style_id === selectedStyleId);
                  return (
                  <div key={c.character_id} className="flex items-center gap-2 p-2 rounded-lg border border-slate-100 hover:border-slate-200 transition-colors" data-testid={`char-card-${c.character_id}`}>
                    <div className="flex-1 min-w-0">
                      {editingChar === c.character_id ? (
                        <div className="space-y-1.5">
                          <Input value={editCharForm.name} onChange={(e) => setEditCharForm({ ...editCharForm, name: e.target.value })} className="h-7 text-xs" />
                          <Input value={editCharForm.description} onChange={(e) => setEditCharForm({ ...editCharForm, description: e.target.value })} className="h-7 text-xs" />
                          <div className="flex gap-1">
                            <Button size="sm" className="h-6 text-[10px] px-2" onClick={() => updateCharacter(c.character_id, editCharForm)}><Check className="w-3 h-3 mr-1" />Save</Button>
                            <Button size="sm" variant="ghost" className="h-6 text-[10px] px-2" onClick={() => setEditingChar(null)}>Cancel</Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-slate-900">{c.name}</p>
                            <p className="text-[11px] text-slate-500 line-clamp-1">{c.description}</p>
                          </div>
                          {selectedStyleId && (
                            <button onClick={() => generateHeadshots([c.character_id], hasHeadshot)} className={`p-1.5 rounded-md shrink-0 transition-colors ${hasHeadshot ? "text-emerald-500 hover:text-emerald-700 hover:bg-emerald-50" : "text-violet-500 hover:text-violet-700 hover:bg-violet-50"}`} title={hasHeadshot ? "Regenerate headshot" : "Generate headshot"} data-testid={`gen-hs-${c.character_id}`}>
                              <Camera className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button onClick={() => { setEditingChar(c.character_id); setEditCharForm({ name: c.name, description: c.description }); }} className="p-1 text-slate-400 hover:text-slate-600 shrink-0" title="Edit"><Pencil className="w-3 h-3" /></button>
                          <button onClick={() => deleteCharacter(c.character_id)} className="p-1 text-slate-400 hover:text-red-500 shrink-0" title="Remove"><Trash2 className="w-3 h-3" /></button>
                        </div>
                      )}
                    </div>
                  </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* 3. REFERENCE IMAGES — headshots + uploaded references */}
          <div className="border border-slate-200 rounded-xl bg-white p-4" data-testid="references-section">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-md bg-teal-600 flex items-center justify-center"><ImageLucide className="w-3.5 h-3.5 text-white" /></div>
                <h3 className="text-sm font-semibold text-slate-900">Reference Images</h3>
                {(headshots.length + referenceImages.length) > 0 && <Badge variant="secondary" className="text-xs">{headshots.length + referenceImages.length}</Badge>}
              </div>
              <Button size="sm" variant="outline" className="h-7" onClick={() => refImgInputRef.current?.click()} data-testid="upload-ref-btn"><Upload className="w-3.5 h-3.5 mr-1" />Upload</Button>
              <input ref={refImgInputRef} type="file" accept="image/*" className="hidden" onChange={handleRefImageUpload} />
            </div>

            {/* Headshot generation progress */}
            {headshotProgress && headshotProgress.status === "generating" && (
              <div className="mb-3 p-2 bg-violet-50 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-violet-600" />
                  <span className="text-xs font-medium text-violet-700">{headshotProgress.label || "Generating headshots"}: {headshotProgress.completed}/{headshotProgress.total}</span>
                </div>
                <div className="w-full h-1.5 bg-violet-200 rounded-full overflow-hidden">
                  <div className="h-full bg-violet-600 rounded-full transition-all" style={{ width: `${headshotProgress.total ? (headshotProgress.completed / headshotProgress.total) * 100 : 0}%` }} />
                </div>
              </div>
            )}

            {/* Character selection for headshot generation */}
            {characters.length > 0 && selectedStyleId && (
              <div className="mb-3 p-3 bg-slate-50 rounded-lg border border-slate-200" data-testid="headshot-generator">
                <p className="text-xs font-semibold text-slate-700 mb-2">Generate Headshots</p>
                <p className="text-[11px] text-slate-500 mb-2">Select characters to generate 1:1 styled headshots as references:</p>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {characters.map(c => {
                    const isSelected = selectedCharIdsForHeadshot.has(c.character_id);
                    const hasHeadshot = headshots.some(h => h.character_id === c.character_id && h.style_id === selectedStyleId);
                    return (
                      <button key={c.character_id} onClick={() => {
                        setSelectedCharIdsForHeadshot(prev => {
                          const next = new Set(prev);
                          if (next.has(c.character_id)) next.delete(c.character_id);
                          else next.add(c.character_id);
                          return next;
                        });
                      }}
                        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all border ${isSelected ? "bg-teal-50 border-teal-400 text-teal-700 shadow-sm" : hasHeadshot ? "bg-emerald-50 border-emerald-200 text-emerald-600" : "bg-white border-slate-200 text-slate-600 hover:border-slate-300"}`}
                        data-testid={`select-char-hs-${c.character_id}`}
                      >
                        {hasHeadshot && <Check className="w-3 h-3" />}
                        {c.name}
                      </button>
                    );
                  })}
                </div>
                <div className="flex gap-2">
                  <Button size="sm" className="h-7 text-xs" disabled={selectedCharIdsForHeadshot.size === 0 || !!headshotBatchId}
                    onClick={() => generateHeadshots([...selectedCharIdsForHeadshot])} data-testid="generate-headshots-btn">
                    {headshotBatchId ? <><Loader2 className="w-3 h-3 mr-1 animate-spin" />Generating...</> : <><Camera className="w-3 h-3 mr-1" />Generate Headshots ({selectedCharIdsForHeadshot.size})</>}
                  </Button>
                  {selectedCharIdsForHeadshot.size < characters.length && (
                    <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => setSelectedCharIdsForHeadshot(new Set(characters.map(c => c.character_id)))}>Select All</Button>
                  )}
                  {selectedCharIdsForHeadshot.size > 0 && (
                    <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => setSelectedCharIdsForHeadshot(new Set())}>Clear</Button>
                  )}
                </div>
              </div>
            )}
            {characters.length > 0 && !selectedStyleId && (
              <p className="text-xs text-amber-600 mb-3 p-2 bg-amber-50 rounded-lg">Select a style above to generate character headshots</p>
            )}

            {/* Generated headshots */}
            {headshots.filter(h => h.style_id === selectedStyleId).length > 0 && (
              <div className="mb-3">
                <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide mb-2">Character Headshots</p>
                <div className="flex gap-3 flex-wrap">
                  {headshots.filter(h => h.style_id === selectedStyleId).map(h => (
                    <div key={h.headshot_id} className="text-center" data-testid={`headshot-${h.headshot_id}`}>
                      <div className="w-20 h-20 rounded-lg overflow-hidden border-2 border-teal-300 bg-slate-100 cursor-pointer hover:opacity-90 transition-opacity"
                        onClick={() => setPreviewImage({ image_url: h.image_url, highlight: { text: h.character_name } })}>
                        <img src={`${BACKEND_URL}${h.image_url}`} alt={h.character_name} className="w-full h-full object-cover" loading="lazy" onError={handleImgError} />
                      </div>
                      <p className="text-[10px] font-medium text-slate-700 mt-1 max-w-[80px] truncate">{h.character_name}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Uploaded reference images */}
            {referenceImages.length > 0 && (
              <div>
                <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide mb-2">Uploaded References</p>
                <div className="flex gap-2 flex-wrap">{referenceImages.map((img, i) => (
                  <div key={i} className="relative group" data-testid={`ref-img-${i}`}>
                    <img src={`${BACKEND_URL}${img.url}`} alt="" className="w-20 h-20 object-cover rounded-lg border border-slate-200" onError={handleImgError} />
                    <button onClick={() => setReferenceImages(p => p.filter((_, j) => j !== i))} className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><X className="w-3 h-3" /></button>
                  </div>
                ))}</div>
              </div>
            )}

            {headshots.filter(h => h.style_id === selectedStyleId).length === 0 && referenceImages.length === 0 && !selectedStyleId && (
              <p className="text-xs text-slate-400">Upload reference images or generate character headshots for visual consistency</p>
            )}
          </div>

          {/* 3. SCENE BLOCKS */}
          <div className="border border-slate-200 rounded-xl bg-white p-4" data-testid="scenes-section">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-6 h-6 rounded-md bg-amber-500 flex items-center justify-center"><Highlighter className="w-3.5 h-3.5 text-white" /></div>
              <h3 className="text-sm font-semibold text-slate-900">Scene Blocks</h3>
              {highlights.length > 0 && <Badge variant="secondary" className="text-xs">{highlights.length}</Badge>}
              {highlights.length > 0 && <Button size="sm" variant="ghost" className="ml-auto h-7 text-xs text-red-500 hover:text-red-700 hover:bg-red-50" onClick={() => { setHighlights([]); toast.success("All scenes cleared"); }} data-testid="clear-all-scenes-btn"><Trash2 className="w-3 h-3 mr-1" />Clear All</Button>}
            </div>
            {highlights.length === 0 && <p className="text-xs text-slate-400 mb-3">Highlight text from the script panel to create scene blocks</p>}
            {highlights.map((h, i) => (
              <div key={h.id} className={`mb-3 p-3 rounded-lg border transition-all ${currentHighlightIdx === i && isGenerating ? "border-amber-400 bg-amber-50 shadow-sm" : "border-slate-200"}`} data-testid={`scene-block-${i}`}>
                <div className="flex items-start gap-2 mb-2">
                  <span className="text-xs text-slate-400 font-mono mt-0.5 w-5 shrink-0">{i + 1}</span>
                  {editingHighlight === h.id ? (
                    <div className="flex-1 flex gap-1.5">
                      <Textarea value={editText} onChange={(e) => setEditText(e.target.value)} className="text-xs flex-1 min-h-[60px]" autoFocus />
                      <Button size="sm" className="h-7 px-2" onClick={saveEditHighlight}><Check className="w-3 h-3" /></Button>
                    </div>
                  ) : (
                    <>
                      <div className="flex-1 text-sm text-slate-700 line-clamp-3">{h.text}{h.isCustom && <Badge variant="outline" className="ml-1.5 text-[10px]">custom</Badge>}</div>
                      <button onClick={() => startEditHighlight(h)} className="p-1 text-slate-400 hover:text-slate-600" data-testid={`edit-scene-${i}`}><Pencil className="w-3 h-3" /></button>
                      <button onClick={() => removeHighlight(h.id)} className="p-1 text-slate-400 hover:text-red-500" data-testid={`remove-scene-${i}`}><X className="w-3 h-3" /></button>
                    </>
                  )}
                </div>
                <div className="flex items-center gap-2 ml-7 flex-wrap">
                  <Select value={h.cameraAngle || ""} onValueChange={(v) => setCameraAngle(h.id, v)}>
                    <SelectTrigger className="h-7 text-xs w-[140px]" data-testid={`camera-${i}`}><Camera className="w-3 h-3 mr-1 text-slate-400" /><SelectValue placeholder="Camera angle" /></SelectTrigger>
                    <SelectContent>{CAMERA_ANGLES.map(a => <SelectItem key={a} value={a} className="text-xs">{a}</SelectItem>)}</SelectContent>
                  </Select>
                  <Select value={h.aspectRatio || "16:9"} onValueChange={(v) => setAspectRatio(h.id, v)}>
                    <SelectTrigger className="h-7 text-xs w-[90px]" data-testid={`aspect-${i}`}><SelectValue placeholder="Ratio" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="16:9" className="text-xs">16:9</SelectItem>
                      <SelectItem value="9:16" className="text-xs">9:16</SelectItem>
                    </SelectContent>
                  </Select>
                  {characters.length > 0 && (
                    <div className="flex gap-1.5 flex-wrap">
                      {characters.map(c => {
                        const active = (h.characterIds || []).includes(c.character_id);
                        return (
                          <button key={c.character_id} onClick={() => toggleCharInScene(h.id, c.character_id)}
                            className={`px-2 py-1 rounded-lg text-[10px] font-medium transition-all border ${active ? "bg-rose-50 border-rose-300 text-rose-700 shadow-sm" : "bg-slate-50 border-slate-200 text-slate-500 hover:border-slate-300"}`}
                            data-testid={`toggle-char-${i}-${c.character_id}`}>
                            {c.name}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
                {isGenerating && currentHighlightIdx === i && (
                  <div className="ml-7 mt-1"><Badge variant="secondary" className="text-[10px]">{currentSubStep === "claude" ? "Generating prompt..." : "Generating image..."}</Badge></div>
                )}
              </div>
            ))}
            <div className="flex gap-2">
              <Input placeholder="Or type custom scene text..." value={customText} onChange={(e) => setCustomText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addCustomHighlight()} className="text-xs h-8" data-testid="custom-scene-input" />
              <Button size="sm" variant="outline" className="h-8 px-3" onClick={addCustomHighlight} disabled={!customText.trim()} data-testid="add-custom-scene-btn"><Plus className="w-3.5 h-3.5" /></Button>
            </div>
          </div>

          {/* GENERATION PROGRESS */}
          {isGenerating && (
            <div className="border border-blue-200 rounded-xl bg-blue-50/50 p-4" data-testid="generation-progress">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2"><Loader2 className="w-4 h-4 animate-spin text-blue-600" /><h3 className="text-sm font-semibold text-blue-900">Generating scene {currentHighlightIdx + 1} of {highlights.length}</h3></div>
                <Badge variant="secondary" className="font-mono text-xs"><Clock className="w-3 h-3 mr-1" />{formatTime(elapsedTime)}</Badge>
              </div>
              <div className="space-y-2">{highlights.map((h, i) => (
                <div key={h.id} className={`flex items-center gap-2 p-2 rounded-lg ${i === currentHighlightIdx ? "bg-white border border-blue-200 shadow-sm" : i < currentHighlightIdx ? "bg-emerald-50 border border-emerald-200" : "bg-slate-50 border border-slate-200"}`}>
                  <span className="text-xs font-mono text-slate-400 w-5">{i + 1}</span>
                  <div className="text-xs text-slate-700 flex-1 truncate">{h.text}</div>
                  {i < currentHighlightIdx && <Badge className="bg-emerald-500 text-[10px]">Done</Badge>}
                  {i === currentHighlightIdx && <div className="flex gap-0.5"><div className={`w-2 h-2 rounded-full ${currentSubStep === "claude" ? "bg-blue-500 animate-pulse" : "bg-emerald-500"}`} title="Text model" /><div className={`w-2 h-2 rounded-full ${currentSubStep === "nanoBanana" ? "bg-orange-500 animate-pulse" : "bg-slate-300"}`} title="Image model" /></div>}
                  {i > currentHighlightIdx && <Badge variant="outline" className="text-[10px]">Waiting</Badge>}
                </div>
              ))}</div>
            </div>
          )}

          {/* 5. OUTPUT */}
          {batchResults.length > 0 && (
            <div className="border border-slate-200 rounded-xl bg-white p-4" data-testid="output-section">
              <div className="flex items-center gap-2 mb-3 flex-wrap">
                <div className="w-6 h-6 rounded-md bg-slate-900 flex items-center justify-center"><ImageIcon className="w-3.5 h-3.5 text-white" /></div>
                <h3 className="text-sm font-semibold text-slate-900">Output</h3>
                <Badge variant="secondary" className="text-xs">{batchResults.filter(r => r.status === "completed").length}/{batchResults.length}</Badge>
                <div className="ml-auto flex items-center gap-2">
                  {batchResults.some(r => r.status === "completed" && r.generation_id) && !isGenerating && (
                    <>
                      <Button size="sm" variant="outline" className="h-7 text-xs opacity-50 cursor-not-allowed" disabled title="Video generation is temporarily disabled" data-testid="select-all-video-btn">
                        <SquareIcon className="w-3.5 h-3.5 mr-1" />Video (Paused)
                      </Button>
                    </>
                  )}
                  <Button size="sm" variant="outline" className="h-7 text-xs" onClick={downloadAll} disabled={!batchResults.some(r => r.image_url)} data-testid="download-all-btn">
                    <DownloadCloud className="w-3.5 h-3.5 mr-1" />Download All
                  </Button>
                  <Button size="sm" variant="ghost" className="h-7 text-xs text-red-500 hover:text-red-700 hover:bg-red-50" onClick={() => { setBatchResults([]); setSelectedForVideo(new Set()); toast.success("All outputs cleared"); }} data-testid="clear-all-outputs-btn">
                    <Trash2 className="w-3 h-3 mr-1" />Clear All
                  </Button>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {batchResults.map((result, i) => (
                  <div key={i} className={`border rounded-lg overflow-hidden relative ${selectedForVideo.has(i) ? "border-violet-400 ring-2 ring-violet-200" : "border-slate-200"}`} data-testid={`output-item-${i}`}>
                    {/* Selection checkbox overlay */}
                    {result.status === "completed" && result.generation_id && !isGenerating && (
                      <button onClick={() => toggleVideoSelection(i)} className={`absolute top-2 right-2 z-10 w-6 h-6 rounded flex items-center justify-center transition-colors ${selectedForVideo.has(i) ? "bg-violet-600 text-white" : "bg-white/80 text-slate-400 border border-slate-300 hover:border-violet-400"}`} data-testid={`video-select-${i}`}>
                        {selectedForVideo.has(i) && <Check className="w-4 h-4" />}
                      </button>
                    )}
                    <div className="p-2 border-b border-slate-100 bg-slate-50"><p className="text-xs text-slate-700 font-medium truncate">Scene {i + 1}: {result.highlight?.text?.slice(0, 50)}</p></div>
                    {result.status === "completed" && result.image_url ? (
                      <div>
                        <img src={`${BACKEND_URL}${result.image_url}`} alt="" className="w-full aspect-square object-cover cursor-pointer hover:opacity-90 transition-opacity" loading="lazy" onClick={() => setPreviewImage(result)} data-testid={`output-image-${i}`} onError={handleImgError} />
                        <div className="p-2 flex gap-1.5">
                          <button onClick={() => setPreviewImage(result)} className="flex items-center justify-center gap-1 px-3 py-1.5 border border-slate-200 rounded-md text-xs font-medium text-slate-700 hover:bg-slate-50" data-testid={`preview-${i}`}><Eye className="w-3 h-3" />Preview</button>
                          <a href={`${BACKEND_URL}${result.image_url}`} download={toFilename(result.highlight?.text || '', i)} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-1 flex-1 py-1.5 bg-slate-900 text-white rounded-md text-xs font-medium hover:bg-slate-800" data-testid={`download-${i}`}><Download className="w-3 h-3" />Download</a>
                          <button onClick={() => regenerateScene(result, i)} disabled={isGenerating} className="flex items-center justify-center gap-1 px-3 py-1.5 border border-slate-200 rounded-md text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50" data-testid={`regenerate-${i}`}><RefreshCw className="w-3 h-3" />Redo</button>
                        </div>
                        {/* Video section */}
                        {result.video_status === "generating" && (
                          <div className="p-2 border-t border-slate-100 bg-violet-50 flex items-center gap-2">
                            <Loader2 className="w-3.5 h-3.5 animate-spin text-violet-600" />
                            <span className="text-xs text-violet-700 font-medium">Generating video...</span>
                          </div>
                        )}
                        {result.video_status === "completed" && result.video_url && (
                          <div className="border-t border-slate-100">
                            <video src={`${BACKEND_URL}${result.video_url}`} controls className="w-full" data-testid={`output-video-${i}`} />
                            <div className="p-2">
                              <a href={`${BACKEND_URL}${result.video_url}`} download={toFilename(result.highlight?.text || '', i).replace('.png', '.mp4')} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-1 w-full py-1.5 bg-violet-600 text-white rounded-md text-xs font-medium hover:bg-violet-700" data-testid={`download-video-${i}`}><Video className="w-3 h-3" />Download Video</a>
                            </div>
                          </div>
                        )}
                        {result.video_status === "failed" && (
                          <div className="p-2 border-t border-slate-100 bg-red-50"><p className="text-[10px] text-red-500">Video failed: {result.video_error || "Unknown error"}</p></div>
                        )}
                      </div>
                    ) : result.status === "failed" ? (
                      <div className="p-4 text-center">
                        <p className="text-xs text-red-500 mb-2">{result.error || "Failed"}</p>
                        <button onClick={() => regenerateScene(result, i)} disabled={isGenerating} className="text-xs text-blue-600 hover:underline" data-testid={`retry-${i}`}>Retry</button>
                      </div>
                    ) : result.status === "generating" ? (
                      <div className="p-4 flex justify-center"><Loader2 className="w-5 h-5 animate-spin text-blue-500" /></div>
                    ) : result.status === "recovering" ? (
                      <div className="p-4 text-center"><Loader2 className="w-5 h-5 animate-spin text-amber-500 mx-auto mb-1" /><p className="text-xs text-amber-600">Recovering from server...</p></div>
                    ) : <div className="p-4 flex justify-center"><Loader2 className="w-5 h-5 animate-spin text-slate-400" /></div>}
                    {result.image_prompt && <div className="p-2 border-t border-slate-100"><p className="text-[10px] text-slate-500 line-clamp-2">{result.image_prompt}</p></div>}
                    {result.model_used && <div className="px-2 pb-1.5"><Badge variant="outline" className="text-[9px] font-mono" data-testid={`model-badge-${i}`}>{result.model_used}</Badge></div>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 6. UPLOAD IMAGE → VIDEO (DISABLED) */}
          <div className="border border-slate-200 rounded-xl bg-slate-50 p-4 opacity-60" data-testid="upload-video-section">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-6 h-6 rounded-md bg-slate-400 flex items-center justify-center"><Video className="w-3.5 h-3.5 text-white" /></div>
              <h3 className="text-sm font-semibold text-slate-500">Upload Image → Video</h3>
              <Badge variant="secondary" className="text-xs">Paused</Badge>
            </div>
            <p className="text-xs text-slate-400">Video generation (Veo 3) is temporarily disabled. Previously generated videos are still available in History.</p>
            {uploadVideos.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mt-3">
                {uploadVideos.map((item) => (
                  <div key={item.upload_video_id} className="border border-slate-200 rounded-lg overflow-hidden" data-testid={`upload-video-item-${item.upload_video_id}`}>
                    {item.video_status === "completed" && item.video_url && (
                      <div>
                        <video src={`${BACKEND_URL}${item.video_url}`} controls className="w-full" />
                        <div className="p-2">
                          <a href={`${BACKEND_URL}${item.video_url}`} download={`video_${item.upload_video_id}.mp4`} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-1 w-full py-1.5 bg-violet-600 text-white rounded-md text-xs font-medium hover:bg-violet-700"><Download className="w-3 h-3" />Download Video</a>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* DIALOGS */}
      <Dialog open={scriptDialogOpen} onOpenChange={setScriptDialogOpen}>
        <DialogContent className="max-w-lg"><DialogHeader><DialogTitle>Select a Script</DialogTitle><DialogDescription>Choose a script to generate media from</DialogDescription></DialogHeader>
          <div className="max-h-[400px] overflow-y-auto space-y-1">
            {scripts.length === 0 ? <p className="text-sm text-slate-500 text-center py-6">No scripts found.</p> : scripts.map(s => (
              <button key={s.script_id} onClick={() => handleSelectScript(s)} className="w-full text-left px-3 py-2.5 rounded-lg hover:bg-slate-50" data-testid={`pick-script-${s.script_id}`}>
                <div className="flex items-center gap-2"><FileText className="w-4 h-4 text-slate-400" /><div className="min-w-0 flex-1"><p className="text-sm font-medium text-slate-900 truncate">{s.name}</p><p className="text-xs text-slate-500">{s.project_name}</p></div></div>
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={historyOpen} onOpenChange={setHistoryOpen}>
        <DialogContent className="max-w-4xl"><DialogHeader><DialogTitle>Generation History</DialogTitle><DialogDescription>Past image and video generations — click to download</DialogDescription></DialogHeader>
          <ScrollArea className="max-h-[600px]"><div className="space-y-3">
            {generations.length === 0 ? <p className="text-sm text-slate-500 text-center py-6">No generations yet.</p> : generations.map(gen => (
              <div key={gen.generation_id} className="border border-slate-200 rounded-lg overflow-hidden">
                <div className="flex gap-3 p-3">
                  {gen.image_url && (
                    <div className="shrink-0 cursor-pointer" onClick={() => { setPreviewImage(gen); setHistoryOpen(false); }}>
                      <img src={`${BACKEND_URL}${gen.image_url}`} alt="" className="w-28 h-28 object-cover rounded-md border hover:opacity-90 transition-opacity" loading="lazy" onError={handleImgError} />
                    </div>
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <Badge variant={gen.status === "completed" ? "default" : "destructive"} className="text-xs">{gen.status}</Badge>
                      <span className="text-xs text-slate-500">{gen.style_name}</span>
                      {gen.camera_angle && <span className="text-xs text-slate-400">{gen.camera_angle}</span>}
                      {gen.model_used && <Badge variant="outline" className="text-[9px] font-mono">{gen.model_used}</Badge>}
                      {gen.video_status === "completed" && <Badge variant="secondary" className="text-[9px] bg-violet-100 text-violet-700">Video Ready</Badge>}
                    </div>
                    <p className="text-sm text-slate-700 line-clamp-2 mb-1">"{gen.selected_text}"</p>
                    <p className="text-xs text-slate-400 mb-2">{new Date(gen.created_at).toLocaleString()}</p>
                    <div className="flex gap-2 flex-wrap">
                      {gen.image_url && (
                        <a href={`${BACKEND_URL}${gen.image_url}`} download={toFilename(gen.selected_text || '', 0)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-900 text-white rounded text-xs font-medium hover:bg-slate-800" data-testid={`history-download-img-${gen.generation_id}`}>
                          <Download className="w-3 h-3" />Image
                        </a>
                      )}
                      {gen.video_url && (
                        <a href={`${BACKEND_URL}${gen.video_url}`} download={toFilename(gen.selected_text || '', 0).replace('.png', '.mp4')} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 px-2.5 py-1 bg-violet-600 text-white rounded text-xs font-medium hover:bg-violet-700" data-testid={`history-download-vid-${gen.generation_id}`}>
                          <Video className="w-3 h-3" />Video
                        </a>
                      )}
                    </div>
                  </div>
                </div>
                {gen.video_url && (
                  <div className="border-t border-slate-100 p-2">
                    <video src={`${BACKEND_URL}${gen.video_url}`} controls className="w-full rounded" style={{ maxHeight: "200px" }} />
                  </div>
                )}
              </div>
            ))}
          </div></ScrollArea>
        </DialogContent>
      </Dialog>

      {/* IMAGE PREVIEW MODAL */}
      <Dialog open={!!previewImage} onOpenChange={(open) => !open && setPreviewImage(null)}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden bg-black/95 border-slate-700" data-testid="image-preview-modal">
          <DialogHeader className="sr-only"><DialogTitle>Image Preview</DialogTitle></DialogHeader>
          <div className="relative">
            <button onClick={() => setPreviewImage(null)} className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black/80 transition-colors" data-testid="close-preview-btn"><X className="w-4 h-4" /></button>
            {previewImage?.image_url && (
              <img src={`${BACKEND_URL}${previewImage.image_url}`} alt="" className="w-full max-h-[75vh] object-contain" data-testid="preview-image-full" onError={handleImgError} />
            )}
            <div className="p-4 bg-slate-900">
              {previewImage?.highlight?.text && <p className="text-sm text-slate-300 mb-2 line-clamp-2">"{previewImage.highlight.text}"</p>}
              {previewImage?.selected_text && !previewImage?.highlight?.text && <p className="text-sm text-slate-300 mb-2 line-clamp-2">"{previewImage.selected_text}"</p>}
              {previewImage?.image_prompt && <p className="text-xs text-slate-500 mb-3 line-clamp-3">{previewImage.image_prompt}</p>}
              <div className="flex gap-2 items-center flex-wrap">
                {previewImage?.image_url && (
                  <a href={`${BACKEND_URL}${previewImage.image_url}`} download={toFilename(previewImage?.highlight?.text || previewImage?.selected_text || '', 0)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 px-4 py-2 bg-white text-slate-900 rounded-lg text-sm font-medium hover:bg-slate-100 transition-colors" data-testid="preview-download-btn"><Download className="w-4 h-4" />Download Image</a>
                )}
                {previewImage?.video_url && (
                  <a href={`${BACKEND_URL}${previewImage.video_url}`} download target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 px-4 py-2 bg-violet-600 text-white rounded-lg text-sm font-medium hover:bg-violet-700 transition-colors" data-testid="preview-download-video-btn"><Video className="w-4 h-4" />Download Video</a>
                )}
                {previewImage?.model_used && <Badge variant="outline" className="text-[10px] font-mono border-slate-600 text-slate-400">{previewImage.model_used}</Badge>}
                {previewImage?.style_name && <span className="text-xs text-slate-500">{previewImage.style_name}</span>}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default ScriptToMediaPage;
