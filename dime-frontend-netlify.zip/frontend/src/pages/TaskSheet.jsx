import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Layout } from "../components/Layout";
import { API, useAuth } from "../App";
import { toast } from "sonner";
import { 
  Search, Filter, Paperclip, ArrowUpDown, X, ExternalLink,
  Trash2, Download, CheckCircle, Clock, CircleDashed, XCircle, Pause,
  Image, Volume2, Link as LinkIcon, FileText
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "../components/ui/select";
import {
  useReactTable, getCoreRowModel, getFilteredRowModel, getSortedRowModel, flexRender,
} from "@tanstack/react-table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "../components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "../components/ui/alert-dialog";
import { Checkbox } from "../components/ui/checkbox";
import * as XLSX from "xlsx";

const STAGE_STATUSES = [
  { value: "pending", label: "Pending" },
  { value: "hold", label: "Hold" },
  { value: "rejected", label: "Rejected" },
  { value: "done", label: "Done" },
];
const stageLabel = (val) => STAGE_STATUSES.find(s => s.value === val)?.label || "Pending";

export const TaskSheetPage = () => {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [project, setProject] = useState(null);
  const [scripts, setScripts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [teamMembers, setTeamMembers] = useState([]);
  const [workflowStages, setWorkflowStages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sorting, setSorting] = useState([]);
  const [globalFilter, setGlobalFilter] = useState("");
  const [attachmentsDialog, setAttachmentsDialog] = useState(null);
  const [attachments, setAttachments] = useState([]);
  const [rowSelection, setRowSelection] = useState({});
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const canEdit = user?.role === "admin" || user?.role === "editor";

  const [filters, setFilters] = useState({
    script_id: "", assigned_to: "", category_id: "", status_id: "",
  });
  const [doneByFilter, setDoneByFilter] = useState(false);

  useEffect(() => { fetchData(); }, [projectId]);
  // Only refetch from API when these filters change (assigned_to is client-side only)
  useEffect(() => { fetchTasks(); }, [filters.script_id, filters.category_id, filters.status_id, globalFilter, projectId]);

  const fetchData = async () => {
    try {
      const [catRes, statusRes, memberRes, stageRes] = await Promise.all([
        fetch(`${API}/categories`, { credentials: "include" }),
        fetch(`${API}/statuses`, { credentials: "include" }),
        fetch(`${API}/team-members`, { credentials: "include" }),
        fetch(`${API}/workflow-stages`, { credentials: "include" }),
      ]);
      if (catRes.ok) setCategories(await catRes.json());
      if (statusRes.ok) setStatuses(await statusRes.json());
      if (memberRes.ok) setTeamMembers(await memberRes.json());
      if (stageRes.ok) setWorkflowStages(await stageRes.json());

      if (projectId) {
        const [projRes, scriptsRes] = await Promise.all([
          fetch(`${API}/projects/${projectId}`, { credentials: "include" }),
          fetch(`${API}/projects/${projectId}/scripts`, { credentials: "include" }),
        ]);
        if (projRes.ok) setProject(await projRes.json());
        if (scriptsRes.ok) setScripts(await scriptsRes.json());
      } else {
        const projRes = await fetch(`${API}/projects`, { credentials: "include" });
        if (projRes.ok) {
          const projs = await projRes.json();
          const allScripts = [];
          for (const p of projs) {
            const r = await fetch(`${API}/projects/${p.project_id}/scripts`, { credentials: "include" });
            if (r.ok) allScripts.push(...(await r.json()));
          }
          setScripts(allScripts);
        }
      }
    } catch (error) {
      console.error("Failed to fetch data:", error);
    }
  };

  const fetchTasks = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (projectId) params.append("project_id", projectId);
      if (filters.script_id) params.append("script_id", filters.script_id);
      // NOTE: assigned_to filter is handled client-side in filteredTasks useMemo
      // because it needs to check stage_assignments which backend doesn't support
      if (filters.category_id) params.append("category_id", filters.category_id);
      if (filters.status_id) params.append("status_id", filters.status_id);
      if (globalFilter) params.append("search", globalFilter);
      const response = await fetch(`${API}/tasks?${params}`, { credentials: "include" });
      if (response.ok) setTasks(await response.json());
    } catch (error) {
      toast.error("Failed to fetch tasks");
    } finally {
      setLoading(false);
    }
  };

  const fetchAttachments = async (taskId) => {
    try {
      const response = await fetch(`${API}/tasks/${taskId}/attachments`, { credentials: "include" });
      if (response.ok) setAttachments(await response.json());
    } catch (error) {
      console.error("Failed to fetch attachments:", error);
    }
  };

  const deleteSelectedTasks = async () => {
    const selectedIds = Object.keys(rowSelection).filter(key => rowSelection[key]);
    const selectedTasks = selectedIds.map(index => tasks[parseInt(index)]).filter(Boolean);
    if (selectedTasks.length === 0) return;
    try {
      let deleted = 0;
      for (const task of selectedTasks) {
        const r = await fetch(`${API}/tasks/${task.task_id}`, { method: "DELETE", credentials: "include" });
        if (r.ok) {
          deleted++;
          if (task.script_id && task.selected_text) {
            try {
              await fetch(`${API}/scripts/${task.script_id}/remove-highlight`, {
                method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
                body: JSON.stringify({ selected_text: task.selected_text }),
              });
            } catch (e) { /* ignore */ }
          }
        }
      }
      toast.success(`${deleted} task(s) deleted`);
      setRowSelection({});
      setDeleteConfirmOpen(false);
      fetchTasks();
    } catch (error) {
      toast.error("Failed to delete some tasks");
      fetchTasks();
    }
  };

  const selectedCount = Object.values(rowSelection).filter(Boolean).length;

  const updateStageStatus = useCallback(async (task, stageId, newStatus) => {
    try {
      const r = await fetch(`${API}/tasks/${task.task_id}/stage`, {
        method: "PUT", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ stage_id: stageId, status: newStatus }),
      });
      if (r.ok) {
        setTasks(prev => prev.map(t => {
          if (t.task_id !== task.task_id) return t;
          const updated = { ...t };
          const sa = { ...(updated.stage_assignments || {}) };
          sa[stageId] = { ...(sa[stageId] || {}), status: newStatus };
          updated.stage_assignments = sa;
          // Auto-calc final status - only consider stages with actual assignees
          const assignedStatuses = workflowStages
            .filter(ws => sa[ws.stage_id]?.assigned_to_name || sa[ws.stage_id]?.assigned_to)
            .map(ws => sa[ws.stage_id]?.status || "pending");
          if (assignedStatuses.length === 0) {
            const s = statuses.find(s => s.name.toLowerCase() === "pending");
            if (s) { updated.status_id = s.status_id; updated.status_name = "Pending"; }
          } else if (assignedStatuses.some(s => s === "rejected")) {
            const s = statuses.find(s => s.name.toLowerCase() === "rejected");
            if (s) { updated.status_id = s.status_id; updated.status_name = "Rejected"; }
          } else if (assignedStatuses.every(s => s === "done") && assignedStatuses.length > 0) {
            const s = statuses.find(s => s.name.toLowerCase() === "done");
            if (s) { updated.status_id = s.status_id; updated.status_name = "Done"; }
          } else if (assignedStatuses.some(s => s === "hold")) {
            const s = statuses.find(s => s.name.toLowerCase() === "hold");
            if (s) { updated.status_id = s.status_id; updated.status_name = "Hold"; }
          } else {
            const s = statuses.find(s => s.name.toLowerCase() === "pending");
            if (s) { updated.status_id = s.status_id; updated.status_name = "Pending"; }
          }
          return updated;
        }));
        toast.success("Updated");
      } else {
        const err = await r.json();
        toast.error(err.detail || "Failed to update");
      }
    } catch (error) {
      toast.error("Failed to update");
    }
  }, [statuses, workflowStages]);

  const filteredTasks = useMemo(() => {
    let result = tasks;
    if (filters.script_id) result = result.filter(t => t.script_id === filters.script_id);
    if (filters.category_id) result = result.filter(t => t.category_id === filters.category_id);
    if (filters.status_id) result = result.filter(t => t.status_id === filters.status_id);
    if (filters.assigned_to) result = result.filter(t => {
      if (t.assigned_to === filters.assigned_to) return true;
      const sa = t.stage_assignments || {};
      return Object.values(sa).some(a => a.assigned_to === filters.assigned_to);
    });
    if (doneByFilter && filters.assigned_to) {
      result = result.filter(t => {
        const sa = t.stage_assignments || {};
        return Object.values(sa).some(a => a.assigned_to === filters.assigned_to && a.status === "done");
      });
    }
    return result;
  }, [tasks, filters, doneByFilter]);

  const taskStats = useMemo(() => {
    const stats = { total: filteredTasks.length, pending: 0, hold: 0, rejected: 0, done: 0 };
    filteredTasks.forEach(task => {
      const name = task.status_name?.toLowerCase() || "";
      if (name === "done" || name === "completed") stats.done++;
      else if (name === "hold") stats.hold++;
      else if (name === "rejected") stats.rejected++;
      else stats.pending++;
    });
    return stats;
  }, [filteredTasks]);

  const exportToExcel = () => {
    if (tasks.length === 0) { toast.error("No tasks to export"); return; }
    const exportData = tasks.map(task => {
      const row = {
        ...(projectId ? {} : { "Project": task.project_name || "-" }),
        "Script": task.script_name || "-",
        "Highlight": task.selected_text,
        "Category": task.category_name || "-",
        "Description": task.description || "-",
        "Assigned By": task.assigned_by_name || "-",
      };
      workflowStages.forEach(ws => {
        const sa = task.stage_assignments?.[ws.stage_id] || {};
        row[`${ws.name} Person`] = sa.assigned_to_name || "-";
        row[`${ws.name} Status`] = stageLabel(sa.status);
      });
      row["Final Status"] = task.status_name || "Pending";
      return row;
    });
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(exportData);
    XLSX.utils.book_append_sheet(wb, ws, "Tasks");
    XLSX.writeFile(wb, `tasks_export_${new Date().toISOString().split('T')[0]}.xlsx`);
    toast.success("Exported");
  };

  const updateDescription = async (taskId, newDesc) => {
    try {
      const res = await fetch(`${API}/tasks/${taskId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ description: newDesc }),
      });
      if (res.ok) {
        setTasks(prev => prev.map(t => t.task_id === taskId ? { ...t, description: newDesc } : t));
        toast.success("Description saved");
      } else {
        toast.error("Failed to save");
      }
    } catch {
      toast.error("Failed to save");
    }
  };

  const InlineDescriptionCell = ({ task }) => {
    const [editing, setEditing] = useState(false);
    const [value, setValue] = useState(task.description || "");
    const inputRef = useRef(null);

    useEffect(() => { setValue(task.description || ""); }, [task.description]);
    useEffect(() => { if (editing && inputRef.current) inputRef.current.focus(); }, [editing]);

    const save = () => {
      setEditing(false);
      if (value !== (task.description || "")) {
        updateDescription(task.task_id, value);
      }
    };

    if (editing && canEdit) {
      return (
        <input
          ref={inputRef}
          className="w-full text-sm bg-white border border-blue-300 rounded px-1.5 py-0.5 outline-none focus:ring-1 focus:ring-blue-400"
          value={value}
          onChange={e => setValue(e.target.value)}
          onBlur={save}
          onKeyDown={e => { if (e.key === "Enter") save(); if (e.key === "Escape") { setValue(task.description || ""); setEditing(false); } }}
          data-testid={`inline-desc-input-${task.task_id}`}
        />
      );
    }

    return (
      <span
        className={`text-slate-600 text-sm whitespace-nowrap ${canEdit ? "cursor-text" : ""}`}
        title={task.description || "Double-click to edit"}
        onDoubleClick={() => canEdit && setEditing(true)}
        data-testid={`inline-desc-${task.task_id}`}
      >
        {(task.description || "-").slice(0, 50)}{(task.description || "").length > 50 ? "..." : ""}
      </span>
    );
  };

  const columns = useMemo(() => {
    const cols = [
      {
        id: "select",
        header: ({ table }) => canEdit ? <Checkbox checked={table.getIsAllPageRowsSelected()} onCheckedChange={(v) => table.toggleAllPageRowsSelected(!!v)} /> : null,
        cell: ({ row }) => canEdit ? <Checkbox checked={row.getIsSelected()} onCheckedChange={(v) => row.toggleSelected(!!v)} /> : null,
        enableSorting: false, size: 36,
      },
    ];

    if (!projectId) {
      cols.push({
        accessorKey: "project_name",
        header: ({ column }) => <button onClick={() => column.toggleSorting(column.getIsSorted() === "asc")} className="flex items-center gap-1 font-medium whitespace-nowrap">Project <ArrowUpDown className="w-3 h-3" /></button>,
        cell: ({ row }) => <span className="text-slate-900 font-medium text-sm whitespace-nowrap">{row.original.project_name || "-"}</span>,
        size: 120,
      });
    }

    cols.push(
      {
        accessorKey: "script_name", header: "Script",
        cell: ({ row }) => (
          <button
            onClick={() => navigate(`/scripts/${row.original.script_id}`)}
            className="text-blue-600 hover:text-blue-800 hover:underline text-sm whitespace-nowrap"
            data-testid={`script-link-${row.original.task_id}`}
          >
            {row.original.script_name || "-"}
          </button>
        ),
        size: 80,
      },
      {
        accessorKey: "selected_text", header: "Highlight",
        cell: ({ row }) => (
          <button
            onClick={() => navigate(`/scripts/${row.original.script_id}?highlight=${row.original.task_id}`)}
            className="text-amber-700 hover:text-amber-900 hover:underline text-xs whitespace-nowrap"
            title={row.original.selected_text}
            data-testid={`highlight-link-${row.original.task_id}`}
          >
            {row.original.selected_text.slice(0, 25)}{row.original.selected_text.length > 25 ? "..." : ""}
          </button>
        ),
        size: 110,
      },
      {
        accessorKey: "category_name", header: "Category",
        cell: ({ row }) => {
          const cat = categories.find(c => c.category_id === row.original.category_id);
          return <span className="px-2 py-0.5 rounded text-xs font-medium whitespace-nowrap" style={{ backgroundColor: cat?.bg_color || "#F1F5F9", color: cat?.text_color || "#374151", border: `1px solid ${cat?.border_color || "#E2E8F0"}` }}>{row.original.category_name || "-"}</span>;
        },
        size: 100,
      },
      {
        accessorKey: "description", header: "Description",
        cell: ({ row }) => <InlineDescriptionCell task={row.original} />,
        size: 220,
      },
      {
        accessorKey: "assigned_by_name", header: "Assigned By",
        cell: ({ row }) => <span className="text-slate-600 text-sm whitespace-nowrap">{row.original.assigned_by_name || "-"}</span>,
        size: 110,
      },
    );

    // Dynamic stage column - single "Assigned To" column
    cols.push({
      id: "assigned_stages",
      header: () => <span className="font-semibold text-xs whitespace-nowrap">Assigned To</span>,
      cell: ({ row }) => {
        const task = row.original;
        const sa = task.stage_assignments || {};
        const assigned = workflowStages.filter(ws => sa[ws.stage_id]?.assigned_to_name);

        if (assigned.length === 0) {
          return <span className="text-xs text-slate-400 whitespace-nowrap">Unassigned</span>;
        }

        return (
          <div className="space-y-1.5">
            {assigned.map(ws => {
              const a = sa[ws.stage_id];
              const shortLabel = ws.name.slice(0, 3).toUpperCase();
              return (
                <div key={ws.stage_id} className="flex items-center gap-2 whitespace-nowrap">
                  <span className="text-[10px] text-slate-500 font-medium w-[28px]">{shortLabel}</span>
                  <span className="text-xs text-slate-700 min-w-[65px]">{a.assigned_to_name}</span>
                  <Select value={a.status || "pending"} onValueChange={(v) => updateStageStatus(task, ws.stage_id, v)}>
                    <SelectTrigger className="w-24 h-7 text-[11px]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {STAGE_STATUSES.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              );
            })}
          </div>
        );
      },
      size: 260,
    });

    cols.push(
      {
        accessorKey: "status_name", header: "Final Status",
        cell: ({ row }) => {
          const name = row.original.status_name?.toLowerCase() || "pending";
          const styles = { done: "bg-green-50 text-green-700 border-green-200", pending: "bg-slate-50 text-slate-600 border-slate-200", rejected: "bg-red-50 text-red-600 border-red-200", hold: "bg-amber-50 text-amber-700 border-amber-200" };
          return <span className={`px-2 py-1 rounded text-xs font-medium border whitespace-nowrap ${styles[name] || styles.pending}`}>{row.original.status_name || "Pending"}</span>;
        },
        size: 90,
      },
      {
        accessorKey: "attachments_count", header: "Files",
        cell: ({ row }) => (
          <button onClick={() => { setAttachmentsDialog(row.original); fetchAttachments(row.original.task_id); }} className="flex items-center gap-1 text-slate-500 hover:text-slate-900 whitespace-nowrap">
            <Paperclip className="w-3.5 h-3.5" /><span className="text-xs">{row.original.attachments_count || 0}</span>
          </button>
        ),
        size: 50,
      },
    );

    return cols;
  }, [categories, canEdit, statuses, teamMembers, workflowStages, updateStageStatus, projectId, navigate]);

  const table = useReactTable({
    data: filteredTasks, columns,
    state: { sorting, globalFilter, rowSelection },
    onSortingChange: setSorting, onGlobalFilterChange: setGlobalFilter, onRowSelectionChange: setRowSelection,
    getCoreRowModel: getCoreRowModel(), getSortedRowModel: getSortedRowModel(), getFilteredRowModel: getFilteredRowModel(),
    enableRowSelection: canEdit,
  });

  const clearFilters = () => { setFilters({ script_id: "", assigned_to: "", category_id: "", status_id: "" }); setGlobalFilter(""); setDoneByFilter(false); };
  const hasActiveFilters = filters.script_id || filters.assigned_to || filters.category_id || filters.status_id || globalFilter;

  const breadcrumbs = projectId
    ? [{ label: "Projects", href: "/dashboard" }, { label: project?.name || "...", href: `/projects/${projectId}` }, { label: "Task Sheet" }]
    : [{ label: "Task Sheet" }];

  return (
    <Layout breadcrumbs={breadcrumbs}>
      <div className="page-header">
        <h1 className="page-title" data-testid="task-sheet-title">
          {project ? `${project.name} — Task Sheet` : "Task Sheet"}
        </h1>
        <div className="flex items-center gap-2">
          {canEdit && selectedCount > 0 && (
            <Button variant="destructive" onClick={() => setDeleteConfirmOpen(true)} data-testid="delete-selected-tasks-btn">
              <Trash2 className="w-4 h-4 mr-2" />Delete ({selectedCount})
            </Button>
          )}
          <Button variant="outline" onClick={exportToExcel} data-testid="export-excel-btn">
            <Download className="w-4 h-4 mr-2" />Export
          </Button>
        </div>
      </div>

      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Tasks</AlertDialogTitle>
            <AlertDialogDescription>Delete {selectedCount} task(s)? This cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={deleteSelectedTasks} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
        {[
          { icon: CircleDashed, color: "text-slate-500", val: taskStats.total, label: "Total", pct: null },
          { icon: Clock, color: "text-slate-400", val: taskStats.pending, label: "Pending", pct: taskStats.total ? Math.round((taskStats.pending / taskStats.total) * 100) : 0 },
          { icon: Pause, color: "text-amber-500", val: taskStats.hold, label: "Hold", pct: taskStats.total ? Math.round((taskStats.hold / taskStats.total) * 100) : 0 },
          { icon: XCircle, color: "text-red-500", val: taskStats.rejected, label: "Rejected", pct: taskStats.total ? Math.round((taskStats.rejected / taskStats.total) * 100) : 0 },
          { icon: CheckCircle, color: "text-green-500", val: taskStats.done, label: "Done", pct: taskStats.total ? Math.round((taskStats.done / taskStats.total) * 100) : 0 },
        ].map(({ icon: Icon, color, val, label, pct }) => (
          <div key={label} className="bg-white border border-slate-200 rounded-lg p-3" data-testid={`stat-${label.toLowerCase()}`}>
            <div className="flex items-center gap-2">
              <Icon className={`w-5 h-5 ${color}`} />
              <div>
                <p className="text-xl font-bold text-slate-900">
                  {val}
                  {pct !== null && <span className="text-xs font-normal text-slate-400 ml-1">({pct}%)</span>}
                </p>
                <p className="text-xs text-slate-500">{label}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <div className="flex items-center gap-2 text-sm text-slate-500"><Filter className="w-4 h-4" /><span>Filter:</span></div>
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input placeholder="Search..." value={globalFilter} onChange={(e) => setGlobalFilter(e.target.value)} className="pl-9" data-testid="search-tasks" />
        </div>
        <Select value={filters.script_id || "all"} onValueChange={(v) => setFilters({ ...filters, script_id: v === "all" ? "" : v })}>
          <SelectTrigger className="w-32" data-testid="filter-script"><SelectValue placeholder="Script" /></SelectTrigger>
          <SelectContent><SelectItem value="all">All Scripts</SelectItem>{scripts.map(s => <SelectItem key={s.script_id} value={s.script_id}>{s.name}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={filters.category_id || "all"} onValueChange={(v) => setFilters({ ...filters, category_id: v === "all" ? "" : v })}>
          <SelectTrigger className="w-32"><SelectValue placeholder="Category" /></SelectTrigger>
          <SelectContent><SelectItem value="all">All Categories</SelectItem>{categories.map(c => <SelectItem key={c.category_id} value={c.category_id}>{c.name}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={filters.status_id || "all"} onValueChange={(v) => setFilters({ ...filters, status_id: v === "all" ? "" : v })}>
          <SelectTrigger className="w-32"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent><SelectItem value="all">All Statuses</SelectItem>{statuses.map(s => <SelectItem key={s.status_id} value={s.status_id}>{s.name}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={filters.assigned_to || "all"} onValueChange={(v) => { setFilters({ ...filters, assigned_to: v === "all" ? "" : v }); if (v === "all") setDoneByFilter(false); }}>
          <SelectTrigger className="w-32"><SelectValue placeholder="Member" /></SelectTrigger>
          <SelectContent><SelectItem value="all">All Members</SelectItem>{teamMembers.map(m => <SelectItem key={m.member_id} value={m.member_id}>{m.name}</SelectItem>)}</SelectContent>
        </Select>
        {filters.assigned_to && (() => {
          const member = teamMembers.find(m => m.member_id === filters.assigned_to);
          return member ? (
            <label className="flex items-center gap-2 cursor-pointer" data-testid="done-by-toggle">
              <input
                type="checkbox"
                checked={doneByFilter}
                onChange={(e) => setDoneByFilter(e.target.checked)}
                className="w-4 h-4 rounded border-slate-300 text-green-600 focus:ring-green-500"
              />
              <span className="text-sm text-slate-600 whitespace-nowrap">Done by {member.name}</span>
            </label>
          ) : null;
        })()}
        {hasActiveFilters && <Button variant="ghost" size="sm" onClick={clearFilters}><X className="w-4 h-4 mr-1" /> Clear</Button>}
      </div>

      {/* Table */}
      <div className="border border-slate-200 rounded-lg overflow-x-auto">
        <table className="data-table" style={{ minWidth: "1200px" }}>
          <thead>
            {table.getHeaderGroups().map(hg => (
              <tr key={hg.id}>{hg.headers.map(h => (
                <th key={h.id} className="text-xs whitespace-nowrap" style={{ width: h.column.getSize() }}>
                  {h.isPlaceholder ? null : flexRender(h.column.columnDef.header, h.getContext())}
                </th>
              ))}</tr>
            ))}
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={columns.length} className="text-center py-8 text-slate-500">Loading...</td></tr>
            ) : table.getRowModel().rows.length === 0 ? (
              <tr><td colSpan={columns.length} className="text-center py-8 text-slate-500">No tasks found</td></tr>
            ) : (
              table.getRowModel().rows.map(row => (
                <tr key={row.id} data-testid={`task-row-${row.original.task_id}`}>
                  {row.getVisibleCells().map(cell => (
                    <td key={cell.id} className="align-middle py-2 px-3 whitespace-nowrap">
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={!!attachmentsDialog} onOpenChange={() => setAttachmentsDialog(null)}>
        <DialogContent className="max-w-lg" data-testid="attachments-dialog">
          <DialogHeader><DialogTitle>Attachments</DialogTitle></DialogHeader>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {attachments.length === 0 ? (
              <p className="text-slate-500 text-center py-4">No attachments</p>
            ) : attachments.map(att => {
              const gid = att.gdrive_file_id || (() => { const m = (att.url || "").match(/[?&]id=([a-zA-Z0-9_-]+)/); return m ? m[1] : null; })();
              const resolveUrl = (variant) => {
                if (att.type === "link") return att.url;
                if (gid) {
                  if (variant === "thumbnail") return `https://drive.google.com/thumbnail?id=${gid}&sz=w400`;
                  if (variant === "full") return `${API}/drive/stream/${gid}`;
                  if (variant === "download") return `https://drive.google.com/uc?id=${gid}&export=download`;
                  if (variant === "audio") return `${API}/drive/stream/${gid}`;
                  return `${API}/drive/stream/${gid}`;
                }
                if (att.url && att.url.startsWith("http")) return att.url;
                return `${process.env.REACT_APP_BACKEND_URL}${att.url}`;
              };

              return (
                <div key={att.attachment_id} className="border border-slate-200 rounded-lg overflow-hidden" data-testid={`tasksheet-attachment-${att.attachment_id}`}>
                  {att.type === "image" ? (
                    <div>
                      <a href={resolveUrl("full")} target="_blank" rel="noreferrer" className="block">
                        <img src={resolveUrl("thumbnail")} alt={att.filename || "Image"} className="w-full max-h-48 object-contain bg-slate-100 cursor-pointer hover:opacity-90 transition-opacity" />
                      </a>
                      <div className="flex items-center justify-between p-2 bg-white border-t border-slate-100">
                        <div className="flex items-center gap-2 min-w-0">
                          <Image className="w-4 h-4 text-slate-400 shrink-0" />
                          <span className="text-xs text-slate-600 truncate">{att.filename || "Image"}</span>
                        </div>
                        <a href={resolveUrl("download")} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-blue-600" title="Download">
                          <Download className="w-4 h-4" />
                        </a>
                      </div>
                    </div>
                  ) : att.type === "audio" ? (
                    <div className="p-3 bg-white">
                      <div className="flex items-center gap-2 mb-2">
                        <Volume2 className="w-4 h-4 text-slate-400 shrink-0" />
                        <span className="text-xs text-slate-600 truncate flex-1">{att.filename || "Audio"}</span>
                        <a href={resolveUrl("download")} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-blue-600 shrink-0" title="Download">
                          <Download className="w-4 h-4" />
                        </a>
                      </div>
                      <audio controls src={resolveUrl("audio")} className="w-full" />
                    </div>
                  ) : att.type === "link" ? (
                    <div className="flex items-center gap-3 p-3 bg-white">
                      <LinkIcon className="w-4 h-4 text-slate-400 shrink-0" />
                      <a href={att.url} target="_blank" rel="noreferrer" className="text-sm text-blue-600 hover:underline truncate flex-1">
                        {att.filename || att.url}
                      </a>
                      <a href={att.url} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-blue-600 shrink-0" title="Open">
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </div>
                  ) : (
                    <div className="flex items-center gap-3 p-3 bg-white">
                      <FileText className="w-4 h-4 text-slate-400 shrink-0" />
                      <span className="text-sm text-slate-600 truncate flex-1">{att.filename || att.url}</span>
                      <a href={resolveUrl("download")} target="_blank" rel="noreferrer" className="text-slate-400 hover:text-blue-600 shrink-0" title="Download">
                        <Download className="w-4 h-4" />
                      </a>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>
    </Layout>
  );
};

export default TaskSheetPage;
