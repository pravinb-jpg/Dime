import { useState, useEffect } from "react";
import { Layout } from "../components/Layout";
import { API, useAuth } from "../App";
import { toast } from "sonner";
import { 
  Users, 
  Tags, 
  ListChecks, 
  Plus, 
  Pencil, 
  Trash2,
  Shield,
  Workflow,
  FolderOpen,
  X,
  Cpu,
  Save,
  Loader2,
  BarChart3,
  DollarSign,
  Zap,
  Image,
  MessageSquare,
  RefreshCw,
} from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../components/ui/tabs";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "../components/ui/alert-dialog";

export const AdminPage = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("team");
  
  // Team Members
  const [teamMembers, setTeamMembers] = useState([]);
  const [memberDialogOpen, setMemberDialogOpen] = useState(false);
  const [editingMember, setEditingMember] = useState(null);
  const [memberForm, setMemberForm] = useState({ name: "", email: "", role: "viewer", project_ids: [] });
  const [deleteMemberConfirm, setDeleteMemberConfirm] = useState(null);

  // All projects (for assignment)
  const [allProjects, setAllProjects] = useState([]);

  // Categories
  const [categories, setCategories] = useState([]);
  const [categoryDialogOpen, setCategoryDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [categoryForm, setCategoryForm] = useState({ 
    name: "", bg_color: "#DBEAFE", text_color: "#1E40AF", border_color: "#BFDBFE" 
  });
  const [deleteCategoryConfirm, setDeleteCategoryConfirm] = useState(null);

  // Statuses
  const [statuses, setStatuses] = useState([]);
  const [statusDialogOpen, setStatusDialogOpen] = useState(false);
  const [editingStatus, setEditingStatus] = useState(null);
  const [statusForm, setStatusForm] = useState({ name: "", order: 0 });
  const [deleteStatusConfirm, setDeleteStatusConfirm] = useState(null);

  // Workflow Stages
  const [workflowStages, setWorkflowStages] = useState([]);
  const [stageDialogOpen, setStageDialogOpen] = useState(false);
  const [editingStage, setEditingStage] = useState(null);
  const [stageForm, setStageForm] = useState({ name: "", order: 0 });
  const [deleteStageConfirm, setDeleteStageConfirm] = useState(null);

  // AI Settings
  const [aiSettings, setAiSettings] = useState({
    character_detection: "gemini",
    image_prompt_generation: "claude",
    scene_image_generation: "gemini",
    headshot_generation: "gemini",
  });
  const [savingAi, setSavingAi] = useState(false);

  // Analytics
  const [analyticsSummary, setAnalyticsSummary] = useState(null);
  const [analyticsDaily, setAnalyticsDaily] = useState([]);
  const [analyticsRecent, setAnalyticsRecent] = useState([]);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);
  const [analyticsPeriod, setAnalyticsPeriod] = useState("30");

  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = async () => {
    await Promise.all([fetchTeamMembers(), fetchCategories(), fetchStatuses(), fetchWorkflowStages(), fetchAllProjects(), fetchAiSettings()]);
  };

  const fetchAiSettings = async () => {
    try {
      const r = await fetch(`${API}/admin/ai-settings`, { credentials: "include" });
      if (r.ok) setAiSettings(await r.json());
    } catch (e) { console.error("Failed to fetch AI settings:", e); }
  };

  const fetchAnalytics = async (days = analyticsPeriod) => {
    setAnalyticsLoading(true);
    try {
      const [summaryRes, dailyRes, recentRes] = await Promise.all([
        fetch(`${API}/admin/analytics/summary?days=${days}`, { credentials: "include" }),
        fetch(`${API}/admin/analytics/daily?days=${days}`, { credentials: "include" }),
        fetch(`${API}/admin/analytics/recent?limit=50`, { credentials: "include" }),
      ]);
      if (summaryRes.ok) setAnalyticsSummary(await summaryRes.json());
      if (dailyRes.ok) setAnalyticsDaily(await dailyRes.json());
      if (recentRes.ok) setAnalyticsRecent(await recentRes.json());
    } catch (e) { console.error("Failed to fetch analytics:", e); }
    setAnalyticsLoading(false);
  };

  const saveAiSettings = async () => {
    setSavingAi(true);
    try {
      const r = await fetch(`${API}/admin/ai-settings`, {
        method: "PUT", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(aiSettings),
      });
      if (r.ok) { setAiSettings(await r.json()); toast.success("AI settings saved"); }
      else toast.error("Failed to save");
    } catch (e) { toast.error("Failed to save AI settings"); }
    setSavingAi(false);
  };

  // ======== Team Members ========
  const fetchTeamMembers = async () => {
    try {
      const response = await fetch(`${API}/team-members`, { credentials: "include" });
      if (response.ok) setTeamMembers(await response.json());
    } catch (error) {
      console.error("Failed to fetch team members:", error);
    }
  };

  const fetchAllProjects = async () => {
    try {
      const response = await fetch(`${API}/projects`, { credentials: "include" });
      if (response.ok) setAllProjects(await response.json());
    } catch (error) {
      console.error("Failed to fetch projects:", error);
    }
  };

  const saveMember = async (e) => {
    e.preventDefault();
    try {
      const url = editingMember 
        ? `${API}/team-members/${editingMember.member_id}`
        : `${API}/team-members`;
      
      const response = await fetch(url, {
        method: editingMember ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(memberForm),
      });

      if (response.ok) {
        toast.success(editingMember ? "Member updated" : "Member added");
        setMemberDialogOpen(false);
        setEditingMember(null);
        setMemberForm({ name: "", email: "", role: "viewer", project_ids: [] });
        fetchTeamMembers();
      } else {
        const error = await response.json();
        toast.error(error.detail || "Failed to save member");
      }
    } catch (error) {
      toast.error("Failed to save member");
    }
  };

  const deleteMember = async (memberId) => {
    try {
      const response = await fetch(`${API}/team-members/${memberId}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (response.ok) {
        toast.success("Member and user access deleted");
        fetchTeamMembers();
      }
    } catch (error) {
      toast.error("Failed to delete member");
    }
    setDeleteMemberConfirm(null);
  };

  const updateMemberRole = async (memberId, role) => {
    try {
      const response = await fetch(`${API}/team-members/${memberId}/role`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ role }),
      });

      if (response.ok) {
        toast.success("Role updated");
        fetchTeamMembers();
      } else {
        const error = await response.json();
        toast.error(error.detail || "Failed to update role");
      }
    } catch (error) {
      toast.error("Failed to update role");
    }
  };

  // ======== Categories ========
  const fetchCategories = async () => {
    try {
      const response = await fetch(`${API}/categories`, { credentials: "include" });
      if (response.ok) setCategories(await response.json());
    } catch (error) {
      console.error("Failed to fetch categories:", error);
    }
  };

  const saveCategory = async (e) => {
    e.preventDefault();
    try {
      const url = editingCategory 
        ? `${API}/categories/${editingCategory.category_id}`
        : `${API}/categories`;
      
      const response = await fetch(url, {
        method: editingCategory ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(categoryForm),
      });

      if (response.ok) {
        toast.success(editingCategory ? "Category updated" : "Category added");
        setCategoryDialogOpen(false);
        setEditingCategory(null);
        setCategoryForm({ name: "", bg_color: "#DBEAFE", text_color: "#1E40AF", border_color: "#BFDBFE" });
        fetchCategories();
      } else {
        const error = await response.json();
        toast.error(error.detail || "Failed to save category");
      }
    } catch (error) {
      toast.error("Failed to save category");
    }
  };

  const deleteCategory = async (categoryId) => {
    try {
      const response = await fetch(`${API}/categories/${categoryId}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (response.ok) {
        toast.success("Category deleted");
        fetchCategories();
      }
    } catch (error) {
      toast.error("Failed to delete category");
    }
    setDeleteCategoryConfirm(null);
  };

  // ======== Statuses ========
  const fetchStatuses = async () => {
    try {
      const response = await fetch(`${API}/statuses`, { credentials: "include" });
      if (response.ok) setStatuses(await response.json());
    } catch (error) {
      console.error("Failed to fetch statuses:", error);
    }
  };

  const saveStatus = async (e) => {
    e.preventDefault();
    try {
      const url = editingStatus 
        ? `${API}/statuses/${editingStatus.status_id}`
        : `${API}/statuses`;
      
      const response = await fetch(url, {
        method: editingStatus ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(statusForm),
      });

      if (response.ok) {
        toast.success(editingStatus ? "Status updated" : "Status added");
        setStatusDialogOpen(false);
        setEditingStatus(null);
        setStatusForm({ name: "", order: 0 });
        fetchStatuses();
      } else {
        const error = await response.json();
        toast.error(error.detail || "Failed to save status");
      }
    } catch (error) {
      toast.error("Failed to save status");
    }
  };

  const deleteStatus = async (statusId) => {
    try {
      const response = await fetch(`${API}/statuses/${statusId}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (response.ok) {
        toast.success("Status deleted");
        fetchStatuses();
      }
    } catch (error) {
      toast.error("Failed to delete status");
    }
    setDeleteStatusConfirm(null);
  };

  // ======== Workflow Stages ========
  const fetchWorkflowStages = async () => {
    try {
      const response = await fetch(`${API}/workflow-stages`, { credentials: "include" });
      if (response.ok) setWorkflowStages(await response.json());
    } catch (error) {
      console.error("Failed to fetch workflow stages:", error);
    }
  };

  const saveStage = async (e) => {
    e.preventDefault();
    try {
      const url = editingStage 
        ? `${API}/workflow-stages/${editingStage.stage_id}`
        : `${API}/workflow-stages`;
      
      const response = await fetch(url, {
        method: editingStage ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(stageForm),
      });

      if (response.ok) {
        toast.success(editingStage ? "Stage updated" : "Stage added");
        setStageDialogOpen(false);
        setEditingStage(null);
        setStageForm({ name: "", order: 0 });
        fetchWorkflowStages();
      } else {
        const error = await response.json();
        toast.error(error.detail || "Failed to save stage");
      }
    } catch (error) {
      toast.error("Failed to save stage");
    }
  };

  const deleteStage = async (stageId) => {
    try {
      const response = await fetch(`${API}/workflow-stages/${stageId}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (response.ok) {
        toast.success("Stage deleted");
        fetchWorkflowStages();
      }
    } catch (error) {
      toast.error("Failed to delete stage");
    }
    setDeleteStageConfirm(null);
  };

  const getRoleBadge = (role) => {
    const styles = {
      admin: "bg-red-50 text-red-700 border-red-200",
      editor: "bg-blue-50 text-blue-700 border-blue-200",
      viewer: "bg-slate-50 text-slate-600 border-slate-200",
    };
    return (
      <span className={`px-2 py-0.5 rounded text-xs font-medium border ${styles[role] || styles.viewer}`}>
        {role?.charAt(0).toUpperCase() + role?.slice(1)}
      </span>
    );
  };

  if (user?.role !== "admin") {
    return (
      <Layout breadcrumbs={[{ label: "Admin Settings" }]}>
        <div className="text-center py-16">
          <Shield className="w-12 h-12 text-slate-300 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-slate-900 mb-2">Access Denied</h2>
          <p className="text-slate-500">You need admin privileges to access this page.</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout breadcrumbs={[{ label: "Admin Settings" }]}>
      <div className="page-header">
        <h1 className="page-title" data-testid="admin-title">Admin Settings</h1>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="bg-slate-100 p-1 rounded-lg">
          <TabsTrigger value="team" className="data-[state=active]:bg-white rounded-md px-4 py-2">
            <Users className="w-4 h-4 mr-2" />
            Team Members
          </TabsTrigger>
          <TabsTrigger value="categories" className="data-[state=active]:bg-white rounded-md px-4 py-2">
            <Tags className="w-4 h-4 mr-2" />
            Categories
          </TabsTrigger>
          <TabsTrigger value="statuses" className="data-[state=active]:bg-white rounded-md px-4 py-2">
            <ListChecks className="w-4 h-4 mr-2" />
            Statuses
          </TabsTrigger>
          <TabsTrigger value="stages" className="data-[state=active]:bg-white rounded-md px-4 py-2">
            <Workflow className="w-4 h-4 mr-2" />
            Workflow Stages
          </TabsTrigger>
          <TabsTrigger value="ai" className="data-[state=active]:bg-white rounded-md px-4 py-2" data-testid="ai-settings-tab">
            <Cpu className="w-4 h-4 mr-2" />
            AI Settings
          </TabsTrigger>
          <TabsTrigger value="analytics" className="data-[state=active]:bg-white rounded-md px-4 py-2" data-testid="analytics-tab" onClick={() => { if (!analyticsSummary) fetchAnalytics(); }}>
            <BarChart3 className="w-4 h-4 mr-2" />
            Analytics
          </TabsTrigger>
        </TabsList>

        {/* Team Members Tab */}
        <TabsContent value="team" className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-slate-500 text-sm">
              Manage team members and their access roles. Members with email can log in to the app.
            </p>
            <Button onClick={() => { setEditingMember(null); setMemberForm({ name: "", email: "", role: "viewer", project_ids: [] }); setMemberDialogOpen(true); }} data-testid="add-member-btn">
              <Plus className="w-4 h-4 mr-2" />
              Add Member
            </Button>
          </div>

          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Projects</th>
                  <th className="w-24">Actions</th>
                </tr>
              </thead>
              <tbody>
                {teamMembers.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="text-center py-8 text-slate-500">No team members yet</td>
                  </tr>
                ) : (
                  teamMembers.map((member) => (
                    <tr key={member.member_id} data-testid={`member-row-${member.member_id}`}>
                      <td className="font-medium text-slate-900">{member.name}</td>
                      <td className="text-slate-600">{member.email || "-"}</td>
                      <td>
                        {member.email ? (
                          <Select
                            value={member.role || "viewer"}
                            onValueChange={(value) => updateMemberRole(member.member_id, value)}
                          >
                            <SelectTrigger className="w-32 h-8" data-testid={`role-select-${member.member_id}`}>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="admin">Admin</SelectItem>
                              <SelectItem value="editor">Editor</SelectItem>
                              <SelectItem value="viewer">Viewer</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : (
                          <span className="text-slate-400 text-sm">No email</span>
                        )}
                      </td>
                      <td>
                        <div className="flex flex-wrap gap-1">
                          {(member.project_ids || []).length === 0 ? (
                            <span className="text-xs text-slate-400">{member.role === "admin" ? "All (admin)" : "None"}</span>
                          ) : (
                            (member.project_ids || []).map(pid => {
                              const proj = allProjects.find(p => p.project_id === pid);
                              return proj ? (
                                <span key={pid} className="px-1.5 py-0.5 bg-slate-100 text-slate-600 text-xs rounded">
                                  {proj.name}
                                </span>
                              ) : null;
                            })
                          )}
                        </div>
                      </td>
                      <td>
                        <div className="flex gap-1">
                          <button 
                            onClick={() => { setEditingMember(member); setMemberForm({ name: member.name, email: member.email || "", role: member.role || "viewer", project_ids: member.project_ids || [] }); setMemberDialogOpen(true); }}
                            className="btn-icon"
                            data-testid={`edit-member-${member.member_id}`}
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => setDeleteMemberConfirm(member)}
                            className="btn-icon text-red-500 hover:text-red-700"
                            data-testid={`delete-member-${member.member_id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>

        {/* Categories Tab */}
        <TabsContent value="categories" className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-slate-500 text-sm">
              Categories are used to classify tasks. Each category has a color for highlighting text.
            </p>
            <Button onClick={() => { setEditingCategory(null); setCategoryForm({ name: "", bg_color: "#DBEAFE", text_color: "#1E40AF", border_color: "#BFDBFE" }); setCategoryDialogOpen(true); }} data-testid="add-category-btn">
              <Plus className="w-4 h-4 mr-2" />
              Add Category
            </Button>
          </div>

          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Preview</th>
                  <th>Name</th>
                  <th>Background</th>
                  <th>Text</th>
                  <th className="w-24">Actions</th>
                </tr>
              </thead>
              <tbody>
                {categories.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="text-center py-8 text-slate-500">No categories yet</td>
                  </tr>
                ) : (
                  categories.map((cat) => (
                    <tr key={cat.category_id}>
                      <td>
                        <span 
                          className="px-3 py-1 rounded text-xs font-medium"
                          style={{ backgroundColor: cat.bg_color, color: cat.text_color, border: `1px solid ${cat.border_color}` }}
                        >
                          {cat.name}
                        </span>
                      </td>
                      <td className="font-medium text-slate-900">{cat.name}</td>
                      <td>
                        <div className="flex items-center gap-2">
                          <span className="w-4 h-4 rounded border" style={{ backgroundColor: cat.bg_color }}></span>
                          <code className="text-xs text-slate-500">{cat.bg_color}</code>
                        </div>
                      </td>
                      <td>
                        <div className="flex items-center gap-2">
                          <span className="w-4 h-4 rounded border" style={{ backgroundColor: cat.text_color }}></span>
                          <code className="text-xs text-slate-500">{cat.text_color}</code>
                        </div>
                      </td>
                      <td>
                        <div className="flex gap-1">
                          <button 
                            onClick={() => { setEditingCategory(cat); setCategoryForm({ name: cat.name, bg_color: cat.bg_color, text_color: cat.text_color, border_color: cat.border_color }); setCategoryDialogOpen(true); }}
                            className="btn-icon"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button onClick={() => setDeleteCategoryConfirm(cat)} className="btn-icon text-red-500 hover:text-red-700">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>

        {/* Statuses Tab */}
        <TabsContent value="statuses" className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-slate-500 text-sm">
              Statuses track the progress of tasks. Order determines the display sequence.
            </p>
            <Button onClick={() => { setEditingStatus(null); setStatusForm({ name: "", order: statuses.length }); setStatusDialogOpen(true); }} data-testid="add-status-btn">
              <Plus className="w-4 h-4 mr-2" />
              Add Status
            </Button>
          </div>

          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Order</th>
                  <th className="w-24">Actions</th>
                </tr>
              </thead>
              <tbody>
                {statuses.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="text-center py-8 text-slate-500">No statuses yet</td>
                  </tr>
                ) : (
                  statuses.map((status) => (
                    <tr key={status.status_id}>
                      <td className="font-medium text-slate-900">{status.name}</td>
                      <td className="text-slate-600">{status.order}</td>
                      <td>
                        <div className="flex gap-1">
                          <button 
                            onClick={() => { setEditingStatus(status); setStatusForm({ name: status.name, order: status.order }); setStatusDialogOpen(true); }}
                            className="btn-icon"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button onClick={() => setDeleteStatusConfirm(status)} className="btn-icon text-red-500 hover:text-red-700">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>

        {/* Workflow Stages Tab */}
        <TabsContent value="stages" className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-slate-500 text-sm">
              Workflow stages define the assignment pipeline for tasks (e.g., Design, Video Edit). Each stage gets its own assignee and status.
            </p>
            <Button onClick={() => { setEditingStage(null); setStageForm({ name: "", order: workflowStages.length }); setStageDialogOpen(true); }} data-testid="add-stage-btn">
              <Plus className="w-4 h-4 mr-2" />
              Add Stage
            </Button>
          </div>

          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Order</th>
                  <th className="w-24">Actions</th>
                </tr>
              </thead>
              <tbody>
                {workflowStages.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="text-center py-8 text-slate-500">No workflow stages yet</td>
                  </tr>
                ) : (
                  workflowStages.map((stage) => (
                    <tr key={stage.stage_id} data-testid={`stage-row-${stage.stage_id}`}>
                      <td className="font-medium text-slate-900">{stage.name}</td>
                      <td className="text-slate-600">{stage.order}</td>
                      <td>
                        <div className="flex gap-1">
                          <button 
                            onClick={() => { setEditingStage(stage); setStageForm({ name: stage.name, order: stage.order }); setStageDialogOpen(true); }}
                            className="btn-icon"
                            data-testid={`edit-stage-${stage.stage_id}`}
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => setDeleteStageConfirm(stage)} 
                            className="btn-icon text-red-500 hover:text-red-700"
                            data-testid={`delete-stage-${stage.stage_id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </TabsContent>

        {/* AI Settings */}
        <TabsContent value="ai" className="space-y-4" data-testid="ai-settings-content">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold text-slate-900">AI Model Configuration</h2>
              <p className="text-sm text-slate-500">Choose which AI platform to use for each process</p>
            </div>
            <Button onClick={saveAiSettings} disabled={savingAi} data-testid="save-ai-settings-btn">
              {savingAi ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
              Save Settings
            </Button>
          </div>

          <div className="grid gap-4">
            {[
              { key: "character_detection", label: "Character Detection", desc: "AI model for detecting characters from scripts", options: ["gemini", "claude"] },
              { key: "image_prompt_generation", label: "Image Prompt Generation", desc: "AI model for creating detailed scene prompts from script text", options: ["gemini", "claude"] },
              { key: "scene_image_generation", label: "Scene Image Generation", desc: "AI model for generating scene images (always Gemini)", options: ["gemini"], locked: true },
              { key: "headshot_generation", label: "Headshot Generation", desc: "AI model for generating character headshots (always Gemini)", options: ["gemini"], locked: true },
            ].map(({ key, label, desc, options, locked }) => (
              <div key={key} className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-xl" data-testid={`ai-setting-${key}`}>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-slate-900">{label}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{desc}</p>
                </div>
                <Select value={aiSettings[key] || "gemini"} onValueChange={(v) => !locked && setAiSettings(prev => ({ ...prev, [key]: v }))} disabled={locked}>
                  <SelectTrigger className={`w-[160px] ${locked ? "opacity-60" : ""}`} data-testid={`ai-select-${key}`}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {options.map(opt => (
                      <SelectItem key={opt} value={opt}>
                        <span className="flex items-center gap-2">
                          <span className={`w-2 h-2 rounded-full inline-block ${opt === "claude" ? "bg-amber-500" : "bg-blue-500"}`} />
                          {opt === "claude" ? "Claude Sonnet" : "Gemini Flash"}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ))}
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
            <p className="text-xs text-slate-500">
              <strong>Claude Sonnet</strong> — Higher quality, more expensive. Best for complex prompt generation.
            </p>
            <p className="text-xs text-slate-500 mt-1">
              <strong>Gemini Flash</strong> — Faster, cheaper. Best for character detection and routine tasks.
            </p>
          </div>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-6" data-testid="analytics-content">
          {/* Header with period selector and refresh */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Select value={analyticsPeriod} onValueChange={(v) => { setAnalyticsPeriod(v); fetchAnalytics(v); }}>
                <SelectTrigger className="w-[140px]" data-testid="analytics-period-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">Last 7 days</SelectItem>
                  <SelectItem value="30">Last 30 days</SelectItem>
                  <SelectItem value="90">Last 90 days</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button variant="outline" size="sm" onClick={() => fetchAnalytics()} disabled={analyticsLoading} data-testid="analytics-refresh-btn">
              <RefreshCw className={`w-4 h-4 mr-2 ${analyticsLoading ? "animate-spin" : ""}`} />
              Refresh
            </Button>
          </div>

          {analyticsLoading && !analyticsSummary ? (
            <div className="flex items-center justify-center py-16 text-slate-400">
              <Loader2 className="w-6 h-6 animate-spin mr-2" /> Loading analytics...
            </div>
          ) : analyticsSummary ? (
            <>
              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4" data-testid="analytics-summary-cards">
                <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 border border-emerald-200 rounded-xl p-5">
                  <div className="flex items-center gap-2 text-emerald-600 mb-1">
                    <DollarSign className="w-4 h-4" />
                    <span className="text-xs font-medium uppercase tracking-wide">Total Cost</span>
                  </div>
                  <p className="text-2xl font-bold text-emerald-800" data-testid="analytics-total-cost">
                    ${analyticsSummary.total_cost?.toFixed(4)}
                  </p>
                </div>
                {Object.entries(analyticsSummary.by_model || {}).map(([model, data]) => (
                  <div key={model} className={`border rounded-xl p-5 ${
                    model.includes("claude") ? "bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200" :
                    model.includes("image") ? "bg-gradient-to-br from-violet-50 to-violet-100 border-violet-200" :
                    "bg-gradient-to-br from-sky-50 to-sky-100 border-sky-200"
                  }`}>
                    <div className={`flex items-center gap-2 mb-1 ${
                      model.includes("claude") ? "text-amber-600" :
                      model.includes("image") ? "text-violet-600" :
                      "text-sky-600"
                    }`}>
                      {model.includes("image") ? <Image className="w-4 h-4" /> : <MessageSquare className="w-4 h-4" />}
                      <span className="text-xs font-medium uppercase tracking-wide truncate">{model}</span>
                    </div>
                    <p className={`text-2xl font-bold ${
                      model.includes("claude") ? "text-amber-800" :
                      model.includes("image") ? "text-violet-800" :
                      "text-sky-800"
                    }`}>
                      ${data.cost?.toFixed(4)}
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      {data.calls} calls
                      {data.images > 0 && ` / ${data.images} images`}
                      {data.input_tokens > 0 && ` / ${(data.input_tokens / 1000).toFixed(1)}K tokens`}
                    </p>
                  </div>
                ))}
              </div>

              {/* Daily Cost Chart (simple bar chart) */}
              {analyticsDaily.length > 0 && (
                <div className="bg-white border border-slate-200 rounded-xl p-5" data-testid="analytics-daily-chart">
                  <h3 className="text-sm font-semibold text-slate-700 mb-4">Daily Cost Breakdown</h3>
                  <div className="space-y-2">
                    {(() => {
                      const maxCost = Math.max(...analyticsDaily.map(d => d.total), 0.001);
                      return analyticsDaily.map((day) => (
                        <div key={day.date} className="flex items-center gap-3">
                          <span className="text-xs text-slate-500 w-20 shrink-0 font-mono">{day.date.slice(5)}</span>
                          <div className="flex-1 flex items-center gap-1 h-6">
                            {Object.entries(day).filter(([k]) => !["date", "total"].includes(k)).map(([model, cost]) => (
                              <div
                                key={model}
                                className={`h-full rounded-sm ${
                                  model.includes("claude") ? "bg-amber-400" :
                                  model.includes("image") ? "bg-violet-400" :
                                  "bg-sky-400"
                                }`}
                                style={{ width: `${Math.max((cost / maxCost) * 100, 1)}%`, minWidth: cost > 0 ? "4px" : "0" }}
                                title={`${model}: $${cost.toFixed(4)}`}
                              />
                            ))}
                          </div>
                          <span className="text-xs font-medium text-slate-600 w-16 text-right">${day.total.toFixed(4)}</span>
                        </div>
                      ));
                    })()}
                  </div>
                  <div className="flex gap-4 mt-3 text-xs text-slate-500">
                    <span className="flex items-center gap-1"><span className="w-3 h-3 bg-amber-400 rounded-sm inline-block" /> Claude</span>
                    <span className="flex items-center gap-1"><span className="w-3 h-3 bg-sky-400 rounded-sm inline-block" /> Gemini Text</span>
                    <span className="flex items-center gap-1"><span className="w-3 h-3 bg-violet-400 rounded-sm inline-block" /> Gemini Image</span>
                  </div>
                </div>
              )}

              {/* Cost by Operation */}
              {Object.keys(analyticsSummary.by_operation || {}).length > 0 && (
                <div className="bg-white border border-slate-200 rounded-xl p-5" data-testid="analytics-operation-breakdown">
                  <h3 className="text-sm font-semibold text-slate-700 mb-4">Cost by Operation</h3>
                  <div className="space-y-3">
                    {Object.entries(analyticsSummary.by_operation).sort(([,a],[,b]) => b.cost - a.cost).map(([op, data]) => {
                      const maxOp = Math.max(...Object.values(analyticsSummary.by_operation).map(o => o.cost), 0.001);
                      const label = op.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase());
                      return (
                        <div key={op} className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span className="text-slate-600 font-medium">{label}</span>
                            <span className="text-slate-500">${data.cost.toFixed(4)} ({data.calls} calls)</span>
                          </div>
                          <div className="w-full bg-slate-100 rounded-full h-2">
                            <div className="bg-indigo-500 h-2 rounded-full" style={{ width: `${(data.cost / maxOp) * 100}%` }} />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Recent API Calls */}
              {analyticsRecent.length > 0 && (
                <div className="bg-white border border-slate-200 rounded-xl p-5" data-testid="analytics-recent-logs">
                  <h3 className="text-sm font-semibold text-slate-700 mb-4">Recent API Calls</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="border-b border-slate-200 text-left text-slate-500">
                          <th className="pb-2 pr-4 font-medium">Time</th>
                          <th className="pb-2 pr-4 font-medium">Operation</th>
                          <th className="pb-2 pr-4 font-medium">Model</th>
                          <th className="pb-2 pr-4 font-medium">Tokens</th>
                          <th className="pb-2 font-medium text-right">Cost</th>
                        </tr>
                      </thead>
                      <tbody>
                        {analyticsRecent.map((log) => (
                          <tr key={log.log_id} className="border-b border-slate-50 hover:bg-slate-50">
                            <td className="py-2 pr-4 text-slate-500 font-mono whitespace-nowrap">
                              {new Date(log.created_at).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                            </td>
                            <td className="py-2 pr-4">
                              <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full text-xs">
                                {log.operation?.replace(/_/g, " ")}
                              </span>
                            </td>
                            <td className="py-2 pr-4">
                              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                                log.model?.includes("claude") ? "bg-amber-100 text-amber-700" :
                                log.model?.includes("image") ? "bg-violet-100 text-violet-700" :
                                "bg-sky-100 text-sky-700"
                              }`}>
                                {log.model}
                              </span>
                            </td>
                            <td className="py-2 pr-4 text-slate-500">
                              {log.image_count > 0 ? `${log.image_count} img` : `${log.input_tokens?.toLocaleString()} / ${log.output_tokens?.toLocaleString()}`}
                            </td>
                            <td className="py-2 text-right font-medium text-slate-700">${log.cost?.toFixed(4)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Empty state */}
              {analyticsSummary.total_cost === 0 && (
                <div className="text-center py-12 text-slate-400">
                  <BarChart3 className="w-10 h-10 mx-auto mb-3 opacity-50" />
                  <p className="text-sm">No API usage data yet. Start generating to see analytics.</p>
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-16 text-slate-400">
              <BarChart3 className="w-10 h-10 mx-auto mb-3 opacity-50" />
              <p className="text-sm">Click to load analytics data</p>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Team Member Dialog */}
      <Dialog open={memberDialogOpen} onOpenChange={setMemberDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingMember ? "Edit Team Member" : "Add Team Member"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={saveMember}>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="member-name">Name</Label>
                <Input
                  id="member-name"
                  value={memberForm.name}
                  onChange={(e) => setMemberForm({ ...memberForm, name: e.target.value })}
                  placeholder="Enter name"
                  required
                  data-testid="member-name-input"
                />
              </div>
              <div>
                <Label htmlFor="member-email">Email</Label>
                <Input
                  id="member-email"
                  type="email"
                  value={memberForm.email}
                  onChange={(e) => setMemberForm({ ...memberForm, email: e.target.value })}
                  placeholder="Enter email for login access"
                  data-testid="member-email-input"
                />
                <p className="text-xs text-slate-400 mt-1">Members with email can log in to the app.</p>
              </div>
              <div>
                <Label htmlFor="member-role">Role</Label>
                <Select
                  value={memberForm.role}
                  onValueChange={(value) => setMemberForm({ ...memberForm, role: value })}
                >
                  <SelectTrigger data-testid="member-role-select">
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Admin - Full control</SelectItem>
                    <SelectItem value="editor">Editor - Create & edit</SelectItem>
                    <SelectItem value="viewer">Viewer - View only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {memberForm.role !== "admin" && (
                <div>
                  <Label>Project Access</Label>
                  <p className="text-xs text-slate-400 mb-2">Select which projects this member can see. Admins see all projects.</p>
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {(memberForm.project_ids || []).map(pid => {
                      const proj = allProjects.find(p => p.project_id === pid);
                      return proj ? (
                        <span key={pid} className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-100 text-slate-700 text-xs rounded-md">
                          <FolderOpen className="w-3 h-3 text-amber-500" />
                          {proj.name}
                          <button
                            type="button"
                            onClick={() => setMemberForm({ ...memberForm, project_ids: memberForm.project_ids.filter(id => id !== pid) })}
                            className="text-slate-400 hover:text-slate-700"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </span>
                      ) : null;
                    })}
                  </div>
                  <select
                    className="w-full h-9 rounded-md border border-slate-200 bg-white px-3 text-sm text-slate-700"
                    value=""
                    onChange={(e) => {
                      const pid = e.target.value;
                      if (pid && !(memberForm.project_ids || []).includes(pid)) {
                        setMemberForm({ ...memberForm, project_ids: [...(memberForm.project_ids || []), pid] });
                      }
                    }}
                    data-testid="member-project-select"
                  >
                    <option value="">Add a project...</option>
                    {allProjects.filter(p => !(memberForm.project_ids || []).includes(p.project_id)).map(p => (
                      <option key={p.project_id} value={p.project_id}>{p.name}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setMemberDialogOpen(false)}>Cancel</Button>
              <Button type="submit" data-testid="save-member-btn">{editingMember ? "Save" : "Add Member"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Category Dialog */}
      <Dialog open={categoryDialogOpen} onOpenChange={setCategoryDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingCategory ? "Edit Category" : "Add Category"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={saveCategory}>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="cat-name">Name</Label>
                <Input
                  id="cat-name"
                  value={categoryForm.name}
                  onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })}
                  placeholder="e.g., B-Roll, Graphics, SFX"
                  required
                />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="cat-bg">Background</Label>
                  <div className="flex gap-2 mt-1">
                    <input type="color" id="cat-bg" value={categoryForm.bg_color} onChange={(e) => setCategoryForm({ ...categoryForm, bg_color: e.target.value })} className="w-10 h-10 rounded border cursor-pointer" />
                    <Input value={categoryForm.bg_color} onChange={(e) => setCategoryForm({ ...categoryForm, bg_color: e.target.value })} className="flex-1" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="cat-text">Text</Label>
                  <div className="flex gap-2 mt-1">
                    <input type="color" id="cat-text" value={categoryForm.text_color} onChange={(e) => setCategoryForm({ ...categoryForm, text_color: e.target.value })} className="w-10 h-10 rounded border cursor-pointer" />
                    <Input value={categoryForm.text_color} onChange={(e) => setCategoryForm({ ...categoryForm, text_color: e.target.value })} className="flex-1" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="cat-border">Border</Label>
                  <div className="flex gap-2 mt-1">
                    <input type="color" id="cat-border" value={categoryForm.border_color} onChange={(e) => setCategoryForm({ ...categoryForm, border_color: e.target.value })} className="w-10 h-10 rounded border cursor-pointer" />
                    <Input value={categoryForm.border_color} onChange={(e) => setCategoryForm({ ...categoryForm, border_color: e.target.value })} className="flex-1" />
                  </div>
                </div>
              </div>
              <div>
                <Label>Preview</Label>
                <div className="mt-2">
                  <span className="px-3 py-1 rounded text-sm font-medium" style={{ backgroundColor: categoryForm.bg_color, color: categoryForm.text_color, border: `1px solid ${categoryForm.border_color}` }}>
                    {categoryForm.name || "Category Name"}
                  </span>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setCategoryDialogOpen(false)}>Cancel</Button>
              <Button type="submit">{editingCategory ? "Save" : "Add Category"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Status Dialog */}
      <Dialog open={statusDialogOpen} onOpenChange={setStatusDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingStatus ? "Edit Status" : "Add Status"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={saveStatus}>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="status-name">Name</Label>
                <Input
                  id="status-name"
                  value={statusForm.name}
                  onChange={(e) => setStatusForm({ ...statusForm, name: e.target.value })}
                  placeholder="e.g., Pending, In Progress, Done"
                  required
                />
              </div>
              <div>
                <Label htmlFor="status-order">Order</Label>
                <Input
                  id="status-order"
                  type="number"
                  value={statusForm.order}
                  onChange={(e) => setStatusForm({ ...statusForm, order: parseInt(e.target.value) })}
                  min={0}
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setStatusDialogOpen(false)}>Cancel</Button>
              <Button type="submit">{editingStatus ? "Save" : "Add Status"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Member Confirmation */}
      <AlertDialog open={!!deleteMemberConfirm} onOpenChange={() => setDeleteMemberConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Team Member</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete <strong>{deleteMemberConfirm?.name}</strong>? This will also revoke their login access.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteMember(deleteMemberConfirm?.member_id)} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Category Confirmation */}
      <AlertDialog open={!!deleteCategoryConfirm} onOpenChange={() => setDeleteCategoryConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Category</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the category "{deleteCategoryConfirm?.name}"?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteCategory(deleteCategoryConfirm?.category_id)} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Status Confirmation */}
      <AlertDialog open={!!deleteStatusConfirm} onOpenChange={() => setDeleteStatusConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Status</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the status "{deleteStatusConfirm?.name}"?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteStatus(deleteStatusConfirm?.status_id)} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Workflow Stage Dialog */}
      <Dialog open={stageDialogOpen} onOpenChange={setStageDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingStage ? "Edit Workflow Stage" : "Add Workflow Stage"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={saveStage}>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="stage-name">Name</Label>
                <Input
                  id="stage-name"
                  value={stageForm.name}
                  onChange={(e) => setStageForm({ ...stageForm, name: e.target.value })}
                  placeholder="e.g., Design, Video Edit, Sound"
                  required
                  data-testid="stage-name-input"
                />
              </div>
              <div>
                <Label htmlFor="stage-order">Order</Label>
                <Input
                  id="stage-order"
                  type="number"
                  value={stageForm.order}
                  onChange={(e) => setStageForm({ ...stageForm, order: parseInt(e.target.value) })}
                  min={0}
                  data-testid="stage-order-input"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setStageDialogOpen(false)}>Cancel</Button>
              <Button type="submit" data-testid="save-stage-btn">{editingStage ? "Save" : "Add Stage"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Stage Confirmation */}
      <AlertDialog open={!!deleteStageConfirm} onOpenChange={() => setDeleteStageConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Workflow Stage</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the stage "{deleteStageConfirm?.name}"? Existing task assignments for this stage will become orphaned.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteStage(deleteStageConfirm?.stage_id)} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Layout>
  );
};

export default AdminPage;
