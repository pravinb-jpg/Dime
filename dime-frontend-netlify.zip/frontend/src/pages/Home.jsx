import { Link } from "react-router-dom";
import { Layout } from "../components/Layout";
import { ClipboardList, Sparkles, ArrowRight } from "lucide-react";

export const HomePage = () => {
  return (
    <Layout breadcrumbs={[{ label: "Home" }]}>
      <div className="max-w-3xl mx-auto mt-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl font-black text-slate-900 tracking-tight" style={{ fontFamily: 'Manrope, sans-serif' }} data-testid="home-title">
            Dime Magic Box
          </h1>
          <p className="text-base text-slate-500 mt-3">Your complete YouTube production toolkit</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <Link
            to="/dashboard"
            className="group relative overflow-hidden rounded-2xl border-2 border-slate-200 bg-white p-8 hover:border-emerald-400 hover:shadow-lg transition-all duration-300"
            data-testid="home-script-to-task"
          >
            <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center mb-5 group-hover:bg-emerald-500 group-hover:text-white transition-colors">
              <ClipboardList className="w-6 h-6 text-emerald-600 group-hover:text-white transition-colors" />
            </div>
            <h2 className="text-xl font-bold text-slate-900 mb-2" style={{ fontFamily: 'Manrope, sans-serif' }}>Script to Task</h2>
            <p className="text-sm text-slate-500 leading-relaxed">Manage projects, scripts, and production tasks. Organize your workflow from script to final delivery.</p>
            <div className="flex items-center gap-1.5 mt-5 text-sm font-semibold text-emerald-600 group-hover:text-emerald-700">
              Open <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </Link>

          <Link
            to="/media"
            className="group relative overflow-hidden rounded-2xl border-2 border-slate-200 bg-white p-8 hover:border-violet-400 hover:shadow-lg transition-all duration-300"
            data-testid="home-script-to-media"
          >
            <div className="w-12 h-12 rounded-xl bg-violet-100 flex items-center justify-center mb-5 group-hover:bg-violet-500 group-hover:text-white transition-colors">
              <Sparkles className="w-6 h-6 text-violet-600 group-hover:text-white transition-colors" />
            </div>
            <h2 className="text-xl font-bold text-slate-900 mb-2" style={{ fontFamily: 'Manrope, sans-serif' }}>Script to Media</h2>
            <p className="text-sm text-slate-500 leading-relaxed">AI-powered scene generation. Detect characters, create images, and generate videos from your scripts.</p>
            <div className="flex items-center gap-1.5 mt-5 text-sm font-semibold text-violet-600 group-hover:text-violet-700">
              Open <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </Link>
        </div>
      </div>
    </Layout>
  );
};

export default HomePage;
