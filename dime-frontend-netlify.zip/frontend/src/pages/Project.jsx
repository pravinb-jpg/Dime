import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Layout } from "../components/Layout";
import { API, useAuth } from "../App";
import { toast } from "sonner";
import { Plus, FileText, MoreVertical, Pencil, Trash2, ArrowLeft, ListTodo, GripVertical, ArrowUp, ArrowDown } from "lucide-react";
import { Button } from "../components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "../components/ui/alert-dialog";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../components/ui/dropdown-menu";

export const ProjectPage = () => {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [project, setProject] = useState(null);
  const [scripts, setScripts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingScript, setEditingScript] = useState(null);
  const [formData, setFormData] = useState({ name: "" });
  const [deleteScriptId, setDeleteScriptId] = useState(null);
  const [reorderMode, setReorderMode] = useState(false);

  const canEdit = user?.role === "admin" || user?.role === "editor";

  useEffect(() => {
    fetchProject();
    fetchScripts();
  }, [projectId]);

  const fetchProject = async () => {
    try {
      const response = await fetch(`${API}/projects/${projectId}`, {
        credentials: "include",
      });
      if (response.ok) {
        const data = await response.json();
        setProject(data);
      } else {
        toast.error("Project not found");
        navigate("/dashboard");
      }
    } catch (error) {
      toast.error("Failed to fetch project");
    }
  };

  const fetchScripts = async () => {
    try {
      const response = await fetch(`${API}/projects/${projectId}/scripts`, {
        credentials: "include",
      });
      if (response.ok) {
        const data = await response.json();
        setScripts(data);
      }
    } catch (error) {
      toast.error("Failed to fetch scripts");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const url = editingScript 
        ? `${API}/scripts/${editingScript.script_id}`
        : `${API}/projects/${projectId}/scripts`;
      
      const response = await fetch(url, {
        method: editingScript ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        toast.success(editingScript ? "Script updated" : "Script created");
        setDialogOpen(false);
        setEditingScript(null);
        setFormData({ name: "" });
        fetchScripts();
      } else {
        const error = await response.json();
        toast.error(error.detail || "Failed to save script");
      }
    } catch (error) {
      toast.error("Failed to save script");
    }
  };

  const handleEdit = (script) => {
    setEditingScript(script);
    setFormData({ name: script.name });
    setDialogOpen(true);
  };

  const handleDelete = async (scriptId) => {
    try {
      const response = await fetch(`${API}/scripts/${scriptId}`, {
        method: "DELETE",
        credentials: "include",
      });

      if (response.ok) {
        toast.success("Script deleted");
        setDeleteScriptId(null);
        fetchScripts();
      } else {
        const error = await response.json();
        toast.error(error.detail || "Failed to delete script");
      }
    } catch (error) {
      toast.error("Failed to delete script");
    }
  };

  const openCreateDialog = () => {
    setEditingScript(null);
    setFormData({ name: "" });
    setDialogOpen(true);
  };

  const moveScript = async (index, direction) => {
    const newScripts = [...scripts];
    const swapIndex = index + direction;
    if (swapIndex < 0 || swapIndex >= newScripts.length) return;
    [newScripts[index], newScripts[swapIndex]] = [newScripts[swapIndex], newScripts[index]];
    setScripts(newScripts);
    try {
      await fetch(`${API}/projects/${projectId}/reorder-scripts`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ script_ids: newScripts.map(s => s.script_id) }),
      });
    } catch (e) {
      toast.error("Failed to save order");
      fetchScripts();
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="w-8 h-8 border-2 border-slate-900 border-t-transparent rounded-full animate-spin"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout 
      breadcrumbs={[
        { label: "Projects", href: "/dashboard" },
        { label: project?.name || "Project" }
      ]}
    >
      <div className="mb-6">
        <button 
          onClick={() => navigate("/dashboard")}
          className="flex items-center gap-2 text-sm text-slate-500 hover:text-slate-900 transition-colors mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Projects
        </button>
      </div>

      <div className="page-header">
        <div>
          <h1 className="page-title" data-testid="project-title">{project?.name}</h1>
          {project?.description && (
            <p className="text-slate-500 mt-1">{project.description}</p>
          )}
        </div>
        {canEdit && (
          <div className="flex items-center gap-2">
            {scripts.length > 1 && (
              <Button variant="outline" onClick={() => setReorderMode(!reorderMode)} data-testid="reorder-scripts-btn">
                <GripVertical className="w-4 h-4 mr-2" />
                {reorderMode ? "Done" : "Reorder"}
              </Button>
            )}
            <Button onClick={openCreateDialog} data-testid="create-script-btn">
              <Plus className="w-4 h-4 mr-2" />
              New Script
            </Button>
          </div>
        )}
      </div>

      {scripts.length === 0 ? (
        <div className="empty-state">
          <FileText className="empty-state-icon" strokeWidth={1} />
          <h3 className="empty-state-title">No scripts yet</h3>
          <p className="empty-state-description">
            Create your first script to start adding tasks and managing your production workflow.
          </p>
          {canEdit && (
            <Button onClick={openCreateDialog}>
              <Plus className="w-4 h-4 mr-2" />
              Create Script
            </Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {scripts.map((script, index) => (
            <div
              key={script.script_id}
              className="card card-interactive group relative"
              onClick={() => !reorderMode && navigate(`/scripts/${script.script_id}`)}
              data-testid={`script-card-${script.script_id}`}
            >
              {reorderMode && (
                <div className="absolute top-2 left-2 flex flex-col gap-1 z-10">
                  <button
                    onClick={(e) => { e.stopPropagation(); moveScript(index, -1); }}
                    disabled={index === 0}
                    className="w-7 h-7 rounded bg-slate-100 hover:bg-slate-200 flex items-center justify-center disabled:opacity-30"
                    data-testid={`move-up-${script.script_id}`}
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); moveScript(index, 1); }}
                    disabled={index === scripts.length - 1}
                    className="w-7 h-7 rounded bg-slate-100 hover:bg-slate-200 flex items-center justify-center disabled:opacity-30"
                    data-testid={`move-down-${script.script_id}`}
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-slate-600" strokeWidth={1.5} />
                </div>
                {canEdit && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <button className="btn-icon opacity-0 group-hover:opacity-100 transition-opacity">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={(e) => { e.stopPropagation(); handleEdit(script); }}>
                        <Pencil className="w-4 h-4 mr-2" />
                        Rename
                      </DropdownMenuItem>
                      {user?.role === "admin" && (
                        <DropdownMenuItem 
                          onClick={(e) => { e.stopPropagation(); setDeleteScriptId(script.script_id); }}
                          className="text-red-600"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mb-1">{script.name}</h3>
              <p className="text-sm text-slate-500 mb-4 line-clamp-2">
                {script.content 
                  ? script.content.replace(/<[^>]*>/g, '').slice(0, 100) + (script.content.length > 100 ? '...' : '')
                  : "No content yet"}
              </p>
              <div className="flex items-center gap-4 text-sm text-slate-500">
                <span className="flex items-center gap-1.5">
                  <ListTodo className="w-4 h-4" strokeWidth={1.5} />
                  {script.tasks_count} {script.tasks_count === 1 ? "task" : "tasks"}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingScript ? "Rename Script" : "Create New Script"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="name">Script Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter script name"
                  required
                  data-testid="script-name-input"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" data-testid="script-submit-btn">
                {editingScript ? "Save" : "Create Script"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteScriptId} onOpenChange={(open) => !open && setDeleteScriptId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Script</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this script? This will delete all related tasks. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => handleDelete(deleteScriptId)} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Layout>
  );
};

export default ProjectPage;
