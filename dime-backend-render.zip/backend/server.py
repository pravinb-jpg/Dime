from fastapi import FastAPI, APIRouter, HTTPException, Depends, UploadFile, File, Form, Request, Response, Body
from fastapi.responses import StreamingResponse, JSONResponse, FileResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import asyncio
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
import httpx
import shutil
import re
import bcrypt
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaInMemoryUpload
import io

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create uploads directory (fallback for local storage)
UPLOADS_DIR = ROOT_DIR / "uploads"
UPLOADS_DIR.mkdir(exist_ok=True)

# Google Drive setup
GDRIVE_SERVICE = None
GDRIVE_FOLDER_ID = None
SERVICE_ACCOUNT_FILE = ROOT_DIR / "google-service-account.json"

def init_gdrive():
    global GDRIVE_SERVICE
    
    # Try loading from env var first (base64-encoded JSON for production)
    sa_json_b64 = os.environ.get("GOOGLE_SERVICE_ACCOUNT_JSON_BASE64")
    if sa_json_b64:
        try:
            import base64
            import json as json_mod
            sa_info = json_mod.loads(base64.b64decode(sa_json_b64))
            creds = service_account.Credentials.from_service_account_info(
                sa_info, scopes=["https://www.googleapis.com/auth/drive"]
            )
            service = build("drive", "v3", credentials=creds)
            logger.info("Google Drive service initialized from env var")
            return service
        except Exception as e:
            logger.error(f"Failed to init Google Drive from env var: {e}")
    
    # Fallback to local file
    if not SERVICE_ACCOUNT_FILE.exists():
        logger.warning("Google service account file not found, file uploads will use local storage")
        return None
    try:
        creds = service_account.Credentials.from_service_account_file(
            str(SERVICE_ACCOUNT_FILE),
            scopes=["https://www.googleapis.com/auth/drive"]
        )
        service = build("drive", "v3", credentials=creds)
        logger.info("Google Drive service initialized from file")
        return service
    except Exception as e:
        logger.error(f"Failed to init Google Drive: {e}")
        return None

async def get_or_create_gdrive_folder():
    """Get or create the app's upload folder in the Shared Drive"""
    global GDRIVE_FOLDER_ID
    if GDRIVE_FOLDER_ID:
        return GDRIVE_FOLDER_ID
    
    if not GDRIVE_SERVICE:
        return None
    
    try:
        # Find the Shared Drive by name
        drives = GDRIVE_SERVICE.drives().list(q=f"name='{os.environ.get('GDRIVE_SHARED_DRIVE_NAME', 'Dime Script Flow')}'").execute()
        shared_drives = drives.get("drives", [])
        if not shared_drives:
            logger.error("Shared Drive not found")
            return None
        shared_drive_id = shared_drives[0]["id"]
        
        # Check if uploads folder exists in the Shared Drive
        results = GDRIVE_SERVICE.files().list(
            q=f"name='Uploads' and mimeType='application/vnd.google-apps.folder' and trashed=false and '{shared_drive_id}' in parents",
            spaces="drive", fields="files(id)",
            includeItemsFromAllDrives=True, supportsAllDrives=True, corpora="drive", driveId=shared_drive_id
        ).execute()
        files = results.get("files", [])
        
        if files:
            GDRIVE_FOLDER_ID = files[0]["id"]
        else:
            folder_meta = {
                "name": "Uploads",
                "mimeType": "application/vnd.google-apps.folder",
                "parents": [shared_drive_id]
            }
            folder = GDRIVE_SERVICE.files().create(
                body=folder_meta, fields="id", supportsAllDrives=True
            ).execute()
            GDRIVE_FOLDER_ID = folder["id"]
        
        logger.info(f"Google Drive folder ID: {GDRIVE_FOLDER_ID} (Shared Drive: {shared_drive_id})")
        return GDRIVE_FOLDER_ID
    except Exception as e:
        logger.error(f"Failed to get/create Drive folder: {e}")
        return None

def upload_to_gdrive(file_bytes: bytes, filename: str, mime_type: str) -> dict:
    """Upload file to Google Drive Shared Drive and return file info with public link"""
    if not GDRIVE_SERVICE or not GDRIVE_FOLDER_ID:
        return None
    
    try:
        file_meta = {
            "name": filename,
            "parents": [GDRIVE_FOLDER_ID]
        }
        media = MediaInMemoryUpload(file_bytes, mimetype=mime_type, resumable=False)
        gfile = GDRIVE_SERVICE.files().create(
            body=file_meta, media_body=media, fields="id,webViewLink,webContentLink",
            supportsAllDrives=True
        ).execute()
        
        # Make file publicly readable
        GDRIVE_SERVICE.permissions().create(
            fileId=gfile["id"],
            body={"type": "anyone", "role": "reader"},
            supportsAllDrives=True
        ).execute()
        
        file_id = gfile["id"]
        return {
            "gdrive_file_id": file_id,
            "view_link": f"https://drive.google.com/file/d/{file_id}/view",
            "direct_link": f"https://drive.google.com/uc?export=view&id={file_id}",
        }
    except Exception as e:
        logger.error(f"Failed to upload to Google Drive: {e}")
        return None

def delete_from_gdrive(file_id: str):
    """Delete a file from Google Drive"""
    if not GDRIVE_SERVICE:
        return
    try:
        GDRIVE_SERVICE.files().delete(fileId=file_id, supportsAllDrives=True).execute()
    except Exception as e:
        logger.error(f"Failed to delete from Google Drive: {e}")

async def _persist_image(image_data: bytes, filename: str, mime_type: str = "image/png"):
    """Save image to local disk (compressed) AND upload to Google Drive for persistence.
    Returns immediately after local save. Drive upload happens in background."""
    from PIL import Image as PILImage
    # Compress image to reduce file size
    try:
        img = PILImage.open(io.BytesIO(image_data))
        buf = io.BytesIO()
        if filename.endswith(".png"):
            # Convert to optimized PNG (or JPEG for large images)
            if len(image_data) > 500_000:  # >500KB → save as optimized JPEG
                img = img.convert("RGB")
                img.save(buf, "JPEG", quality=85, optimize=True)
                compressed = buf.getvalue()
            else:
                img.save(buf, "PNG", optimize=True)
                compressed = buf.getvalue()
        else:
            img = img.convert("RGB")
            img.save(buf, "JPEG", quality=85, optimize=True)
            compressed = buf.getvalue()
        image_data = compressed
    except Exception:
        pass  # Use original if compression fails
    # Save locally (fast)
    local_path = UPLOADS_DIR / filename
    with open(local_path, "wb") as f:
        f.write(image_data)
    # Fire-and-forget Drive upload (non-blocking)
    asyncio.create_task(_upload_to_drive_bg(image_data, filename, mime_type))
    return None

async def _upload_to_drive_bg(image_data: bytes, filename: str, mime_type: str):
    """Background task to upload image to Google Drive."""
    try:
        result = await asyncio.to_thread(upload_to_gdrive, image_data, filename, mime_type)
        if result:
            await db.file_drive_map.update_one(
                {"filename": filename},
                {"$set": {"filename": filename, "gdrive_file_id": result["gdrive_file_id"]}},
                upsert=True,
            )
    except Exception as e:
        logger.warning(f"Background Drive upload failed for {filename}: {e}")

async def _read_image_bytes(url_or_path: str) -> bytes:
    """Read image bytes from local disk or fall back to Google Drive."""
    # Extract filename from URL
    if url_or_path.startswith("/api/uploads/"):
        filename = url_or_path.replace("/api/uploads/", "")
    elif url_or_path.startswith("/uploads/"):
        filename = url_or_path.replace("/uploads/", "")
    else:
        filename = url_or_path

    local_path = UPLOADS_DIR / filename
    if local_path.exists():
        with open(local_path, "rb") as f:
            return f.read()

    # Fallback: Google Drive
    mapping = await db.file_drive_map.find_one({"filename": filename}, {"_id": 0})
    if mapping and mapping.get("gdrive_file_id"):
        try:
            file_id = mapping["gdrive_file_id"]
            request_obj = GDRIVE_SERVICE.files().get_media(fileId=file_id, supportsAllDrives=True)
            buffer = io.BytesIO()
            from googleapiclient.http import MediaIoBaseDownload
            downloader = MediaIoBaseDownload(buffer, request_obj)
            done = False
            while not done:
                _, done = downloader.next_chunk()
            return buffer.getvalue()
        except Exception as e:
            logger.error(f"Failed to read {filename} from Drive: {e}")
    return None

GDRIVE_SERVICE = init_gdrive()

app = FastAPI()
api_router = APIRouter(prefix="/api")

@app.get("/health")
async def health_check():
    return {"status": "ok"}

# ============== MODELS ==============

class UserBase(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str
    email: str
    name: str
    picture: Optional[str] = None
    role: str = "viewer"  # admin, editor, viewer
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class UserResponse(BaseModel):
    user_id: str
    email: str
    name: str
    picture: Optional[str] = None
    role: str

class ProjectCreate(BaseModel):
    name: str
    description: Optional[str] = ""

class ProjectResponse(BaseModel):
    project_id: str
    name: str
    description: str
    created_by: str
    created_at: str
    scripts_count: int = 0
    order: int = 0

class ScriptCreate(BaseModel):
    name: str
    content: Optional[str] = ""

class ScriptUpdate(BaseModel):
    name: Optional[str] = None
    content: Optional[str] = None

class ScriptResponse(BaseModel):
    script_id: str
    project_id: str
    name: str
    content: str
    created_by: str
    created_at: str
    tasks_count: int = 0

class CategoryCreate(BaseModel):
    name: str
    bg_color: str
    text_color: str
    border_color: str

class CategoryResponse(BaseModel):
    category_id: str
    name: str
    bg_color: str
    text_color: str
    border_color: str
    created_at: str

class StatusCreate(BaseModel):
    name: str
    order: int = 0

class StatusResponse(BaseModel):
    status_id: str
    name: str
    order: int
    created_at: str

class WorkflowStageCreate(BaseModel):
    name: str
    order: int = 0

class WorkflowStageResponse(BaseModel):
    stage_id: str
    name: str
    order: int
    created_at: str

class TeamMemberCreate(BaseModel):
    name: str
    email: Optional[str] = ""
    role: Optional[str] = "viewer"
    project_ids: Optional[List[str]] = []

class TeamMemberResponse(BaseModel):
    member_id: str
    name: str
    email: str
    role: str = "viewer"
    project_ids: List[str] = []
    created_at: str

class TaskCreate(BaseModel):
    script_id: str
    selected_text: str
    highlight_start: int
    highlight_end: int
    category_id: str
    description: Optional[str] = ""
    assigned_by: Optional[str] = ""
    assigned_to: Optional[str] = ""
    status_id: Optional[str] = ""

class TaskUpdate(BaseModel):
    category_id: Optional[str] = None
    description: Optional[str] = None
    assigned_by: Optional[str] = None
    assigned_to: Optional[str] = None
    status_id: Optional[str] = None

class TaskResponse(BaseModel):
    task_id: str
    script_id: str
    selected_text: str
    highlight_start: int
    highlight_end: int
    category_id: str
    category_name: Optional[str] = None
    category_bg_color: Optional[str] = None
    category_text_color: Optional[str] = None
    description: str
    assigned_by: str
    assigned_by_name: Optional[str] = None
    assigned_to: str
    assigned_to_name: Optional[str] = None
    status_id: str
    status_name: Optional[str] = None
    created_at: str
    attachments_count: int = 0
    project_id: Optional[str] = None
    project_name: Optional[str] = None
    script_name: Optional[str] = None
    stage_assignments: Optional[dict] = {}

class AttachmentCreate(BaseModel):
    task_id: str
    type: str  # link, image, file, audio
    url: str
    filename: Optional[str] = ""
    gdrive_file_id: Optional[str] = ""

class AttachmentResponse(BaseModel):
    attachment_id: str
    task_id: str
    type: str
    url: str
    filename: str
    gdrive_file_id: Optional[str] = ""
    created_at: str

class WhitelistedEmailCreate(BaseModel):
    email: str

class WhitelistedEmailResponse(BaseModel):
    email_id: str
    email: str
    added_by: str
    created_at: str

# ============== AUTH HELPERS ==============

async def get_session_from_token(request: Request) -> dict:
    """Get session from cookie or Authorization header"""
    session_token = request.cookies.get("session_token")
    if not session_token:
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            session_token = auth_header[7:]
    
    if not session_token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    session_doc = await db.user_sessions.find_one(
        {"session_token": session_token},
        {"_id": 0}
    )
    
    if not session_doc:
        raise HTTPException(status_code=401, detail="Invalid session")
    
    expires_at = session_doc["expires_at"]
    if isinstance(expires_at, str):
        expires_at = datetime.fromisoformat(expires_at)
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    if expires_at < datetime.now(timezone.utc):
        raise HTTPException(status_code=401, detail="Session expired")
    
    return session_doc

async def get_current_user(request: Request) -> dict:
    """Get current user from session"""
    session = await get_session_from_token(request)
    user_doc = await db.users.find_one(
        {"user_id": session["user_id"]},
        {"_id": 0}
    )
    if not user_doc:
        raise HTTPException(status_code=401, detail="User not found")
    return user_doc

async def require_role(request: Request, allowed_roles: List[str]) -> dict:
    """Require specific role(s)"""
    user = await get_current_user(request)
    if user["role"] not in allowed_roles:
        raise HTTPException(status_code=403, detail="Insufficient permissions")
    return user

# ============== AUTH ROUTES ==============

class EmailLoginRequest(BaseModel):
    email: str
    password: Optional[str] = None

@api_router.post("/auth/login")
async def login_with_email(data: EmailLoginRequest, response: Response):
    """Email-based login. Admins require password after first-time setup."""
    email = data.email.strip().lower()
    
    if not email:
        raise HTTPException(status_code=400, detail="Email required")
    
    # Check if this is the first user
    users_count = await db.users.count_documents({})
    is_first_user = users_count == 0
    
    if not is_first_user:
        # Check whitelist (case-insensitive)
        whitelist_doc = await db.whitelisted_emails.find_one({
            "email": {"$regex": f"^{email}$", "$options": "i"}
        })
        if not whitelist_doc:
            logger.warning(f"Email not whitelisted: {email}")
            raise HTTPException(status_code=403, detail="You do not have access.")
    
    # Check if user exists
    existing_user = await db.users.find_one(
        {"email": {"$regex": f"^{email}$", "$options": "i"}}, 
        {"_id": 0}
    )
    
    if existing_user:
        user_id = existing_user["user_id"]
        # Sync role from team_members (source of truth for roles)
        team_member = await db.team_members.find_one(
            {"email": {"$regex": f"^{email}$", "$options": "i"}},
            {"_id": 0}
        )
        if team_member and team_member.get("role"):
            if existing_user.get("role") != team_member["role"]:
                await db.users.update_one(
                    {"user_id": user_id},
                    {"$set": {"role": team_member["role"]}}
                )
                existing_user["role"] = team_member["role"]
        
        # Admin password check
        if existing_user.get("role") == "admin":
            has_password = bool(existing_user.get("password_hash"))
            if not has_password:
                # First-time admin: needs password setup
                return {"needs_password_setup": True, "email": email}
            
            # Admin with password set: require password
            if not data.password:
                return {"needs_password": True, "email": email}
            
            if not bcrypt.checkpw(data.password.encode("utf-8"), existing_user["password_hash"].encode("utf-8")):
                raise HTTPException(status_code=401, detail="Incorrect password")
    else:
        # Create new user
        user_id = f"user_{uuid.uuid4().hex[:12]}"
        role = "admin" if is_first_user else "viewer"
        
        # Extract name from email
        name = email.split("@")[0].replace(".", " ").replace("_", " ").title()
        
        user_doc = {
            "user_id": user_id,
            "email": email,
            "name": name,
            "picture": "",
            "role": role,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        await db.users.insert_one(user_doc)
        
        # If first user (admin), prompt password setup
        if is_first_user:
            await db.whitelisted_emails.insert_one({
                "email_id": f"email_{uuid.uuid4().hex[:12]}",
                "email": email,
                "added_by": user_id,
                "created_at": datetime.now(timezone.utc).isoformat()
            })
            return {"needs_password_setup": True, "email": email}
    
    # Create session
    session_token = f"session_{uuid.uuid4().hex}"
    expires_at = datetime.now(timezone.utc) + timedelta(days=7)
    
    # Cleanup: keep max 5 sessions per user (allow multiple tabs/devices)
    existing = await db.user_sessions.find({"user_id": user_id}, {"_id": 0, "session_id": 1}).sort("created_at", -1).to_list(100)
    if len(existing) >= 5:
        old_ids = [s.get("session_id") for s in existing[4:] if s.get("session_id")]
        if old_ids:
            await db.user_sessions.delete_many({"session_id": {"$in": old_ids}})
    
    session_doc = {
        "session_id": f"sess_{uuid.uuid4().hex[:12]}",
        "user_id": user_id,
        "session_token": session_token,
        "expires_at": expires_at.isoformat(),
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.user_sessions.insert_one(session_doc)
    
    # Set cookie
    response.set_cookie(
        key="session_token",
        value=session_token,
        httponly=True,
        secure=True,
        samesite="none",
        path="/",
        max_age=7 * 24 * 60 * 60
    )
    
    # Get user data
    user = await db.users.find_one(
        {"user_id": user_id}, 
        {"_id": 0}
    )
    
    logger.info(f"User logged in: {email}")
    
    return {
        "user_id": user["user_id"],
        "email": user["email"],
        "name": user["name"],
        "picture": user.get("picture", ""),
        "role": user["role"]
    }

@api_router.post("/auth/set-password")
async def set_admin_password(request: Request):
    """Set password for admin accounts (first-time setup)"""
    body = await request.json()
    email = body.get("email", "").strip().lower()
    password = body.get("password", "")
    
    if not email or not password:
        raise HTTPException(status_code=400, detail="Email and password required")
    if len(password) < 6:
        raise HTTPException(status_code=400, detail="Password must be at least 6 characters")
    
    user = await db.users.find_one(
        {"email": {"$regex": f"^{email}$", "$options": "i"}},
        {"_id": 0}
    )
    if not user or user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Only admin accounts can set passwords")
    
    password_hash = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
    await db.users.update_one(
        {"user_id": user["user_id"]},
        {"$set": {"password_hash": password_hash}}
    )
    
    return {"message": "Password set successfully"}

@api_router.put("/auth/change-password")
async def change_admin_password(request: Request):
    """Change password for logged-in admin"""
    current_user = await require_role(request, ["admin"])
    body = await request.json()
    current_password = body.get("current_password", "")
    new_password = body.get("new_password", "")
    
    if not current_password or not new_password:
        raise HTTPException(status_code=400, detail="Current and new password required")
    if len(new_password) < 6:
        raise HTTPException(status_code=400, detail="New password must be at least 6 characters")
    
    user = await db.users.find_one({"user_id": current_user["user_id"]}, {"_id": 0})
    if not user.get("password_hash"):
        raise HTTPException(status_code=400, detail="No password set")
    
    if not bcrypt.checkpw(current_password.encode("utf-8"), user["password_hash"].encode("utf-8")):
        raise HTTPException(status_code=401, detail="Current password is incorrect")
    
    new_hash = bcrypt.hashpw(new_password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
    await db.users.update_one(
        {"user_id": current_user["user_id"]},
        {"$set": {"password_hash": new_hash}}
    )
    
    return {"message": "Password changed successfully"}

@api_router.post("/auth/session")
async def create_session(request: Request, response: Response):
    """Exchange session_id for session_token (legacy Google OAuth)"""
    body = await request.json()
    session_id = body.get("session_id")
    
    if not session_id:
        raise HTTPException(status_code=400, detail="session_id required")
    
    # Call Emergent Auth to get session data
    try:
        async with httpx.AsyncClient() as client_http:
            auth_response = await client_http.get(
                os.environ.get("AUTH_SERVICE_URL", "https://demobackend.emergentagent.com") + "/auth/v1/env/oauth/session-data",
                headers={"X-Session-ID": session_id}
            )
    except Exception as e:
        logger.error(f"Auth service error: {e}")
        raise HTTPException(status_code=500, detail="Authentication service unavailable")
    
    if auth_response.status_code != 200:
        logger.error(f"Auth response status: {auth_response.status_code}, body: {auth_response.text}")
        raise HTTPException(status_code=401, detail="Invalid session_id")
    
    auth_data = auth_response.json()
    email = auth_data["email"]
    logger.info(f"Auth attempt for email: {email}")
    
    # Check if this is the first user or if email is whitelisted
    users_count = await db.users.count_documents({})
    is_first_user = users_count == 0
    
    if not is_first_user:
        # Check whitelist (case-insensitive)
        whitelist_doc = await db.whitelisted_emails.find_one({
            "email": {"$regex": f"^{email}$", "$options": "i"}
        })
        if not whitelist_doc:
            logger.warning(f"Email not whitelisted: {email}")
            raise HTTPException(status_code=403, detail="You do not have access.")
    
    # Check if user exists
    existing_user = await db.users.find_one({"email": email}, {"_id": 0})
    
    if existing_user:
        user_id = existing_user["user_id"]
        # Update user info if changed
        await db.users.update_one(
            {"user_id": user_id},
            {"$set": {
                "name": auth_data["name"],
                "picture": auth_data.get("picture", "")
            }}
        )
    else:
        # Create new user
        user_id = f"user_{uuid.uuid4().hex[:12]}"
        role = "admin" if is_first_user else "viewer"
        
        user_doc = {
            "user_id": user_id,
            "email": email,
            "name": auth_data["name"],
            "picture": auth_data.get("picture", ""),
            "role": role,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        await db.users.insert_one(user_doc)
        
        # If first user, add their email to whitelist
        if is_first_user:
            await db.whitelisted_emails.insert_one({
                "email_id": f"email_{uuid.uuid4().hex[:12]}",
                "email": email,
                "added_by": user_id,
                "created_at": datetime.now(timezone.utc).isoformat()
            })
    
    # Create session
    session_token = auth_data.get("session_token", f"session_{uuid.uuid4().hex}")
    expires_at = datetime.now(timezone.utc) + timedelta(days=7)
    
    # Cleanup: keep max 5 sessions per user
    existing = await db.user_sessions.find({"user_id": user_id}, {"_id": 0, "session_id": 1}).sort("created_at", -1).to_list(100)
    if len(existing) >= 5:
        old_ids = [s.get("session_id") for s in existing[4:] if s.get("session_id")]
        if old_ids:
            await db.user_sessions.delete_many({"session_id": {"$in": old_ids}})
    
    session_doc = {
        "session_id": f"sess_{uuid.uuid4().hex[:12]}",
        "user_id": user_id,
        "session_token": session_token,
        "expires_at": expires_at.isoformat(),
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.user_sessions.insert_one(session_doc)
    
    # Set cookie
    response.set_cookie(
        key="session_token",
        value=session_token,
        httponly=True,
        secure=True,
        samesite="none",
        path="/",
        max_age=7 * 24 * 60 * 60
    )
    
    # Get user data
    user = await db.users.find_one({"user_id": user_id}, {"_id": 0})
    
    return {
        "user_id": user["user_id"],
        "email": user["email"],
        "name": user["name"],
        "picture": user.get("picture", ""),
        "role": user["role"]
    }

@api_router.get("/auth/me")
async def get_me(request: Request):
    """Get current user"""
    user = await get_current_user(request)
    return {
        "user_id": user["user_id"],
        "email": user["email"],
        "name": user["name"],
        "picture": user.get("picture", ""),
        "role": user["role"]
    }

@api_router.post("/auth/logout")
async def logout(request: Request, response: Response):
    """Logout user"""
    session_token = request.cookies.get("session_token")
    if session_token:
        await db.user_sessions.delete_many({"session_token": session_token})
    
    response.delete_cookie(
        key="session_token",
        path="/",
        secure=True,
        samesite="none"
    )
    return {"message": "Logged out"}

# ============== WHITELIST ROUTES ==============

@api_router.get("/admin/whitelist", response_model=List[WhitelistedEmailResponse])
async def get_whitelist(request: Request):
    user = await require_role(request, ["admin"])
    emails = await db.whitelisted_emails.find({}, {"_id": 0}).to_list(1000)
    return emails

@api_router.post("/admin/whitelist", response_model=WhitelistedEmailResponse)
async def add_to_whitelist(data: WhitelistedEmailCreate, request: Request):
    user = await require_role(request, ["admin"])
    
    existing = await db.whitelisted_emails.find_one({"email": data.email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already whitelisted")
    
    email_doc = {
        "email_id": f"email_{uuid.uuid4().hex[:12]}",
        "email": data.email,
        "added_by": user["user_id"],
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.whitelisted_emails.insert_one(email_doc)
    return email_doc

@api_router.delete("/admin/whitelist/{email_id}")
async def remove_from_whitelist(email_id: str, request: Request):
    user = await require_role(request, ["admin"])
    result = await db.whitelisted_emails.delete_one({"email_id": email_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Email not found")
    return {"message": "Removed from whitelist"}

# ============== USER MANAGEMENT ==============

@api_router.get("/admin/users", response_model=List[UserResponse])
async def get_users(request: Request):
    user = await require_role(request, ["admin"])
    users = await db.users.find({}, {"_id": 0}).to_list(1000)
    return users

@api_router.put("/admin/users/{user_id}/role")
async def update_user_role(user_id: str, request: Request):
    admin = await require_role(request, ["admin"])
    body = await request.json()
    new_role = body.get("role")
    
    if new_role not in ["admin", "editor", "viewer"]:
        raise HTTPException(status_code=400, detail="Invalid role")
    
    result = await db.users.update_one(
        {"user_id": user_id},
        {"$set": {"role": new_role}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "Role updated"}

# ============== TEAM MEMBERS ==============

@api_router.get("/team-members", response_model=List[TeamMemberResponse])
async def get_team_members(request: Request):
    await get_current_user(request)
    members = await db.team_members.find({}, {"_id": 0}).to_list(1000)
    return members

@api_router.post("/team-members", response_model=TeamMemberResponse)
async def create_team_member(data: TeamMemberCreate, request: Request):
    user = await require_role(request, ["admin", "editor"])
    
    email = data.email.lower().strip() if data.email else ""
    role = data.role if data.role in ("admin", "editor", "viewer") else "viewer"
    
    member_doc = {
        "member_id": f"member_{uuid.uuid4().hex[:12]}",
        "name": data.name,
        "email": email,
        "role": role,
        "project_ids": data.project_ids or [],
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.team_members.insert_one(member_doc)
    
    if email:
        # Auto-whitelist the email
        existing_whitelist = await db.whitelisted_emails.find_one({
            "email": {"$regex": f"^{email}$", "$options": "i"}
        })
        if not existing_whitelist:
            await db.whitelisted_emails.insert_one({
                "email_id": f"email_{uuid.uuid4().hex[:12]}",
                "email": email,
                "added_by": user["user_id"],
                "created_at": datetime.now(timezone.utc).isoformat()
            })
            logger.info(f"Auto-whitelisted email for team member: {email}")
        
        # Create or update corresponding user record
        existing_user = await db.users.find_one(
            {"email": {"$regex": f"^{email}$", "$options": "i"}},
            {"_id": 0}
        )
        if existing_user:
            await db.users.update_one(
                {"email": {"$regex": f"^{email}$", "$options": "i"}},
                {"$set": {"role": role, "name": data.name}}
            )
        else:
            await db.users.insert_one({
                "user_id": f"user_{uuid.uuid4().hex[:12]}",
                "email": email,
                "name": data.name,
                "picture": "",
                "role": role,
                "created_at": datetime.now(timezone.utc).isoformat()
            })
    
    return member_doc

@api_router.put("/team-members/{member_id}", response_model=TeamMemberResponse)
async def update_team_member(member_id: str, data: TeamMemberCreate, request: Request):
    user = await require_role(request, ["admin", "editor"])
    
    old_member = await db.team_members.find_one({"member_id": member_id}, {"_id": 0})
    if not old_member:
        raise HTTPException(status_code=404, detail="Team member not found")
    
    new_email = data.email.lower().strip() if data.email else ""
    role = data.role if data.role in ("admin", "editor", "viewer") else old_member.get("role", "viewer")
    
    await db.team_members.update_one(
        {"member_id": member_id},
        {"$set": {"name": data.name, "email": new_email, "role": role, "project_ids": data.project_ids or []}}
    )
    
    # Handle email/whitelist changes
    old_email = old_member.get("email", "").lower()
    
    if new_email and new_email != old_email:
        # Whitelist new email
        existing_whitelist = await db.whitelisted_emails.find_one({
            "email": {"$regex": f"^{new_email}$", "$options": "i"}
        })
        if not existing_whitelist:
            await db.whitelisted_emails.insert_one({
                "email_id": f"email_{uuid.uuid4().hex[:12]}",
                "email": new_email,
                "added_by": user["user_id"],
                "created_at": datetime.now(timezone.utc).isoformat()
            })
            logger.info(f"Auto-whitelisted email for team member: {new_email}")
    
    # Update or create corresponding user record
    if new_email:
        existing_user = await db.users.find_one(
            {"email": {"$regex": f"^{new_email}$", "$options": "i"}},
            {"_id": 0}
        )
        if existing_user:
            await db.users.update_one(
                {"email": {"$regex": f"^{new_email}$", "$options": "i"}},
                {"$set": {"role": role, "name": data.name}}
            )
        else:
            await db.users.insert_one({
                "user_id": f"user_{uuid.uuid4().hex[:12]}",
                "email": new_email,
                "name": data.name,
                "picture": "",
                "role": role,
                "created_at": datetime.now(timezone.utc).isoformat()
            })
    
    member = await db.team_members.find_one({"member_id": member_id}, {"_id": 0})
    return member

@api_router.delete("/team-members/{member_id}")
async def delete_team_member(member_id: str, request: Request):
    await require_role(request, ["admin"])
    
    # Get member info for cascade deletion
    member = await db.team_members.find_one({"member_id": member_id}, {"_id": 0})
    if not member:
        raise HTTPException(status_code=404, detail="Team member not found")
    
    email = member.get("email", "")
    
    # Cascade: invalidate sessions, delete user record and whitelist entry
    if email:
        user_doc = await db.users.find_one(
            {"email": {"$regex": f"^{email}$", "$options": "i"}},
            {"_id": 0}
        )
        if user_doc:
            await db.user_sessions.delete_many({"user_id": user_doc["user_id"]})
        await db.users.delete_many({"email": {"$regex": f"^{email}$", "$options": "i"}})
        await db.whitelisted_emails.delete_many({"email": {"$regex": f"^{email}$", "$options": "i"}})
        logger.info(f"Cascade deleted user and whitelist for: {email}")
    
    # Delete team member
    await db.team_members.delete_one({"member_id": member_id})
    
    return {"message": "Team member and user access deleted"}

@api_router.put("/team-members/{member_id}/role")
async def update_member_role(member_id: str, request: Request):
    await require_role(request, ["admin"])
    body = await request.json()
    new_role = body.get("role")
    
    if new_role not in ("admin", "editor", "viewer"):
        raise HTTPException(status_code=400, detail="Invalid role")
    
    member = await db.team_members.find_one({"member_id": member_id}, {"_id": 0})
    if not member:
        raise HTTPException(status_code=404, detail="Team member not found")
    
    # Update role on team member
    await db.team_members.update_one(
        {"member_id": member_id},
        {"$set": {"role": new_role}}
    )
    
    # Also update the user record if email exists
    email = member.get("email", "")
    if email:
        await db.users.update_one(
            {"email": {"$regex": f"^{email}$", "$options": "i"}},
            {"$set": {"role": new_role}}
        )
    
    return {"message": "Role updated"}

# ============== CATEGORIES ==============

@api_router.get("/categories", response_model=List[CategoryResponse])
async def get_categories(request: Request):
    await get_current_user(request)
    categories = await db.categories.find({}, {"_id": 0}).to_list(1000)
    return categories

@api_router.post("/categories", response_model=CategoryResponse)
async def create_category(data: CategoryCreate, request: Request):
    await require_role(request, ["admin", "editor"])
    
    category_doc = {
        "category_id": f"cat_{uuid.uuid4().hex[:12]}",
        "name": data.name,
        "bg_color": data.bg_color,
        "text_color": data.text_color,
        "border_color": data.border_color,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.categories.insert_one(category_doc)
    return category_doc

@api_router.put("/categories/{category_id}", response_model=CategoryResponse)
async def update_category(category_id: str, data: CategoryCreate, request: Request):
    await require_role(request, ["admin", "editor"])
    
    # Get old category to check for color changes
    old_cat = await db.categories.find_one({"category_id": category_id}, {"_id": 0})
    if not old_cat:
        raise HTTPException(status_code=404, detail="Category not found")
    
    result = await db.categories.update_one(
        {"category_id": category_id},
        {"$set": {
            "name": data.name,
            "bg_color": data.bg_color,
            "text_color": data.text_color,
            "border_color": data.border_color
        }}
    )
    
    # Cascade: update highlight colors in all scripts with tasks of this category
    if old_cat.get("bg_color") != data.bg_color:
        old_color = old_cat.get("bg_color", "")
        new_color = data.bg_color
        tasks_with_cat = await db.tasks.find({"category_id": category_id}, {"_id": 0, "script_id": 1}).to_list(10000)
        script_ids = list(set(t["script_id"] for t in tasks_with_cat))
        for sid in script_ids:
            script = await db.scripts.find_one({"script_id": sid}, {"_id": 0, "content": 1})
            if script and script.get("content") and old_color in script["content"]:
                updated = script["content"].replace(old_color, new_color)
                await db.scripts.update_one({"script_id": sid}, {"$set": {"content": updated}})
    
    # Cascade: update category name on tasks
    if old_cat.get("name") != data.name:
        await db.tasks.update_many(
            {"category_id": category_id},
            {"$set": {"category_name": data.name}}
        )
    
    category = await db.categories.find_one({"category_id": category_id}, {"_id": 0})
    return category

@api_router.delete("/categories/{category_id}")
async def delete_category(category_id: str, request: Request):
    await require_role(request, ["admin"])
    result = await db.categories.delete_one({"category_id": category_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Category not found")
    return {"message": "Category deleted"}

# ============== STATUSES ==============

@api_router.get("/statuses", response_model=List[StatusResponse])
async def get_statuses(request: Request):
    await get_current_user(request)
    statuses = await db.statuses.find({}, {"_id": 0}).sort("order", 1).to_list(1000)
    return statuses

@api_router.post("/statuses", response_model=StatusResponse)
async def create_status(data: StatusCreate, request: Request):
    await require_role(request, ["admin", "editor"])
    
    status_doc = {
        "status_id": f"status_{uuid.uuid4().hex[:12]}",
        "name": data.name,
        "order": data.order,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.statuses.insert_one(status_doc)
    return status_doc

@api_router.put("/statuses/{status_id}", response_model=StatusResponse)
async def update_status(status_id: str, data: StatusCreate, request: Request):
    await require_role(request, ["admin", "editor"])
    
    old_status = await db.statuses.find_one({"status_id": status_id}, {"_id": 0})
    
    result = await db.statuses.update_one(
        {"status_id": status_id},
        {"$set": {"name": data.name, "order": data.order}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Status not found")
    
    # Cascade: update status name on tasks
    if old_status and old_status.get("name") != data.name:
        await db.tasks.update_many(
            {"status_id": status_id},
            {"$set": {"status_name": data.name}}
        )
    
    status = await db.statuses.find_one({"status_id": status_id}, {"_id": 0})
    return status

@api_router.delete("/statuses/{status_id}")
async def delete_status(status_id: str, request: Request):
    await require_role(request, ["admin"])
    result = await db.statuses.delete_one({"status_id": status_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Status not found")
    return {"message": "Status deleted"}

# ============== WORKFLOW STAGES ==============

@api_router.get("/workflow-stages", response_model=List[WorkflowStageResponse])
async def get_workflow_stages(request: Request):
    await get_current_user(request)
    stages = await db.workflow_stages.find({}, {"_id": 0}).sort("order", 1).to_list(100)
    return stages

@api_router.post("/workflow-stages", response_model=WorkflowStageResponse)
async def create_workflow_stage(data: WorkflowStageCreate, request: Request):
    await require_role(request, ["admin"])
    stage_doc = {
        "stage_id": f"stage_{uuid.uuid4().hex[:12]}",
        "name": data.name,
        "order": data.order,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.workflow_stages.insert_one(stage_doc)
    return stage_doc

@api_router.put("/workflow-stages/{stage_id}", response_model=WorkflowStageResponse)
async def update_workflow_stage(stage_id: str, data: WorkflowStageCreate, request: Request):
    await require_role(request, ["admin"])
    result = await db.workflow_stages.update_one(
        {"stage_id": stage_id},
        {"$set": {"name": data.name, "order": data.order}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Stage not found")
    stage = await db.workflow_stages.find_one({"stage_id": stage_id}, {"_id": 0})
    return stage

@api_router.delete("/workflow-stages/{stage_id}")
async def delete_workflow_stage(stage_id: str, request: Request):
    await require_role(request, ["admin"])
    result = await db.workflow_stages.delete_one({"stage_id": stage_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Stage not found")
    return {"message": "Stage deleted"}

# ============== PROJECTS ==============

@api_router.get("/projects", response_model=List[ProjectResponse])
async def get_projects(request: Request):
    user = await get_current_user(request)
    projects = await db.projects.find({}, {"_id": 0}).sort("order", 1).to_list(1000)
    
    # Non-admins only see projects they're assigned to
    if user.get("role") != "admin":
        member = await db.team_members.find_one(
            {"email": {"$regex": f"^{user['email']}$", "$options": "i"}},
            {"_id": 0}
        )
        if member:
            allowed = set(member.get("project_ids", []))
            projects = [p for p in projects if p["project_id"] in allowed]
        else:
            projects = []
    
    # Batch count scripts per project using aggregation
    pipeline = [{"$group": {"_id": "$project_id", "count": {"$sum": 1}}}]
    counts = {doc["_id"]: doc["count"] async for doc in db.scripts.aggregate(pipeline)}
    
    return [{**p, "scripts_count": counts.get(p["project_id"], 0)} for p in projects]

@api_router.put("/projects/reorder")
async def reorder_projects(request: Request):
    """Reorder projects by providing ordered list of project_ids"""
    await require_role(request, ["admin", "editor"])
    body = await request.json()
    project_ids = body.get("project_ids", [])
    for i, pid in enumerate(project_ids):
        await db.projects.update_one({"project_id": pid}, {"$set": {"order": i}})
    return {"message": "Projects reordered"}

@api_router.post("/projects", response_model=ProjectResponse)
async def create_project(data: ProjectCreate, request: Request):
    user = await require_role(request, ["admin", "editor"])
    
    max_order = await db.projects.find_one({}, {"_id": 0, "order": 1}, sort=[("order", -1)])
    next_order = (max_order.get("order", 0) + 1) if max_order else 0
    
    project_doc = {
        "project_id": f"proj_{uuid.uuid4().hex[:12]}",
        "name": data.name,
        "description": data.description or "",
        "created_by": user["user_id"],
        "order": next_order,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.projects.insert_one(project_doc)
    return {**project_doc, "scripts_count": 0}

@api_router.get("/projects/{project_id}", response_model=ProjectResponse)
async def get_project(project_id: str, request: Request):
    await get_current_user(request)
    project = await db.projects.find_one({"project_id": project_id}, {"_id": 0})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    scripts_count = await db.scripts.count_documents({"project_id": project_id})
    return {**project, "scripts_count": scripts_count}

@api_router.put("/projects/{project_id}", response_model=ProjectResponse)
async def update_project(project_id: str, data: ProjectCreate, request: Request):
    await require_role(request, ["admin", "editor"])
    
    result = await db.projects.update_one(
        {"project_id": project_id},
        {"$set": {"name": data.name, "description": data.description or ""}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Project not found")
    
    project = await db.projects.find_one({"project_id": project_id}, {"_id": 0})
    scripts_count = await db.scripts.count_documents({"project_id": project_id})
    return {**project, "scripts_count": scripts_count}

@api_router.delete("/projects/{project_id}")
async def delete_project(project_id: str, request: Request):
    await require_role(request, ["admin"])
    
    # Delete all related data
    scripts = await db.scripts.find({"project_id": project_id}, {"script_id": 1}).to_list(1000)
    script_ids = [s["script_id"] for s in scripts]
    
    if script_ids:
        tasks = await db.tasks.find({"script_id": {"$in": script_ids}}, {"task_id": 1}).to_list(10000)
        task_ids = [t["task_id"] for t in tasks]
        if task_ids:
            await db.attachments.delete_many({"task_id": {"$in": task_ids}})
        await db.tasks.delete_many({"script_id": {"$in": script_ids}})
    
    await db.scripts.delete_many({"project_id": project_id})
    result = await db.projects.delete_one({"project_id": project_id})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Project not found")
    return {"message": "Project deleted"}

# ============== SCRIPTS ==============

@api_router.get("/projects/{project_id}/scripts", response_model=List[ScriptResponse])
async def get_scripts(project_id: str, request: Request):
    await get_current_user(request)
    scripts = await db.scripts.find({"project_id": project_id}, {"_id": 0}).sort("order", 1).to_list(1000)
    
    # Batch count tasks per script using aggregation
    script_ids = [s["script_id"] for s in scripts]
    pipeline = [{"$match": {"script_id": {"$in": script_ids}}}, {"$group": {"_id": "$script_id", "count": {"$sum": 1}}}]
    counts = {doc["_id"]: doc["count"] async for doc in db.tasks.aggregate(pipeline)}
    
    return [{**s, "tasks_count": counts.get(s["script_id"], 0)} for s in scripts]

@api_router.post("/projects/{project_id}/scripts", response_model=ScriptResponse)
async def create_script(project_id: str, data: ScriptCreate, request: Request):
    user = await require_role(request, ["admin", "editor"])
    
    # Verify project exists
    project = await db.projects.find_one({"project_id": project_id})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    script_doc = {
        "script_id": f"script_{uuid.uuid4().hex[:12]}",
        "project_id": project_id,
        "name": data.name,
        "content": data.content or "",
        "created_by": user["user_id"],
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.scripts.insert_one(script_doc)
    return {**script_doc, "tasks_count": 0}

@api_router.get("/scripts/{script_id}", response_model=ScriptResponse)
async def get_script(script_id: str, request: Request):
    await get_current_user(request)
    script = await db.scripts.find_one({"script_id": script_id}, {"_id": 0})
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")
    
    tasks_count = await db.tasks.count_documents({"script_id": script_id})
    return {**script, "tasks_count": tasks_count}

@api_router.put("/scripts/{script_id}", response_model=ScriptResponse)
async def update_script(script_id: str, data: ScriptUpdate, request: Request):
    await require_role(request, ["admin", "editor"])
    
    update_data = {}
    if data.name is not None:
        update_data["name"] = data.name
    if data.content is not None:
        update_data["content"] = data.content
    
    if not update_data:
        raise HTTPException(status_code=400, detail="No data to update")
    
    result = await db.scripts.update_one(
        {"script_id": script_id},
        {"$set": update_data}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Script not found")
    
    script = await db.scripts.find_one({"script_id": script_id}, {"_id": 0})
    tasks_count = await db.tasks.count_documents({"script_id": script_id})
    return {**script, "tasks_count": tasks_count}

@api_router.delete("/scripts/{script_id}")
async def delete_script(script_id: str, request: Request):
    await require_role(request, ["admin"])
    
    # Delete related tasks and attachments
    tasks = await db.tasks.find({"script_id": script_id}, {"_id": 0, "task_id": 1}).to_list(10000)
    task_ids = [t["task_id"] for t in tasks]
    if task_ids:
        await db.attachments.delete_many({"task_id": {"$in": task_ids}})
    await db.tasks.delete_many({"script_id": script_id})
    
    result = await db.scripts.delete_one({"script_id": script_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Script not found")
    return {"message": "Script deleted"}

@api_router.put("/projects/{project_id}/reorder-scripts")
async def reorder_scripts(project_id: str, request: Request):
    """Reorder scripts within a project"""
    await require_role(request, ["admin", "editor"])
    body = await request.json()
    script_ids = body.get("script_ids", [])
    
    for i, sid in enumerate(script_ids):
        await db.scripts.update_one(
            {"script_id": sid, "project_id": project_id},
            {"$set": {"order": i}}
        )
    return {"message": "Scripts reordered"}

@api_router.post("/scripts/{script_id}/remove-highlight")
async def remove_highlight_from_script(script_id: str, request: Request):
    """Remove highlight markup from script content for a specific text"""
    await require_role(request, ["admin", "editor"])
    
    body = await request.json()
    selected_text = body.get("selected_text", "")
    
    if not selected_text:
        raise HTTPException(status_code=400, detail="selected_text required")
    
    script = await db.scripts.find_one({"script_id": script_id}, {"_id": 0})
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")
    
    content = script.get("content", "")
    import re
    
    # Find all <mark> tags and check if their text content matches selected_text
    def normalize(text):
        """Normalize text for comparison: strip HTML entities, normalize whitespace"""
        t = text.replace("&nbsp;", " ").replace("&#160;", " ")
        t = re.sub(r'&[a-zA-Z]+;', '', t)  # strip remaining entities
        t = re.sub(r'\s+', ' ', t).strip()
        return t
    
    normalized_selected = normalize(selected_text)
    
    # Match all <mark ...>content</mark> tags
    mark_pattern = re.compile(r'<mark[^>]*>(.*?)</mark>', re.DOTALL)
    
    def replace_matching_mark(match):
        inner = match.group(1)
        if normalize(inner) == normalized_selected:
            return inner  # Remove the mark tags, keep inner content
        # Also check if selected_text is contained in the inner content (partial match for truncated texts)
        if normalized_selected in normalize(inner) or normalize(inner) in normalized_selected:
            return inner
        return match.group(0)  # Keep the mark as-is
    
    new_content = mark_pattern.sub(replace_matching_mark, content)
    
    if new_content != content:
        await db.scripts.update_one(
            {"script_id": script_id},
            {"$set": {"content": new_content}}
        )
    
    return {"message": "Highlight removed", "content": new_content}

# ============== TASKS ==============

@api_router.get("/scripts/{script_id}/tasks", response_model=List[TaskResponse])
async def get_script_tasks(script_id: str, request: Request):
    await get_current_user(request)
    tasks = await db.tasks.find({"script_id": script_id}, {"_id": 0}).to_list(10000)
    
    # Enrich with related data
    categories = {c["category_id"]: c for c in await db.categories.find({}, {"_id": 0}).to_list(100)}
    statuses = {s["status_id"]: s for s in await db.statuses.find({}, {"_id": 0}).to_list(100)}
    members = {m["member_id"]: m for m in await db.team_members.find({}, {"_id": 0}).to_list(1000)}
    
    result = []
    
    # Batch fetch attachment counts in one query
    task_ids = [t["task_id"] for t in tasks]
    attachment_counts = {}
    if task_ids:
        pipeline = [
            {"$match": {"task_id": {"$in": task_ids}}},
            {"$group": {"_id": "$task_id", "count": {"$sum": 1}}}
        ]
        counts = await db.attachments.aggregate(pipeline).to_list(10000)
        attachment_counts = {c["_id"]: c["count"] for c in counts}
    
    # Fetch workflow stages for enrichment
    all_stages = await db.workflow_stages.find({}, {"_id": 0}).sort("order", 1).to_list(100)
    
    for task in tasks:
        cat = categories.get(task.get("category_id", ""), {})
        status = statuses.get(task.get("status_id", ""), {})
        assigned_by_member = members.get(task.get("assigned_by", ""), {})
        assigned_to_member = members.get(task.get("assigned_to", ""), {})
        
        # Build stage_assignments with resolved names
        raw_assignments = task.get("stage_assignments", {})
        enriched_assignments = {}
        for stage in all_stages:
            sid = stage["stage_id"]
            assignment = raw_assignments.get(sid, {})
            member = members.get(assignment.get("assigned_to", ""), {})
            enriched_assignments[sid] = {
                "stage_name": stage["name"],
                "assigned_to": assignment.get("assigned_to", ""),
                "assigned_to_name": member.get("name", ""),
                "status": assignment.get("status", "pending"),
            }
        
        result.append({
            **task,
            "category_name": cat.get("name", ""),
            "category_bg_color": cat.get("bg_color", ""),
            "category_text_color": cat.get("text_color", ""),
            "status_name": status.get("name", ""),
            "assigned_by_name": assigned_by_member.get("name", ""),
            "assigned_to_name": assigned_to_member.get("name", ""),
            "attachments_count": attachment_counts.get(task["task_id"], 0),
            "stage_assignments": enriched_assignments,
        })
    return result

@api_router.get("/tasks", response_model=List[TaskResponse])
async def get_all_tasks(
    request: Request,
    project_id: Optional[str] = None,
    script_id: Optional[str] = None,
    assigned_to: Optional[str] = None,
    category_id: Optional[str] = None,
    status_id: Optional[str] = None,
    search: Optional[str] = None
):
    """Get all tasks with filters"""
    await get_current_user(request)
    
    # Build filter
    filter_query = {}
    
    # Script filter takes priority over project filter
    if script_id:
        filter_query["script_id"] = script_id
    elif project_id:
        scripts = await db.scripts.find({"project_id": project_id}, {"script_id": 1}).to_list(1000)
        script_ids = [s["script_id"] for s in scripts]
        filter_query["script_id"] = {"$in": script_ids}
    
    if assigned_to:
        filter_query["assigned_to"] = assigned_to
    if category_id:
        filter_query["category_id"] = category_id
    if status_id:
        filter_query["status_id"] = status_id
    if search:
        filter_query["$or"] = [
            {"selected_text": {"$regex": search, "$options": "i"}},
            {"description": {"$regex": search, "$options": "i"}}
        ]
    
    tasks = await db.tasks.find(filter_query, {"_id": 0}).to_list(10000)
    
    # Enrich with related data
    categories = {c["category_id"]: c for c in await db.categories.find({}, {"_id": 0}).to_list(100)}
    statuses = {s["status_id"]: s for s in await db.statuses.find({}, {"_id": 0}).to_list(100)}
    members = {m["member_id"]: m for m in await db.team_members.find({}, {"_id": 0}).to_list(1000)}
    all_scripts = {s["script_id"]: s for s in await db.scripts.find({}, {"_id": 0}).to_list(1000)}
    projects = {p["project_id"]: p for p in await db.projects.find({}, {"_id": 0}).to_list(1000)}
    
    result = []
    
    # Batch fetch attachment counts in one query
    task_ids = [t["task_id"] for t in tasks]
    attachment_counts = {}
    if task_ids:
        pipeline = [
            {"$match": {"task_id": {"$in": task_ids}}},
            {"$group": {"_id": "$task_id", "count": {"$sum": 1}}}
        ]
        counts = await db.attachments.aggregate(pipeline).to_list(10000)
        attachment_counts = {c["_id"]: c["count"] for c in counts}
    
    # Fetch workflow stages for enrichment
    all_stages = await db.workflow_stages.find({}, {"_id": 0}).sort("order", 1).to_list(100)
    
    for task in tasks:
        cat = categories.get(task.get("category_id", ""), {})
        status = statuses.get(task.get("status_id", ""), {})
        assigned_by_member = members.get(task.get("assigned_by", ""), {})
        assigned_to_member = members.get(task.get("assigned_to", ""), {})
        script = all_scripts.get(task.get("script_id", ""), {})
        project = projects.get(script.get("project_id", ""), {})
        
        # Build stage_assignments with resolved names
        raw_assignments = task.get("stage_assignments", {})
        enriched_assignments = {}
        for stage in all_stages:
            sid = stage["stage_id"]
            assignment = raw_assignments.get(sid, {})
            member = members.get(assignment.get("assigned_to", ""), {})
            enriched_assignments[sid] = {
                "stage_name": stage["name"],
                "assigned_to": assignment.get("assigned_to", ""),
                "assigned_to_name": member.get("name", ""),
                "status": assignment.get("status", "pending"),
            }
        
        result.append({
            **task,
            "category_name": cat.get("name", ""),
            "category_bg_color": cat.get("bg_color", ""),
            "category_text_color": cat.get("text_color", ""),
            "status_name": status.get("name", ""),
            "assigned_by_name": assigned_by_member.get("name", ""),
            "assigned_to_name": assigned_to_member.get("name", ""),
            "attachments_count": attachment_counts.get(task["task_id"], 0),
            "script_name": script.get("name", ""),
            "project_name": project.get("name", ""),
            "project_id": script.get("project_id", ""),
            "stage_assignments": enriched_assignments,
        })
    return result

@api_router.post("/tasks", response_model=TaskResponse)
async def create_task(data: TaskCreate, request: Request):
    user = await require_role(request, ["admin", "editor"])
    
    # Verify script exists
    script = await db.scripts.find_one({"script_id": data.script_id})
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")
    
    # Get default status if not provided
    status_id = data.status_id
    if not status_id:
        default_status = await db.statuses.find_one({}, {"_id": 0}, sort=[("order", 1)])
        if default_status:
            status_id = default_status["status_id"]
    
    # Auto-assign "assigned_by" to current user if not provided
    assigned_by = data.assigned_by
    if not assigned_by:
        # Find or create a team member for the current user
        existing_member = await db.team_members.find_one({"email": user["email"]}, {"_id": 0})
        if existing_member:
            assigned_by = existing_member["member_id"]
        else:
            # Create a team member for this user
            new_member = {
                "member_id": f"member_{uuid.uuid4().hex[:12]}",
                "name": user["name"],
                "email": user["email"],
                "created_at": datetime.now(timezone.utc).isoformat()
            }
            await db.team_members.insert_one(new_member)
            assigned_by = new_member["member_id"]
    
    task_doc = {
        "task_id": f"task_{uuid.uuid4().hex[:12]}",
        "script_id": data.script_id,
        "selected_text": data.selected_text,
        "highlight_start": data.highlight_start,
        "highlight_end": data.highlight_end,
        "category_id": data.category_id,
        "description": data.description or "",
        "assigned_by": assigned_by,
        "assigned_to": data.assigned_to or "",
        "status_id": status_id or "",
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.tasks.insert_one(task_doc)
    
    # Get enriched data
    cat = await db.categories.find_one({"category_id": data.category_id}, {"_id": 0}) or {}
    status = await db.statuses.find_one({"status_id": status_id}, {"_id": 0}) if status_id else {}
    assigned_by_member = await db.team_members.find_one({"member_id": assigned_by}, {"_id": 0}) if assigned_by else {}
    
    return {
        **task_doc,
        "category_name": cat.get("name", ""),
        "category_bg_color": cat.get("bg_color", ""),
        "category_text_color": cat.get("text_color", ""),
        "status_name": status.get("name", "") if status else "",
        "assigned_by_name": assigned_by_member.get("name", "") if assigned_by_member else "",
        "assigned_to_name": "",
        "attachments_count": 0
    }

@api_router.get("/tasks/{task_id}", response_model=TaskResponse)
async def get_task(task_id: str, request: Request):
    await get_current_user(request)
    task = await db.tasks.find_one({"task_id": task_id}, {"_id": 0})
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Enrich
    cat = await db.categories.find_one({"category_id": task.get("category_id", "")}, {"_id": 0}) or {}
    status = await db.statuses.find_one({"status_id": task.get("status_id", "")}, {"_id": 0}) or {}
    assigned_by_member = await db.team_members.find_one({"member_id": task.get("assigned_by", "")}, {"_id": 0}) or {}
    assigned_to_member = await db.team_members.find_one({"member_id": task.get("assigned_to", "")}, {"_id": 0}) or {}
    attachments_count = await db.attachments.count_documents({"task_id": task_id})
    
    return {
        **task,
        "category_name": cat.get("name", ""),
        "category_bg_color": cat.get("bg_color", ""),
        "category_text_color": cat.get("text_color", ""),
        "status_name": status.get("name", ""),
        "assigned_by_name": assigned_by_member.get("name", ""),
        "assigned_to_name": assigned_to_member.get("name", ""),
        "attachments_count": attachments_count
    }

@api_router.put("/tasks/{task_id}", response_model=TaskResponse)
async def update_task(task_id: str, data: TaskUpdate, request: Request):
    await require_role(request, ["admin", "editor"])
    
    update_data = {}
    if data.category_id is not None:
        update_data["category_id"] = data.category_id
    if data.description is not None:
        update_data["description"] = data.description
    if data.assigned_by is not None:
        update_data["assigned_by"] = data.assigned_by
    if data.assigned_to is not None:
        update_data["assigned_to"] = data.assigned_to
    if data.status_id is not None:
        update_data["status_id"] = data.status_id
    
    if not update_data:
        raise HTTPException(status_code=400, detail="No data to update")
    
    result = await db.tasks.update_one(
        {"task_id": task_id},
        {"$set": update_data}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Return updated task
    return await get_task(task_id, request)

@api_router.put("/tasks/{task_id}/status")
async def update_task_status(task_id: str, request: Request):
    """Allow any authenticated user (including viewers) to update task status (mark done/undone)"""
    await get_current_user(request)
    body = await request.json()
    status_id = body.get("status_id")
    
    if not status_id:
        raise HTTPException(status_code=400, detail="status_id required")
    
    result = await db.tasks.update_one(
        {"task_id": task_id},
        {"$set": {"status_id": status_id}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Task not found")
    
    return {"message": "Status updated"}

@api_router.put("/tasks/{task_id}/stage")
async def update_task_stage(task_id: str, request: Request):
    """Update a workflow stage assignment or status"""
    await get_current_user(request)
    body = await request.json()
    
    stage_id = body.get("stage_id")
    if not stage_id:
        raise HTTPException(status_code=400, detail="stage_id required")
    
    # Verify stage exists
    stage = await db.workflow_stages.find_one({"stage_id": stage_id}, {"_id": 0})
    if not stage:
        raise HTTPException(status_code=404, detail="Workflow stage not found")
    
    task = await db.tasks.find_one({"task_id": task_id}, {"_id": 0})
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    current_assignments = task.get("stage_assignments", {})
    current_stage = current_assignments.get(stage_id, {})
    
    if "assigned_to" in body:
        current_stage["assigned_to"] = body["assigned_to"]
    if "status" in body:
        valid_statuses = ("pending", "hold", "rejected", "done")
        if body["status"] not in valid_statuses:
            raise HTTPException(status_code=400, detail=f"Invalid status. Must be one of: {valid_statuses}")
        current_stage["status"] = body["status"]
    
    current_assignments[stage_id] = current_stage
    await db.tasks.update_one({"task_id": task_id}, {"$set": {"stage_assignments": current_assignments}})
    
    # Auto-calculate final task status from stages that have assignments
    all_stages = await db.workflow_stages.find({}, {"_id": 0}).to_list(100)
    # Only consider stages where someone is actually assigned
    assigned_stages = [
        current_assignments.get(s["stage_id"], {})
        for s in all_stages
        if current_assignments.get(s["stage_id"], {}).get("assigned_to")
    ]
    stage_statuses = [a.get("status", "pending") for a in assigned_stages]
    
    # Determine final status
    done_status = await db.statuses.find_one({"name": {"$regex": "^done$", "$options": "i"}}, {"_id": 0})
    rejected_status = await db.statuses.find_one({"name": {"$regex": "^rejected$", "$options": "i"}}, {"_id": 0})
    pending_status = await db.statuses.find_one({"name": {"$regex": "^pending$", "$options": "i"}}, {"_id": 0})
    hold_status = await db.statuses.find_one({"name": {"$regex": "^hold$", "$options": "i"}}, {"_id": 0})
    
    if not stage_statuses:
        # No assignments at all — keep as pending
        if pending_status:
            await db.tasks.update_one({"task_id": task_id}, {"$set": {"status_id": pending_status["status_id"]}})
    elif any(s == "rejected" for s in stage_statuses):
        if rejected_status:
            await db.tasks.update_one({"task_id": task_id}, {"$set": {"status_id": rejected_status["status_id"]}})
    elif all(s == "done" for s in stage_statuses) and stage_statuses:
        if done_status:
            await db.tasks.update_one({"task_id": task_id}, {"$set": {"status_id": done_status["status_id"]}})
    elif any(s == "hold" for s in stage_statuses):
        if hold_status:
            await db.tasks.update_one({"task_id": task_id}, {"$set": {"status_id": hold_status["status_id"]}})
    else:
        if pending_status:
            await db.tasks.update_one({"task_id": task_id}, {"$set": {"status_id": pending_status["status_id"]}})
    
    return {"message": "Stage updated"}

@api_router.delete("/tasks/{task_id}")
async def delete_task(task_id: str, request: Request):
    await require_role(request, ["admin", "editor"])
    
    # Get task info first (for returning to frontend to remove highlight)
    task = await db.tasks.find_one({"task_id": task_id}, {"_id": 0})
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    # Delete attachments first
    await db.attachments.delete_many({"task_id": task_id})
    
    await db.tasks.delete_one({"task_id": task_id})
    
    return {
        "message": "Task deleted",
        "task": {
            "task_id": task["task_id"],
            "script_id": task["script_id"],
            "selected_text": task["selected_text"],
            "highlight_start": task.get("highlight_start"),
            "highlight_end": task.get("highlight_end")
        }
    }

# ============== HIGHLIGHT LOCKS ==============

@api_router.post("/tasks/{task_id}/lock")
async def lock_highlight(task_id: str, request: Request):
    """Lock a highlight/task for editing. Auto-expires after 5 minutes."""
    user = await get_current_user(request)
    task = await db.tasks.find_one({"task_id": task_id}, {"_id": 0, "script_id": 1})
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    now = datetime.now(timezone.utc)
    expires_at = now + timedelta(minutes=5)

    # Check if already locked by someone else (and not expired)
    existing = await db.highlight_locks.find_one(
        {"task_id": task_id, "expires_at": {"$gt": now.isoformat()}},
        {"_id": 0}
    )
    if existing and existing["user_id"] != user["user_id"]:
        raise HTTPException(status_code=409, detail=f"Locked by {existing['user_name']}")

    # Upsert lock
    await db.highlight_locks.update_one(
        {"task_id": task_id},
        {"$set": {
            "task_id": task_id,
            "script_id": task["script_id"],
            "user_id": user["user_id"],
            "user_name": user.get("name", user["email"]),
            "locked_at": now.isoformat(),
            "expires_at": expires_at.isoformat(),
        }},
        upsert=True
    )
    return {"locked": True, "expires_at": expires_at.isoformat()}

@api_router.delete("/tasks/{task_id}/lock")
async def unlock_highlight(task_id: str, request: Request):
    """Release a highlight lock."""
    user = await get_current_user(request)
    await db.highlight_locks.delete_one({"task_id": task_id, "user_id": user["user_id"]})
    return {"locked": False}

@api_router.post("/tasks/{task_id}/lock/renew")
async def renew_lock(task_id: str, request: Request):
    """Renew an existing lock for another 5 minutes."""
    user = await get_current_user(request)
    now = datetime.now(timezone.utc)
    result = await db.highlight_locks.update_one(
        {"task_id": task_id, "user_id": user["user_id"]},
        {"$set": {"expires_at": (now + timedelta(minutes=5)).isoformat()}}
    )
    if result.modified_count == 0:
        return {"renewed": False, "reason": "no_active_lock"}
    return {"renewed": True}

@api_router.get("/scripts/{script_id}/locks")
async def get_script_locks(script_id: str, request: Request):
    """Get all active (non-expired) locks for a script."""
    await get_current_user(request)
    now = datetime.now(timezone.utc).isoformat()
    locks = await db.highlight_locks.find(
        {"script_id": script_id, "expires_at": {"$gt": now}},
        {"_id": 0}
    ).to_list(500)
    return locks

# ============== SCRIPT-LEVEL LOCKING ==============

@api_router.post("/scripts/{script_id}/lock")
async def lock_script(script_id: str, request: Request):
    """Lock an entire script for editing. Auto-expires after 5 minutes."""
    user = await get_current_user(request)
    now = datetime.now(timezone.utc)
    expires_at = now + timedelta(minutes=5)

    # Check if already locked by someone else (and not expired)
    existing = await db.script_locks.find_one(
        {"script_id": script_id, "expires_at": {"$gt": now.isoformat()}},
        {"_id": 0}
    )
    if existing and existing["user_id"] != user["user_id"]:
        return JSONResponse(status_code=409, content={
            "detail": f"Locked by {existing['locked_by_name']}",
            "locked_by": {
                "user_id": existing["user_id"],
                "locked_by_name": existing["locked_by_name"],
            }
        })

    # Upsert lock
    await db.script_locks.update_one(
        {"script_id": script_id},
        {"$set": {
            "script_id": script_id,
            "user_id": user["user_id"],
            "locked_by_name": user.get("name", user["email"]),
            "locked_at": now.isoformat(),
            "expires_at": expires_at.isoformat(),
        }},
        upsert=True
    )
    return {"locked": True, "expires_at": expires_at.isoformat()}

@api_router.delete("/scripts/{script_id}/unlock")
async def unlock_script(script_id: str, request: Request):
    """Release a script lock."""
    user = await get_current_user(request)
    await db.script_locks.delete_one({"script_id": script_id, "user_id": user["user_id"]})
    return {"locked": False}

@api_router.post("/scripts/{script_id}/unlock-beacon")
async def unlock_script_beacon(script_id: str, request: Request):
    """Release script lock via sendBeacon (fire-and-forget on tab close)."""
    try:
        body = await request.json()
        user_id = body.get("user_id")
        if user_id:
            await db.script_locks.delete_one({"script_id": script_id, "user_id": user_id})
    except Exception:
        pass
    return {"ok": True}

@api_router.get("/scripts/{script_id}/lock-status")
async def script_lock_status(script_id: str, request: Request):
    """Check if a script is locked and by whom."""
    await get_current_user(request)
    now = datetime.now(timezone.utc).isoformat()
    lock = await db.script_locks.find_one(
        {"script_id": script_id, "expires_at": {"$gt": now}},
        {"_id": 0}
    )
    if lock:
        return {
            "locked": True,
            "locked_by": {
                "user_id": lock["user_id"],
                "locked_by_name": lock["locked_by_name"],
            },
            "expires_at": lock["expires_at"],
        }
    return {"locked": False, "locked_by": None}

# ============== ATTACHMENTS ==============

@api_router.get("/tasks/{task_id}/attachments", response_model=List[AttachmentResponse])
async def get_attachments(task_id: str, request: Request):
    await get_current_user(request)
    attachments = await db.attachments.find({"task_id": task_id}, {"_id": 0}).to_list(1000)
    return attachments

@api_router.post("/tasks/{task_id}/attachments", response_model=AttachmentResponse)
async def add_attachment(task_id: str, data: AttachmentCreate, request: Request):
    await require_role(request, ["admin", "editor"])
    
    # Verify task exists
    task = await db.tasks.find_one({"task_id": task_id})
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    attachment_doc = {
        "attachment_id": f"attach_{uuid.uuid4().hex[:12]}",
        "task_id": task_id,
        "type": data.type,
        "url": data.url,
        "filename": data.filename or "",
        "gdrive_file_id": data.gdrive_file_id or "",
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.attachments.insert_one(attachment_doc)
    return attachment_doc

@api_router.post("/upload")
async def upload_file(file: UploadFile = File(...), request: Request = None):
    """Upload a file to Google Drive (or local fallback)"""
    if request:
        await require_role(request, ["admin", "editor"])
    
    contents = await file.read()
    if len(contents) > 10 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="File too large (max 10MB)")
    
    allowed_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.pdf', '.doc', '.docx', '.txt', '.csv', '.xlsx', '.mp3', '.wav', '.webm', '.ogg', '.m4a'}
    ext = Path(file.filename).suffix.lower()
    if ext not in allowed_extensions:
        raise HTTPException(status_code=400, detail=f"File type not allowed: {ext}")
    
    file_type = "image" if ext in {'.jpg', '.jpeg', '.png', '.gif', '.webp'} else "audio" if ext in {'.mp3', '.wav', '.webm', '.ogg', '.m4a'} else "file"
    
    # Try Google Drive upload first (lazy-init folder)
    if GDRIVE_SERVICE:
        folder_id = await get_or_create_gdrive_folder()
        if folder_id:
            mime_type = file.content_type or "application/octet-stream"
            unique_name = f"{uuid.uuid4().hex[:12]}_{file.filename}"
            result = upload_to_gdrive(contents, unique_name, mime_type)
            if result:
                return {
                    "url": result["direct_link"],
                    "filename": file.filename,
                    "type": file_type,
                    "gdrive_file_id": result["gdrive_file_id"],
                    "storage": "gdrive"
                }
    
    # Fallback to local storage (also persist to Drive)
    file_id = uuid.uuid4().hex[:12]
    filename = f"{file_id}{ext}"
    await _persist_image(contents, filename, file.content_type or "application/octet-stream")
    
    return {
        "url": f"/api/uploads/{filename}",
        "filename": file.filename,
        "type": file_type,
        "storage": "local"
    }

@api_router.get("/drive/stream/{file_id}")
async def stream_gdrive_file(file_id: str, download: Optional[str] = None):
    """Proxy a Google Drive file for browser playback (audio/images). No auth required for public share pages."""
    if not GDRIVE_SERVICE:
        raise HTTPException(status_code=503, detail="Google Drive not configured")
    try:
        meta = GDRIVE_SERVICE.files().get(
            fileId=file_id, fields="mimeType,name,size", supportsAllDrives=True
        ).execute()
        mime_type = meta.get("mimeType", "application/octet-stream")
        filename = meta.get("name", "file")

        request = GDRIVE_SERVICE.files().get_media(fileId=file_id, supportsAllDrives=True)
        buffer = io.BytesIO()
        from googleapiclient.http import MediaIoBaseDownload
        downloader = MediaIoBaseDownload(buffer, request)
        done = False
        while not done:
            _, done = downloader.next_chunk()
        buffer.seek(0)

        disposition = "attachment" if download else "inline"
        return StreamingResponse(
            buffer,
            media_type=mime_type,
            headers={
                "Content-Disposition": f'{disposition}; filename="{filename}"',
                "Accept-Ranges": "bytes",
            }
        )
    except Exception as e:
        logger.error(f"Failed to stream file from Drive: {e}")
        raise HTTPException(status_code=404, detail="File not found")

@api_router.delete("/attachments/{attachment_id}")
async def delete_attachment(attachment_id: str, request: Request):
    await require_role(request, ["admin", "editor"])
    
    attachment = await db.attachments.find_one({"attachment_id": attachment_id}, {"_id": 0})
    if not attachment:
        raise HTTPException(status_code=404, detail="Attachment not found")
    
    # Delete from Google Drive if applicable
    if attachment.get("gdrive_file_id"):
        delete_from_gdrive(attachment["gdrive_file_id"])
    # Delete local file if applicable
    elif attachment["url"].startswith("/api/uploads/"):
        filename = attachment["url"].split("/")[-1]
        file_path = UPLOADS_DIR / filename
        if file_path.exists():
            file_path.unlink()
    
    await db.attachments.delete_one({"attachment_id": attachment_id})
    return {"message": "Attachment deleted"}

# ============== SEED DATA ==============

# ============== SCRIPT SHAREABLE LINKS ==============

@api_router.post("/scripts/{script_id}/share")
async def create_script_share_link(script_id: str, request: Request):
    """Create a shareable public link for a script"""
    await require_role(request, ["admin", "editor"])

    script = await db.scripts.find_one({"script_id": script_id}, {"_id": 0})
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")

    existing = await db.shared_links.find_one({"script_id": script_id, "active": True}, {"_id": 0})
    if existing:
        return existing

    share_doc = {
        "share_id": f"share_{uuid.uuid4().hex[:16]}",
        "script_id": script_id,
        "token": uuid.uuid4().hex,
        "active": True,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    await db.shared_links.insert_one(share_doc)
    return {k: v for k, v in share_doc.items() if k != "_id"}

@api_router.get("/scripts/{script_id}/share")
async def get_script_share_link(script_id: str, request: Request):
    """Get existing share link for a script"""
    await get_current_user(request)
    link = await db.shared_links.find_one({"script_id": script_id, "active": True}, {"_id": 0})
    if not link:
        return {"active": False}
    return link

@api_router.delete("/scripts/{script_id}/share")
async def revoke_script_share_link(script_id: str, request: Request):
    """Revoke a script share link"""
    await require_role(request, ["admin", "editor"])
    await db.shared_links.update_many(
        {"script_id": script_id},
        {"$set": {"active": False}}
    )
    return {"message": "Share link revoked"}

@api_router.get("/public/script/{token}")
async def get_public_script(token: str):
    """Public endpoint - no auth required. Returns script with highlights and filtered task details."""
    link = await db.shared_links.find_one({"token": token, "active": True}, {"_id": 0})
    if not link:
        raise HTTPException(status_code=404, detail="Share link not found or expired")

    script_id = link["script_id"]
    script = await db.scripts.find_one({"script_id": script_id}, {"_id": 0})
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")

    tasks = await db.tasks.find({"script_id": script_id}, {"_id": 0}).to_list(10000)
    categories = {c["category_id"]: c for c in await db.categories.find({}, {"_id": 0}).to_list(100)}

    enriched_tasks = []
    for task in tasks:
        cat = categories.get(task.get("category_id", ""), {})
        task_attachments = await db.attachments.find({"task_id": task["task_id"]}, {"_id": 0}).to_list(100)

        enriched_tasks.append({
            "task_id": task["task_id"],
            "selected_text": task["selected_text"],
            "highlight_start": task.get("highlight_start", 0),
            "highlight_end": task.get("highlight_end", 0),
            "category_id": task.get("category_id", ""),
            "category_name": cat.get("name", ""),
            "category_bg_color": cat.get("bg_color", ""),
            "category_text_color": cat.get("text_color", ""),
            "category_border_color": cat.get("border_color", ""),
            "description": task.get("description", ""),
            "attachments_count": len(task_attachments),
            "attachments": task_attachments,
        })

    return {
        "script": {
            "script_id": script["script_id"],
            "name": script["name"],
            "content": script.get("content", ""),
        },
        "tasks": enriched_tasks,
        "categories": list(categories.values()),
    }

# ============== SCRIPT-TO-MEDIA ==============

@api_router.get("/media/ai-status")
async def get_ai_status(request: Request):
    """Check which AI keys are configured and active"""
    await get_current_user(request)
    google_configured = bool(os.environ.get("GOOGLE_API_KEY"))
    anthropic_configured = bool(os.environ.get("ANTHROPIC_API_KEY"))
    return {
        "google_configured": google_configured,
        "anthropic_configured": anthropic_configured,
        "text_model": "Claude Sonnet 4.5 / Gemini 2.5 Flash" if (anthropic_configured or google_configured) else "Not configured",
        "image_model": "Gemini 2.0 Flash (Image)" if google_configured else "Not configured",
        "video_enabled": False,
    }

# Default AI settings per process
DEFAULT_AI_SETTINGS = {
    "character_detection": "gemini",
    "image_prompt_generation": "claude",
    "scene_image_generation": "gemini",   # Gemini image model (always gemini)
    "headshot_generation": "gemini",       # Gemini image model (always gemini)
}

async def _get_ai_settings():
    """Fetch AI settings from DB, or return defaults."""
    doc = await db.ai_settings.find_one({"_id": "global"}, {"_id": 0})
    if doc:
        merged = {**DEFAULT_AI_SETTINGS, **doc}
        return merged
    return dict(DEFAULT_AI_SETTINGS)

@api_router.get("/admin/ai-settings")
async def get_ai_settings_endpoint(request: Request):
    """Get AI model settings for each process."""
    await require_role(request, ["admin"])
    settings = await _get_ai_settings()
    return settings

@api_router.put("/admin/ai-settings")
async def update_ai_settings_endpoint(request: Request):
    """Update AI model settings per process. Only admin."""
    await require_role(request, ["admin"])
    body = await request.json()
    valid_processes = set(DEFAULT_AI_SETTINGS.keys())
    valid_models = {"claude", "gemini"}
    updates = {}
    for key, val in body.items():
        if key in valid_processes and val in valid_models:
            updates[key] = val
    if not updates:
        raise HTTPException(status_code=400, detail="No valid settings provided")
    await db.ai_settings.update_one(
        {"_id": "global"}, {"$set": updates}, upsert=True
    )
    return await _get_ai_settings()

# ============== ANALYTICS ENDPOINTS ==============

@api_router.get("/admin/analytics/summary")
async def get_analytics_summary(request: Request, days: int = 30):
    """Get usage summary: totals by model and operation for the last N days."""
    await require_role(request, ["admin"])
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

    pipeline = [
        {"$match": {"created_at": {"$gte": cutoff}}},
        {"$group": {
            "_id": {"model": "$model", "operation": "$operation"},
            "total_cost": {"$sum": "$cost"},
            "total_input_tokens": {"$sum": "$input_tokens"},
            "total_output_tokens": {"$sum": "$output_tokens"},
            "total_images": {"$sum": "$image_count"},
            "call_count": {"$sum": 1},
        }},
    ]
    results = await db.api_usage_logs.aggregate(pipeline).to_list(100)

    by_model = {}
    by_operation = {}
    grand_total = 0.0
    for r in results:
        model = r["_id"]["model"]
        op = r["_id"]["operation"]
        cost = r["total_cost"]
        grand_total += cost
        by_model.setdefault(model, {"cost": 0, "calls": 0, "input_tokens": 0, "output_tokens": 0, "images": 0})
        by_model[model]["cost"] += cost
        by_model[model]["calls"] += r["call_count"]
        by_model[model]["input_tokens"] += r["total_input_tokens"]
        by_model[model]["output_tokens"] += r["total_output_tokens"]
        by_model[model]["images"] += r["total_images"]
        by_operation.setdefault(op, {"cost": 0, "calls": 0})
        by_operation[op]["cost"] += cost
        by_operation[op]["calls"] += r["call_count"]

    # Round costs
    for v in by_model.values():
        v["cost"] = round(v["cost"], 4)
    for v in by_operation.values():
        v["cost"] = round(v["cost"], 4)

    return {
        "period_days": days,
        "total_cost": round(grand_total, 4),
        "by_model": by_model,
        "by_operation": by_operation,
    }

@api_router.get("/admin/analytics/daily")
async def get_analytics_daily(request: Request, days: int = 30):
    """Get daily cost breakdown for charting."""
    await require_role(request, ["admin"])
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

    logs = await db.api_usage_logs.find(
        {"created_at": {"$gte": cutoff}},
        {"_id": 0, "created_at": 1, "cost": 1, "model": 1}
    ).to_list(50000)

    daily = {}
    for log in logs:
        day = log["created_at"][:10]
        model = log.get("model", "unknown")
        daily.setdefault(day, {})
        daily[day].setdefault(model, 0.0)
        daily[day][model] += log.get("cost", 0)

    # Build sorted list
    result = []
    for day in sorted(daily.keys()):
        entry = {"date": day, "total": 0.0}
        for model, cost in daily[day].items():
            entry[model] = round(cost, 4)
            entry["total"] += cost
        entry["total"] = round(entry["total"], 4)
        result.append(entry)

    return result

@api_router.get("/admin/analytics/recent")
async def get_analytics_recent(request: Request, limit: int = 50):
    """Get recent API usage logs."""
    await require_role(request, ["admin"])
    logs = await db.api_usage_logs.find({}, {"_id": 0}).sort("created_at", -1).to_list(limit)
    return logs



class MediaStyleCreate(BaseModel):
    name: str
    description: str
    headshot_prompt: Optional[str] = ""

class MediaStyleUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    headshot_prompt: Optional[str] = None

class MediaGenerateRequest(BaseModel):
    script_id: str
    selected_text: str
    style_id: str
    reference_image_urls: Optional[List[str]] = []
    character_ids: Optional[List[str]] = []
    camera_angle: Optional[str] = None
    aspect_ratio: Optional[str] = "16:9"

class DetectCharactersRequest(BaseModel):
    script_id: str

class CharacterUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None

# ============== SCRIPT ANALYSIS (ONE-TIME CONTEXT) ==============

@api_router.post("/media/scripts/{script_id}/analyze")
async def analyze_script(script_id: str, request: Request):
    """One-time deep analysis of a script using Claude. Cached in DB."""
    user = await get_current_user(request)

    # Check cache first
    existing = await db.script_contexts.find_one({"script_id": script_id}, {"_id": 0})
    if existing:
        return existing

    # Fetch script
    script = await db.scripts.find_one({"script_id": script_id}, {"_id": 0})
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")

    plain_text = re.sub(r'<[^>]+>', '', script.get("content", ""))

    system_msg = (
        "You are a senior film director and visual storyteller. "
        "Analyze this script for a YouTube video and produce a STRUCTURED ANALYSIS as JSON.\n\n"
        "Your analysis will be used by an image generation system to create visually consistent, "
        "narratively connected storyboard frames. Be precise and visual in your descriptions.\n\n"
        "Output ONLY valid JSON with this exact structure:\n"
        "{\n"
        '  "scenes": [\n'
        '    {\n'
        '      "scene_number": 1,\n'
        '      "text_start": "first 30 chars of scene text...",\n'
        '      "text_end": "last 30 chars of scene text...",\n'
        '      "location": "specific location description",\n'
        '      "time_of_day": "morning/afternoon/evening/night",\n'
        '      "mood": "emotional tone of scene",\n'
        '      "characters_present": ["Name1", "Name2"],\n'
        '      "visual_description": "what this scene looks like cinematically",\n'
        '      "story_arc_position": "setup/rising_action/climax/falling_action/resolution"\n'
        '    }\n'
        '  ],\n'
        '  "characters": [\n'
        '    {\n'
        '      "name": "Character Name",\n'
        '      "visual_description": "detailed physical appearance for image generation",\n'
        '      "role": "protagonist/antagonist/supporting",\n'
        '      "emotional_arc": "brief emotional journey through the story"\n'
        '    }\n'
        '  ],\n'
        '  "cinematic_tone": "overall visual and emotional tone",\n'
        '  "visual_motifs": ["recurring visual element 1", "element 2"],\n'
        '  "color_palette": "dominant colors and lighting style"\n'
        "}\n\n"
        "RULES:\n"
        "- Break the script into logical scenes (each scene = a distinct moment/location/beat)\n"
        "- Be SPECIFIC in visual descriptions — these drive AI image generation\n"
        "- Character visual descriptions should be detailed enough to generate consistent images\n"
        "- Every character mentioned should be in the characters array\n"
        "- text_start and text_end help locate scenes in the script text\n"
    )

    try:
        response, model_used = await _run_text_generation_with_fallback(
            system_msg, f"SCRIPT:\n{plain_text}",
            preferred_model="claude",
            operation="script_analysis",
            script_id=script_id,
            user_id=user["user_id"],
        )

        # Parse JSON from response
        import json as json_mod
        json_str = response
        if "```json" in json_str:
            json_str = json_str.split("```json")[1].split("```")[0]
        elif "```" in json_str:
            json_str = json_str.split("```")[1].split("```")[0]
        analysis = json_mod.loads(json_str.strip())

        # Store in DB
        context_doc = {
            "script_id": script_id,
            "script_name": script.get("name", ""),
            "analysis": analysis,
            "model_used": model_used,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        await db.script_contexts.replace_one(
            {"script_id": script_id}, context_doc, upsert=True
        )

        return context_doc

    except Exception as e:
        logger.error(f"Script analysis failed: {e}")
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

@api_router.get("/media/scripts/{script_id}/context")
async def get_script_context(script_id: str, request: Request):
    """Get cached script context analysis."""
    await get_current_user(request)
    ctx = await db.script_contexts.find_one({"script_id": script_id}, {"_id": 0})
    if not ctx:
        return {"script_id": script_id, "analysis": None}
    return ctx

@api_router.post("/media/scripts/{script_id}/match-scene")
async def match_scene(script_id: str, request: Request):
    """Given highlighted text, find the matching scene and auto-detect characters."""
    await get_current_user(request)
    body = await request.json()
    highlighted_text = body.get("text", "").strip().lower()

    ctx = await db.script_contexts.find_one({"script_id": script_id}, {"_id": 0})
    if not ctx or not ctx.get("analysis"):
        return {"matched_scene": None, "characters": [], "surrounding_scenes": []}

    scenes = ctx["analysis"].get("scenes", [])
    analysis_characters = ctx["analysis"].get("characters", [])

    # Find the best matching scene
    best_match = None
    best_idx = -1
    best_score = 0
    for i, scene in enumerate(scenes):
        # Check if highlighted text overlaps with scene markers
        start = scene.get("text_start", "").lower()
        end = scene.get("text_end", "").lower()
        visual = scene.get("visual_description", "").lower()
        # Score based on text overlap
        score = 0
        words = highlighted_text.split()
        for w in words:
            if len(w) > 3:
                if w in start or w in end or w in visual:
                    score += 1
        # Also check character names
        for char_name in scene.get("characters_present", []):
            if char_name.lower() in highlighted_text:
                score += 3
        if score > best_score:
            best_score = score
            best_match = scene
            best_idx = i

    # Get surrounding scenes
    surrounding = []
    if best_idx >= 0:
        if best_idx > 0:
            surrounding.append({"position": "before", **scenes[best_idx - 1]})
        if best_idx < len(scenes) - 1:
            surrounding.append({"position": "after", **scenes[best_idx + 1]})

    # Map scene characters to DB character IDs
    matched_char_names = best_match.get("characters_present", []) if best_match else []
    db_characters = await db.media_characters.find(
        {"script_id": script_id}, {"_id": 0, "character_id": 1, "name": 1}
    ).to_list(50)

    matched_char_ids = []
    for db_char in db_characters:
        primary_name = db_char["name"].split("(")[0].strip().lower()
        for scene_char in matched_char_names:
            if scene_char.lower() in primary_name or primary_name in scene_char.lower():
                matched_char_ids.append(db_char["character_id"])
                break

    return {
        "matched_scene": best_match,
        "character_ids": matched_char_ids,
        "character_names": matched_char_names,
        "surrounding_scenes": surrounding,
    }

@api_router.get("/media/styles")
async def get_media_styles(request: Request):
    await get_current_user(request)
    styles = await db.media_styles.find({}, {"_id": 0}).sort("created_at", -1).to_list(100)
    return styles

@api_router.post("/media/styles")
async def create_media_style(data: MediaStyleCreate, request: Request):
    user = await require_role(request, ["admin", "editor"])
    style_doc = {
        "style_id": f"style_{uuid.uuid4().hex[:12]}",
        "name": data.name.strip(),
        "description": data.description.strip(),
        "headshot_prompt": (data.headshot_prompt or "").strip(),
        "created_by": user["user_id"],
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.media_styles.insert_one(style_doc)
    return {k: v for k, v in style_doc.items() if k != "_id"}

@api_router.put("/media/styles/{style_id}")
async def update_media_style(style_id: str, data: MediaStyleUpdate, request: Request):
    await require_role(request, ["admin", "editor"])
    updates = {}
    if data.name is not None:
        updates["name"] = data.name.strip()
    if data.description is not None:
        updates["description"] = data.description.strip()
    if data.headshot_prompt is not None:
        updates["headshot_prompt"] = data.headshot_prompt.strip()
    if not updates:
        raise HTTPException(status_code=400, detail="Nothing to update")
    result = await db.media_styles.update_one({"style_id": style_id}, {"$set": updates})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Style not found")
    updated = await db.media_styles.find_one({"style_id": style_id}, {"_id": 0})
    return updated

@api_router.delete("/media/styles/{style_id}")
async def delete_media_style(style_id: str, request: Request):
    await require_role(request, ["admin", "editor"])
    result = await db.media_styles.delete_one({"style_id": style_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Style not found")
    return {"message": "Style deleted"}

@api_router.post("/media/styles/{style_id}/guide-images")
async def upload_style_guide_image(style_id: str, request: Request, file: UploadFile = File(...)):
    """Upload a guide/reference image for a style."""
    await require_role(request, ["admin", "editor"])
    style = await db.media_styles.find_one({"style_id": style_id}, {"_id": 0})
    if not style:
        raise HTTPException(status_code=404, detail="Style not found")
    contents = await file.read()
    if len(contents) > 10 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="File too large (max 10MB)")
    ext = Path(file.filename).suffix.lower()
    if ext not in {'.jpg', '.jpeg', '.png', '.gif', '.webp'}:
        raise HTTPException(status_code=400, detail="Only image files allowed")
    file_id = uuid.uuid4().hex[:12]
    filename = f"style_guide_{file_id}{ext}"
    await _persist_image(contents, filename, file.content_type or "image/png")
    guide_img = {"url": f"/api/uploads/{filename}", "filename": file.filename, "stored_name": filename}
    await db.media_styles.update_one(
        {"style_id": style_id},
        {"$push": {"guide_images": guide_img}}
    )
    updated = await db.media_styles.find_one({"style_id": style_id}, {"_id": 0})
    return updated

@api_router.delete("/media/styles/{style_id}/guide-images")
async def delete_style_guide_image(style_id: str, request: Request):
    """Delete a guide image from a style by url."""
    await require_role(request, ["admin", "editor"])
    body = await request.json()
    url = body.get("url")
    if not url:
        raise HTTPException(status_code=400, detail="url is required")
    # Remove file from disk and Drive
    if url.startswith("/api/uploads/"):
        fname = url.replace("/api/uploads/", "")
        p = UPLOADS_DIR / fname
        if p.exists():
            p.unlink()
        mapping = await db.file_drive_map.find_one({"filename": fname})
        if mapping and mapping.get("gdrive_file_id"):
            delete_from_gdrive(mapping["gdrive_file_id"])
            await db.file_drive_map.delete_one({"filename": fname})
    await db.media_styles.update_one(
        {"style_id": style_id},
        {"$pull": {"guide_images": {"url": url}}}
    )
    updated = await db.media_styles.find_one({"style_id": style_id}, {"_id": 0})
    return updated

# ============== API USAGE TRACKING ==============

# Pricing rates per 1M tokens / per image
PRICING = {
    "claude-sonnet-4.5": {"input_per_m": 3.0, "output_per_m": 15.0},
    "gemini-2.5-flash": {"input_per_m": 0.15, "output_per_m": 0.60},
    "gemini-3.1-flash-image": {"per_image": 0.067},
}

async def _log_api_usage(
    operation: str, model: str, input_tokens: int = 0, output_tokens: int = 0,
    image_count: int = 0, script_id: str = "", user_id: str = "",
):
    """Log an AI API call to the api_usage_logs collection."""
    pricing = PRICING.get(model, {})
    if image_count > 0:
        cost = image_count * pricing.get("per_image", 0.067)
    else:
        cost = (input_tokens * pricing.get("input_per_m", 0) + output_tokens * pricing.get("output_per_m", 0)) / 1_000_000
    doc = {
        "log_id": f"log_{uuid.uuid4().hex[:12]}",
        "operation": operation,
        "model": model,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "image_count": image_count,
        "cost": round(cost, 6),
        "script_id": script_id,
        "user_id": user_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    try:
        await db.api_usage_logs.insert_one(doc)
    except Exception as e:
        logger.warning(f"Failed to log API usage: {e}")

async def _run_text_generation_with_fallback(system_message: str, user_text: str, preferred_model: str = "claude", operation: str = "", script_id: str = "", user_id: str = ""):
    """Run text generation using direct SDKs. Tries preferred model first, falls back to the other. Returns (text, model_used)."""
    import anthropic
    from google import genai

    async def _call_claude(system_msg, user_msg):
        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            raise Exception("ANTHROPIC_API_KEY not configured")
        client = anthropic.Anthropic(api_key=api_key)
        resp = await asyncio.to_thread(
            client.messages.create,
            model="claude-sonnet-4-5",
            max_tokens=4096,
            system=system_msg,
            messages=[{"role": "user", "content": user_msg}],
        )
        in_tok = getattr(resp.usage, "input_tokens", 0) or 0
        out_tok = getattr(resp.usage, "output_tokens", 0) or 0
        await _log_api_usage(operation=operation, model="claude-sonnet-4.5", input_tokens=in_tok, output_tokens=out_tok, script_id=script_id, user_id=user_id)
        return resp.content[0].text

    async def _call_gemini(system_msg, user_msg):
        api_key = os.environ.get("GOOGLE_API_KEY")
        if not api_key:
            raise Exception("GOOGLE_API_KEY not configured")
        client = genai.Client(api_key=api_key)
        resp = await asyncio.to_thread(
            client.models.generate_content,
            model="gemini-2.5-flash",
            contents=f"{system_msg}\n\n{user_msg}",
        )
        meta = getattr(resp, "usage_metadata", None)
        in_tok = getattr(meta, "prompt_token_count", 0) or 0 if meta else 0
        out_tok = getattr(meta, "candidates_token_count", 0) or 0 if meta else 0
        await _log_api_usage(operation=operation, model="gemini-2.5-flash", input_tokens=in_tok, output_tokens=out_tok, script_id=script_id, user_id=user_id)
        return resp.text

    models = [
        ("claude-sonnet-4.5", _call_claude),
        ("gemini-2.5-flash", _call_gemini),
    ]
    if preferred_model == "gemini":
        models = list(reversed(models))

    last_error = None
    for i, (label, fn) in enumerate(models):
        try:
            result = await fn(system_message, user_text)
            model_used = label if i == 0 else f"{label} (fallback)"
            return result, model_used
        except Exception as e:
            logger.warning(f"{label} failed: {e}. {'Falling back...' if i == 0 else ''}")
            last_error = e

    raise Exception(f"Both models failed. Last error: {str(last_error)}")


@api_router.post("/media/generate")
async def generate_media(data: MediaGenerateRequest, request: Request):
    """Orchestrate Claude/Gemini + Nano Banana pipeline for a scene with character support"""
    import time as _time
    t0 = _time.time()
    user = await require_role(request, ["admin", "editor"])

    script = await db.scripts.find_one({"script_id": data.script_id}, {"_id": 0})
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")

    style = await db.media_styles.find_one({"style_id": data.style_id}, {"_id": 0})
    if not style:
        raise HTTPException(status_code=404, detail="Style not found")

    google_key = os.environ.get("GOOGLE_API_KEY")
    if not google_key:
        raise HTTPException(status_code=500, detail="GOOGLE_API_KEY not configured")

    # Fetch characters if provided
    characters_context = ""
    character_ref_parts = []  # (name, image_path) tuples for labeled reference
    if data.character_ids:
        chars = await db.media_characters.find(
            {"character_id": {"$in": data.character_ids}}, {"_id": 0}
        ).to_list(50)
        if chars:
            char_descs = []
            for c in chars:
                # Use visual_spec for detailed appearance, fall back to description
                spec = c.get("visual_spec", "") or c.get("description", "")
                char_descs.append(f"- {c['name']}: {spec}")
                # Prefer headshot from library matching current style, then any headshot
                headshot = await db.character_headshots.find_one(
                    {"character_id": c["character_id"], "style_id": data.style_id},
                    {"_id": 0}, sort=[("created_at", -1)]
                )
                if not headshot:
                    headshot = await db.character_headshots.find_one(
                        {"character_id": c["character_id"]},
                        {"_id": 0}, sort=[("created_at", -1)]
                    )
                ref_url = (headshot or {}).get("image_url") or c.get("image_url")
                if ref_url:
                    img_bytes = await _read_image_bytes(ref_url)
                    if img_bytes:
                        # Save locally temporarily so genai can read it
                        fname = ref_url.split("/")[-1]
                        tmp_path = UPLOADS_DIR / fname
                        if not tmp_path.exists():
                            with open(tmp_path, "wb") as f:
                                f.write(img_bytes)
                        character_ref_parts.append((c["name"], str(tmp_path)))
                        logger.info(f"Character ref image loaded: {c['name']} -> {tmp_path}")
                    else:
                        logger.warning(f"Character ref image NOT found for {c['name']}: {ref_url}")
                else:
                    logger.warning(f"No headshot/image for character: {c['name']}")
            characters_context = (
                "\n=== MANDATORY: ONLY THESE CHARACTERS MAY APPEAR ===\n"
                f"The user selected exactly {len(char_descs)} character(s) for this scene.\n"
                "ONLY the characters listed below may appear. Do NOT add any other characters.\n"
                "Do NOT include characters from the script who are not listed here.\n\n"
                + "\n".join(char_descs) + "\n\n"
                f"TOTAL CHARACTERS ALLOWED IN IMAGE: {len(char_descs)}\n"
                f"ALLOWED NAMES: {', '.join([c['name'] for c in chars])}\n"
                "Any other character is FORBIDDEN.\n"
                "=== END CHARACTER LIST ===\n"
            )
            logger.info(f"Scene generation: {len(char_descs)} characters, {len(character_ref_parts)} ref images")

    camera_context = ""
    if data.camera_angle:
        camera_context = f"\n=== MANDATORY CAMERA ANGLE: {data.camera_angle} ===\nThe image MUST be framed as a {data.camera_angle}. This is the user's selection.\n"

    # Fetch script visual context
    script_context_doc = await db.script_visual_contexts.find_one(
        {"script_id": data.script_id}, {"_id": 0}
    )
    script_ctx = script_context_doc.get("context", {}) if script_context_doc else {}
    scene_context = ""
    if script_ctx:
        ctx_parts = []
        if script_ctx.get("location"):
            ctx_parts.append(f"Location: {script_ctx['location']}")
        if script_ctx.get("time_period"):
            ctx_parts.append(f"Time period: {script_ctx['time_period']}")
        if script_ctx.get("culture"):
            ctx_parts.append(f"Cultural context: {script_ctx['culture']}")
        if script_ctx.get("visual_mood"):
            ctx_parts.append(f"Visual mood: {script_ctx['visual_mood']}")
        if script_ctx.get("key_visual_elements"):
            ctx_parts.append(f"Key visual elements: {script_ctx['key_visual_elements']}")
        if ctx_parts:
            scene_context = "\n=== SCRIPT WORLD CONTEXT (use this to set the scene accurately) ===\n" + "\n".join(ctx_parts) + "\n=== END CONTEXT ===\n"

    generation_id = f"gen_{uuid.uuid4().hex[:12]}"
    gen_doc = {
        "generation_id": generation_id,
        "script_id": data.script_id,
        "script_name": script.get("name", ""),
        "selected_text": data.selected_text,
        "style_id": data.style_id,
        "style_name": style["name"],
        "style_description": style["description"],
        "reference_image_urls": data.reference_image_urls or [],
        "character_ids": data.character_ids or [],
        "camera_angle": data.camera_angle,
        "aspect_ratio": data.aspect_ratio or "16:9",
        "image_prompt": None,
        "video_prompt": None,
        "image_url": None,
        "image_filename": None,
        "status": "generating_prompts",
        "error": None,
        "model_used": None,
        "created_by": user["user_id"],
        "created_by_name": user.get("name", ""),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.media_generations.insert_one(gen_doc)

    # --- Step 1: Text model generates image prompt (Claude with Gemini fallback) ---
    try:
        import json as json_mod
        t1 = _time.time()
        logger.info(f"[TIMING] DB+prep took {t1-t0:.2f}s")

        # Fetch the one-time script analysis context
        script_analysis = await db.script_contexts.find_one(
            {"script_id": data.script_id}, {"_id": 0}
        )
        analysis = script_analysis.get("analysis", {}) if script_analysis else {}

        ref_context = ""
        if data.reference_image_urls:
            ref_context = f"\nReference Images: {len(data.reference_image_urls)} reference image(s) provided for visual consistency.\n"

        aspect_ratio = data.aspect_ratio or "16:9"

        # Collect character names for validation
        char_names = []
        char_names_full = []
        if data.character_ids:
            chars_for_names = await db.media_characters.find(
                {"character_id": {"$in": data.character_ids}}, {"_id": 0, "name": 1}
            ).to_list(50)
            char_names_full = [c["name"] for c in chars_for_names]
            char_names = [c["name"].split("(")[0].strip() for c in chars_for_names]

        # Build the script context block from analysis
        script_context_block = ""
        matched_scene_block = ""
        surrounding_block = ""
        if analysis:
            # Cinematic context
            ctx_parts = []
            if analysis.get("cinematic_tone"):
                ctx_parts.append(f"Cinematic Tone: {analysis['cinematic_tone']}")
            if analysis.get("color_palette"):
                ctx_parts.append(f"Color Palette: {analysis['color_palette']}")
            if analysis.get("visual_motifs"):
                ctx_parts.append(f"Visual Motifs: {', '.join(analysis['visual_motifs'])}")
            if ctx_parts:
                script_context_block = "--- SCRIPT CINEMATIC CONTEXT ---\n" + "\n".join(ctx_parts) + "\n--- END CINEMATIC CONTEXT ---\n\n"

            # Find matching scene from analysis
            scenes = analysis.get("scenes", [])
            highlighted_lower = data.selected_text.lower()
            best_scene = None
            best_idx = -1
            best_score = 0
            for i, scene in enumerate(scenes):
                score = 0
                for field in ["text_start", "text_end", "visual_description", "location"]:
                    val = scene.get(field, "").lower()
                    for word in highlighted_lower.split():
                        if len(word) > 3 and word in val:
                            score += 1
                for cn in scene.get("characters_present", []):
                    if cn.lower() in highlighted_lower:
                        score += 3
                if score > best_score:
                    best_score = score
                    best_scene = scene
                    best_idx = i

            if best_scene:
                matched_scene_block = (
                    f"--- MATCHED SCENE FROM ANALYSIS ---\n"
                    f"Scene #{best_scene.get('scene_number', '?')}: "
                    f"Location: {best_scene.get('location', 'unknown')} | "
                    f"Time: {best_scene.get('time_of_day', 'unknown')} | "
                    f"Mood: {best_scene.get('mood', 'unknown')} | "
                    f"Story Arc: {best_scene.get('story_arc_position', 'unknown')}\n"
                    f"Visual: {best_scene.get('visual_description', '')}\n"
                    f"--- END MATCHED SCENE ---\n\n"
                )
                # Surrounding scenes for continuity
                surrounding_parts = []
                if best_idx > 0:
                    prev = scenes[best_idx - 1]
                    surrounding_parts.append(
                        f"PREVIOUS scene (#{prev.get('scene_number','?')}): {prev.get('location','')} | "
                        f"{prev.get('time_of_day','')} | {prev.get('mood','')} | "
                        f"Visual: {prev.get('visual_description','')[:150]}"
                    )
                if best_idx < len(scenes) - 1:
                    nxt = scenes[best_idx + 1]
                    surrounding_parts.append(
                        f"NEXT scene (#{nxt.get('scene_number','?')}): {nxt.get('location','')} | "
                        f"{nxt.get('time_of_day','')} | {nxt.get('mood','')} | "
                        f"Visual: {nxt.get('visual_description','')[:150]}"
                    )
                if surrounding_parts:
                    surrounding_block = "--- SURROUNDING SCENES (for visual transition) ---\n" + "\n".join(surrounding_parts) + "\n--- END SURROUNDING ---\n\n"

        system_msg = (
            "You are a senior film storyboard artist and visual director. "
            "You create storyboard frames for a YouTube video based on a script.\n\n"
            "Respond ONLY in JSON: {\"image_prompt\": \"...\", \"video_prompt\": \"...\"}\n\n"
            "You have been given a full cinematic analysis of the script. Use it to:\n"
            "- Match the scene's LOCATION, TIME OF DAY, and MOOD in your prompt\n"
            "- Maintain visual CONTINUITY with surrounding scenes\n"
            "- Follow the COLOR PALETTE and VISUAL MOTIFS of the overall production\n"
            "- Position the scene within the STORY ARC (setup scenes feel calm, climax feels intense)\n\n"
            "ABSOLUTE RULES (violation = failure):\n"
            "1. ONLY the characters listed under MANDATORY CHARACTERS may appear in the image. "
            "Do NOT add, infer, or include ANY character not in that list — even if the script mentions them. "
            "If only 1 character is listed, the image must show ONLY that 1 character. No exceptions.\n"
            "2. The camera angle specified by the user MUST be used exactly.\n"
            "3. The aspect ratio MUST match the user's selection.\n"
            "4. Your image_prompt MUST mention each mandatory character BY NAME and include their full physical description.\n"
            "5. If NO mandatory characters are listed, generate a scene without any named characters.\n"
        )

        # Fetch recent generations for visual continuity
        recent_gens = await db.media_generations.find(
            {"script_id": data.script_id, "status": "completed", "image_prompt": {"$ne": None}},
            {"_id": 0, "selected_text": 1, "image_prompt": 1}
        ).sort("created_at", -1).to_list(3)

        continuity_context = ""
        if recent_gens:
            continuity_context = "\n--- PREVIOUSLY GENERATED SCENES (maintain visual continuity) ---\n"
            for i, gen in enumerate(reversed(recent_gens)):
                continuity_context += f"Scene {i+1}: \"{gen['selected_text'][:100]}\"\nPrompt: {gen['image_prompt'][:200]}\n\n"
            continuity_context += "--- END PREVIOUS SCENES ---\n"

        # Build user text with full narrative awareness
        user_text = (
            f"{script_context_block}"
            f"{matched_scene_block}"
            f"{surrounding_block}"
            f"--- HIGHLIGHTED TEXT TO ILLUSTRATE ---\n{data.selected_text}\n--- END HIGHLIGHTED ---\n\n"
            f"{continuity_context}"
            f"Visual Style: {style['name']} - {style['description']}\n"
            f"Aspect Ratio: {aspect_ratio}\n"
            f"{ref_context}\n"
        )

        if data.camera_angle:
            user_text += f"CAMERA ANGLE (mandatory): {data.camera_angle}\n\n"

        # Characters go LAST for recency bias
        if characters_context:
            user_text += characters_context

        user_text += (
            "\nFINAL INSTRUCTION: Generate the image_prompt now. "
            "CHECKLIST before outputting:\n"
            f"1. Does your prompt mention EXACTLY these characters and NO others? Required: {', '.join(char_names) if char_names else 'none'}\n"
            "2. Are there any character names in your prompt that are NOT in the list above? If yes, REMOVE them.\n"
            f"3. Total characters visible in the image must be exactly {len(char_names)}.\n"
            "4. Does the prompt reflect the scene's LOCATION, TIME, and MOOD from the analysis?\n"
            "If any check fails, rewrite before outputting."
        )

        # Use AI settings for prompt generation model
        ai_settings = await _get_ai_settings()
        prompt_model = ai_settings.get("image_prompt_generation", "claude")

        # Collect ALL character names for the script (to detect extras)
        all_script_chars = await db.media_characters.find(
            {"script_id": data.script_id}, {"_id": 0, "name": 1, "character_id": 1}
        ).to_list(50)
        # Get full names of selected characters to avoid false positives
        selected_full_names = " ".join([
            c["name"] for c in all_script_chars
            if c["character_id"] in (data.character_ids or [])
        ]).lower()
        # Only flag excluded chars whose primary name doesn't appear in any selected char's full name
        excluded_char_names = []
        for c in all_script_chars:
            if c["character_id"] not in (data.character_ids or []):
                primary_name = c["name"].split("(")[0].strip()
                if primary_name.lower() not in selected_full_names:
                    excluded_char_names.append(primary_name)

        # Generate with retry if characters are missing or extras are present
        max_attempts = 2
        text_response = None
        model_used = None
        for attempt in range(max_attempts):
            text_response, model_used = await _run_text_generation_with_fallback(
                system_msg, user_text,
                preferred_model=prompt_model,
                operation="image_prompt_generation",
                script_id=data.script_id,
                user_id=user["user_id"],
            )
            # Validate: check for missing AND extra characters
            response_lower = text_response.lower()
            issues = []
            if char_names:
                missing = [name for name in char_names if name.lower() not in response_lower]
                if missing:
                    issues.append(f"MISSING characters: {', '.join(missing)}")
            if excluded_char_names:
                extras = [name for name in excluded_char_names if name.lower() in response_lower]
                if extras:
                    issues.append(f"UNAUTHORIZED characters found (user did NOT select them): {', '.join(extras)}")
            if issues and attempt < max_attempts - 1:
                logger.warning(f"Attempt {attempt+1}: {'; '.join(issues)}. Retrying...")
                user_text += (
                    f"\n\nCRITICAL ERROR IN YOUR PREVIOUS OUTPUT: {'; '.join(issues)}. "
                    f"ONLY these characters are allowed: {', '.join(char_names) if char_names else 'NONE'}. "
                    f"REMOVE any mention of: {', '.join(excluded_char_names)}. Try again."
                )
                continue
            elif issues:
                logger.warning(f"Final attempt still has issues: {'; '.join(issues)}")
            break

        try:
            json_str = text_response
            t2 = _time.time()
            logger.info(f"[TIMING] Text generation took {t2-t1:.2f}s (model: {model_used})")
            if "```json" in json_str:
                json_str = json_str.split("```json")[1].split("```")[0].strip()
            elif "```" in json_str:
                json_str = json_str.split("```")[1].split("```")[0].strip()
            prompts = json_mod.loads(json_str)
            image_prompt = prompts.get("image_prompt", text_response)
            video_prompt = prompts.get("video_prompt", "")
        except (json_mod.JSONDecodeError, IndexError):
            image_prompt = text_response
            video_prompt = ""

        await db.media_generations.update_one(
            {"generation_id": generation_id},
            {"$set": {
                "image_prompt": image_prompt,
                "video_prompt": video_prompt,
                "model_used": model_used,
                "status": "generating_image",
            }}
        )

    except Exception as e:
        logger.error(f"Text generation failed: {e}")
        await db.media_generations.update_one(
            {"generation_id": generation_id},
            {"$set": {"status": "failed", "error": f"Prompt generation failed: {str(e)}"}}
        )
        gen_doc["status"] = "failed"
        gen_doc["error"] = f"Prompt generation failed: {str(e)}"
        return {k: v for k, v in gen_doc.items() if k != "_id"}

    # --- Step 2: Gemini generates scene image (via direct Google API) ---
    try:
        import base64
        from google import genai
        from google.genai.types import GenerateContentConfig, Part, Content, ImageConfig

        client = genai.Client(api_key=google_key)

        # Include character reference images and session reference images
        parts = []

        # Load style guide images first (for consistent style reference)
        if style.get("guide_images"):
            for guide_img in style["guide_images"]:
                try:
                    guide_url = guide_img.get("url", "")
                    img_bytes = await _read_image_bytes(guide_url)
                    if img_bytes:
                        parts.append(Part.from_bytes(data=img_bytes, mime_type="image/png"))
                except Exception:
                    pass
            if parts:
                parts.append(Part.from_text(text="Above: Style guide reference images. Match this exact visual style."))

        # Add LABELED character reference images (critical for consistency)
        for char_name, ref_path in character_ref_parts:
            try:
                from pathlib import Path as PPath
                p = PPath(ref_path)
                if p.exists():
                    with open(p, "rb") as f:
                        ref_bytes = f.read()
                    parts.append(Part.from_text(text=f"Reference headshot of character '{char_name}':"))
                    parts.append(Part.from_bytes(data=ref_bytes, mime_type="image/png"))
            except Exception as ref_err:
                logger.warning(f"Failed to load character ref image {ref_path}: {ref_err}")

        # Add uploaded reference images
        for ref_url in (data.reference_image_urls or []):
            try:
                img_bytes = await _read_image_bytes(ref_url)
                if img_bytes:
                    parts.append(Part.from_bytes(data=img_bytes, mime_type="image/png"))
            except Exception:
                pass

        aspect_ratio = data.aspect_ratio or "16:9"
        if aspect_ratio == "16:9":
            ar_desc = "WIDESCREEN LANDSCAPE (16:9 ratio, width much greater than height, like a movie frame or YouTube thumbnail)"
        else:
            ar_desc = "TALL PORTRAIT (9:16 ratio, height much greater than width, like a phone screen or Instagram story)"

        # Build the final prompt with aspect ratio as the FIRST and LAST instruction
        char_label_list = ", ".join([name for name, _ in character_ref_parts]) if character_ref_parts else "none"

        consistency_text = ""
        if character_ref_parts:
            consistency_text = (
                "CHARACTER CONSISTENCY:\n"
                f"Character reference headshots are provided above for: {char_label_list}.\n"
                "Reproduce the EXACT same face, skin tone, hair, clothing from each reference. "
                "Do NOT change any character's appearance.\n"
                "NOTE: The reference headshots are 1:1 square crops — they are for face reference ONLY. "
                f"The OUTPUT image must still be {aspect_ratio} {ar_desc}.\n\n"
            )
        if style.get("guide_images"):
            consistency_text += "Match the visual style shown in the style guide reference images.\n\n"

        final_prompt = (
            f"OUTPUT IMAGE SIZE: {aspect_ratio} — {ar_desc}.\n"
            f"You MUST generate the image in {aspect_ratio} aspect ratio. This is non-negotiable.\n\n"
            f"{image_prompt}\n\n"
            f"{consistency_text}"
            f"REMINDER: The final image MUST be {aspect_ratio} ({ar_desc}). Do NOT generate a square image."
        )

        parts.append(Part.from_text(text=final_prompt))

        response = await asyncio.to_thread(
            client.models.generate_content,
            model="gemini-3.1-flash-image-preview",
            contents=Content(parts=parts),
            config=GenerateContentConfig(
                response_modalities=["Text", "Image"],
                image_config=ImageConfig(aspect_ratio=aspect_ratio),
            ),
        )

        image_saved = False
        for part in response.candidates[0].content.parts:
            if part.inline_data and part.inline_data.mime_type.startswith("image/"):
                image_data = part.inline_data.data
                image_filename = f"media_{generation_id}.png"
                await _persist_image(image_data, image_filename)
                image_url = f"/api/uploads/{image_filename}"
                await db.media_generations.update_one(
                    {"generation_id": generation_id},
                    {"$set": {"image_url": image_url, "image_filename": image_filename, "status": "completed"}}
                )
                image_saved = True
                await _log_api_usage(operation="scene_image_generation", model="gemini-3.1-flash-image", image_count=1, script_id=data.script_id, user_id=user["user_id"])
                t3 = _time.time()
                logger.info(f"[TIMING] Image generation took {t3-t2:.2f}s | Total: {t3-t0:.2f}s")
                break

        if not image_saved:
            await db.media_generations.update_one(
                {"generation_id": generation_id},
                {"$set": {"status": "failed", "error": "No image generated by Gemini"}}
            )

    except Exception as e:
        logger.error(f"Gemini image generation failed: {e}")
        await db.media_generations.update_one(
            {"generation_id": generation_id},
            {"$set": {"status": "failed", "error": f"Image generation failed: {str(e)}"}}
        )

    final = await db.media_generations.find_one({"generation_id": generation_id}, {"_id": 0})
    return final

@api_router.get("/media/generations")
async def get_media_generations(request: Request, script_id: Optional[str] = None):
    await get_current_user(request)
    query = {}
    if script_id:
        query["script_id"] = script_id
    generations = await db.media_generations.find(query, {"_id": 0}).sort("created_at", -1).to_list(100)
    return generations

@api_router.get("/media/generations/{generation_id}")
async def get_media_generation(generation_id: str, request: Request):
    await get_current_user(request)
    gen = await db.media_generations.find_one({"generation_id": generation_id}, {"_id": 0})
    if not gen:
        raise HTTPException(status_code=404, detail="Generation not found")
    return gen

@api_router.delete("/media/generations/{generation_id}")
async def delete_media_generation(generation_id: str, request: Request):
    await require_role(request, ["admin", "editor"])
    gen = await db.media_generations.find_one({"generation_id": generation_id}, {"_id": 0})
    if not gen:
        raise HTTPException(status_code=404, detail="Generation not found")
    if gen.get("image_filename"):
        img_path = UPLOADS_DIR / gen["image_filename"]
        if img_path.exists():
            img_path.unlink()
        # Also clean up from Drive
        mapping = await db.file_drive_map.find_one({"filename": gen["image_filename"]})
        if mapping and mapping.get("gdrive_file_id"):
            delete_from_gdrive(mapping["gdrive_file_id"])
            await db.file_drive_map.delete_one({"filename": gen["image_filename"]})
    await db.media_generations.delete_one({"generation_id": generation_id})
    return {"message": "Generation deleted"}

# ============== VIDEO GENERATION (Veo 3 Fast) ==============

class VideoGenerateRequest(BaseModel):
    generation_ids: List[str]

@api_router.post("/media/generate-video-from-upload")
async def generate_video_from_upload(request: Request, file: UploadFile = File(...), prompt: str = Form("")):
    """Generate a Veo 3 Fast video from a user-uploaded image"""
    await require_role(request, ["admin", "editor"])

    api_key_google = os.environ.get("GOOGLE_API_KEY")
    if not api_key_google:
        raise HTTPException(status_code=500, detail="GOOGLE_API_KEY not configured")

    # Save uploaded image
    upload_id = f"upload_{uuid.uuid4().hex[:12]}"
    ext = Path(file.filename).suffix or ".png"
    image_filename = f"{upload_id}{ext}"
    content = await file.read()
    await _persist_image(content, image_filename, file.content_type or "image/png")

    image_url = f"/api/uploads/{image_filename}"

    try:
        from google import genai
        from google.genai import types as genai_types
        import mimetypes

        client = genai.Client(api_key=api_key_google)
        mime = mimetypes.guess_type(file.filename)[0] or "image/png"
        image = genai_types.Image(image_bytes=content, mime_type=mime)

        video_prompt = prompt.strip() if prompt.strip() else "Animate this scene with cinematic movement and atmosphere"

        import asyncio
        operation = await asyncio.to_thread(
            client.models.generate_videos,
            model="veo-3.0-fast-generate-001",
            prompt=video_prompt,
            image=image,
            config=genai_types.GenerateVideosConfig(
                number_of_videos=1,
                duration_seconds=8,
                negative_prompt="blurry, low quality, distorted, static",
                person_generation="allow_adult",
            ),
        )

        doc = {
            "upload_video_id": upload_id,
            "image_url": image_url,
            "image_filename": image_filename,
            "video_prompt": video_prompt,
            "video_status": "generating",
            "video_operation": operation.name,
            "video_url": None,
            "video_error": None,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        await db.upload_videos.insert_one(doc)

        return {k: v for k, v in doc.items() if k != "_id"}

    except Exception as e:
        logger.error(f"Video from upload failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/media/poll-upload-videos")
async def poll_upload_videos(request: Request):
    """Poll for uploaded-image video generation completion"""
    await get_current_user(request)

    api_key_google = os.environ.get("GOOGLE_API_KEY")
    if not api_key_google:
        raise HTTPException(status_code=500, detail="GOOGLE_API_KEY not configured")

    body = await request.json()
    upload_ids = body.get("upload_video_ids", [])

    pending = await db.upload_videos.find(
        {"upload_video_id": {"$in": upload_ids}, "video_status": "generating"},
        {"_id": 0}
    ).to_list(50)

    if not pending:
        return {"updated": 0, "results": []}

    from google import genai
    from google.genai.types import GenerateVideosOperation
    client = genai.Client(api_key=api_key_google)

    results = []
    for item in pending:
        op_name = item.get("video_operation")
        if not op_name:
            continue
        try:
            op_obj = GenerateVideosOperation(name=op_name)
            operation = await asyncio.to_thread(client.operations.get, operation=op_obj)

            if operation.done:
                if operation.result and operation.result.generated_videos:
                    vid = operation.result.generated_videos[0]
                    video_data = await asyncio.to_thread(client.files.download, file=vid.video)
                    video_filename = f"video_{item['upload_video_id']}.mp4"
                    video_path = UPLOADS_DIR / video_filename
                    with open(video_path, "wb") as f:
                        f.write(video_data)
                    video_url = f"/api/uploads/{video_filename}"
                    await db.upload_videos.update_one(
                        {"upload_video_id": item["upload_video_id"]},
                        {"$set": {"video_status": "completed", "video_url": video_url, "video_filename": video_filename}}
                    )
                    results.append({"upload_video_id": item["upload_video_id"], "video_status": "completed", "video_url": video_url})
                else:
                    error_msg = "No video in result"
                    if operation.result and operation.result.rai_media_filtered_reasons:
                        error_msg = "; ".join(operation.result.rai_media_filtered_reasons)
                    await db.upload_videos.update_one(
                        {"upload_video_id": item["upload_video_id"]},
                        {"$set": {"video_status": "failed", "video_error": error_msg}}
                    )
                    results.append({"upload_video_id": item["upload_video_id"], "video_status": "failed", "video_error": error_msg})
            else:
                results.append({"upload_video_id": item["upload_video_id"], "video_status": "generating"})
        except Exception as e:
            logger.error(f"Upload video poll failed: {e}")
            await db.upload_videos.update_one(
                {"upload_video_id": item["upload_video_id"]},
                {"$set": {"video_status": "failed", "video_error": str(e)}}
            )
            results.append({"upload_video_id": item["upload_video_id"], "video_status": "failed", "video_error": str(e)})

    return {"updated": len([r for r in results if r["video_status"] != "generating"]), "results": results}

@api_router.get("/media/upload-videos")
async def get_upload_videos(request: Request):
    """Get all uploaded-image video generations"""
    await get_current_user(request)
    items = await db.upload_videos.find({}, {"_id": 0}).sort("created_at", -1).to_list(50)
    return items

@api_router.post("/media/generate-videos")
async def generate_videos_batch(data: VideoGenerateRequest, request: Request):
    """Start Veo 3 Fast video generation for selected image generations"""
    await require_role(request, ["admin", "editor"])

    api_key_google = os.environ.get("GOOGLE_API_KEY")
    if not api_key_google:
        raise HTTPException(status_code=500, detail="GOOGLE_API_KEY not configured")

    results = []
    for gen_id in data.generation_ids:
        gen = await db.media_generations.find_one({"generation_id": gen_id}, {"_id": 0})
        if not gen or not gen.get("image_filename"):
            results.append({"generation_id": gen_id, "video_status": "failed", "video_error": "No image found"})
            continue

        img_bytes = await _read_image_bytes(gen["image_filename"])
        if not img_bytes:
            results.append({"generation_id": gen_id, "video_status": "failed", "video_error": "Image file missing"})
            continue

        try:
            from google import genai
            from google.genai import types as genai_types

            client = genai.Client(api_key=api_key_google)

            image = genai_types.Image(image_bytes=img_bytes, mime_type="image/png")

            video_prompt = gen.get("video_prompt") or gen.get("image_prompt") or gen.get("selected_text", "Animate this scene")
            video_prompt = f"Animate this scene with cinematic movement and atmosphere: {video_prompt[:300]}"

            import asyncio
            operation = await asyncio.to_thread(
                client.models.generate_videos,
                model="veo-3.0-fast-generate-001",
                prompt=video_prompt,
                image=image,
                config=genai_types.GenerateVideosConfig(
                    number_of_videos=1,
                    duration_seconds=8,
                    negative_prompt="blurry, low quality, distorted, static",
                    person_generation="allow_adult",
                ),
            )

            await db.media_generations.update_one(
                {"generation_id": gen_id},
                {"$set": {
                    "video_status": "generating",
                    "video_operation": operation.name,
                    "video_error": None,
                }}
            )
            results.append({"generation_id": gen_id, "video_status": "generating", "video_operation": operation.name})

        except Exception as e:
            logger.error(f"Veo 3 video generation failed for {gen_id}: {e}")
            await db.media_generations.update_one(
                {"generation_id": gen_id},
                {"$set": {"video_status": "failed", "video_error": str(e)}}
            )
            results.append({"generation_id": gen_id, "video_status": "failed", "video_error": str(e)})

    return {"results": results}

@api_router.post("/media/poll-videos")
async def poll_video_status(request: Request):
    """Poll for video generation completion and download finished videos"""
    await get_current_user(request)

    api_key_google = os.environ.get("GOOGLE_API_KEY")
    if not api_key_google:
        raise HTTPException(status_code=500, detail="GOOGLE_API_KEY not configured")

    body = await request.json()
    generation_ids = body.get("generation_ids", [])

    pending = await db.media_generations.find(
        {"generation_id": {"$in": generation_ids}, "video_status": "generating"},
        {"_id": 0}
    ).to_list(50)

    if not pending:
        return {"updated": 0, "results": []}

    from google import genai
    from google.genai.types import GenerateVideosOperation
    client = genai.Client(api_key=api_key_google)

    updated_count = 0
    results = []
    for gen in pending:
        op_name = gen.get("video_operation")
        if not op_name:
            continue

        try:
            op_obj = GenerateVideosOperation(name=op_name)
            operation = await asyncio.to_thread(client.operations.get, operation=op_obj)

            if operation.done:
                if operation.result and operation.result.generated_videos:
                    vid = operation.result.generated_videos[0]
                    logger.info(f"Video completed for {gen['generation_id']}, URI: {vid.video.uri if vid.video else 'None'}")
                    video_data = await asyncio.to_thread(client.files.download, file=vid.video)
                    video_filename = f"video_{gen['generation_id']}.mp4"
                    video_path = UPLOADS_DIR / video_filename
                    with open(video_path, "wb") as f:
                        f.write(video_data)

                    video_url = f"/api/uploads/{video_filename}"
                    await db.media_generations.update_one(
                        {"generation_id": gen["generation_id"]},
                        {"$set": {
                            "video_status": "completed",
                            "video_url": video_url,
                            "video_filename": video_filename,
                        }}
                    )
                    results.append({"generation_id": gen["generation_id"], "video_status": "completed", "video_url": video_url})
                else:
                    error_msg = "No video in result"
                    if operation.result and operation.result.rai_media_filtered_reasons:
                        error_msg = "; ".join(operation.result.rai_media_filtered_reasons)
                    await db.media_generations.update_one(
                        {"generation_id": gen["generation_id"]},
                        {"$set": {"video_status": "failed", "video_error": error_msg}}
                    )
                    results.append({"generation_id": gen["generation_id"], "video_status": "failed", "video_error": error_msg})
                updated_count += 1
            else:
                results.append({"generation_id": gen["generation_id"], "video_status": "generating"})

        except Exception as e:
            logger.error(f"Video poll failed for {gen['generation_id']}: {e}")
            await db.media_generations.update_one(
                {"generation_id": gen["generation_id"]},
                {"$set": {"video_status": "failed", "video_error": str(e)}}
            )
            results.append({"generation_id": gen["generation_id"], "video_status": "failed", "video_error": str(e)})
            updated_count += 1

    return {"updated": updated_count, "results": results}

# ============== CHARACTER LIBRARY ==============

@api_router.post("/media/detect-characters")
async def detect_characters(data: DetectCharactersRequest, request: Request):
    """Use Claude (or Gemini fallback) to detect ALL characters from the entire script"""
    await require_role(request, ["admin", "editor"])

    script = await db.scripts.find_one({"script_id": data.script_id}, {"_id": 0})
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")

    api_key = os.environ.get("GOOGLE_API_KEY")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key and not anthropic_key:
        raise HTTPException(status_code=500, detail="No LLM API keys configured (need GOOGLE_API_KEY or ANTHROPIC_API_KEY)")

    try:
        import json as json_mod

        plain_script = re.sub(r'<[^>]+>', '', script.get("content", ""))

        system_msg = (
            "You are an expert script analyst and character designer. Analyze the ENTIRE script and detect ALL characters mentioned. "
            "For each character, provide:\n"
            "1. A short 'description' (role in the story, personality)\n"
            "2. A detailed 'visual_spec' — a FIXED, precise visual identity card that will be used to generate "
            "consistent images across multiple scenes. The visual_spec MUST include ALL of the following:\n"
            "   - Exact age (e.g. '28 years old')\n"
            "   - Gender and ethnicity/skin tone (e.g. 'South Asian woman with warm brown skin')\n"
            "   - Face shape and key facial features (e.g. 'oval face, sharp jawline, large expressive brown eyes, thin nose, full lips')\n"
            "   - Hair (color, length, style — e.g. 'long straight black hair, usually tied in a loose braid')\n"
            "   - Body type (e.g. 'slim build, average height')\n"
            "   - Signature clothing/outfit (e.g. 'wears a maroon kurta with gold embroidery and cream dupatta')\n"
            "   - Any distinctive features (e.g. 'small nose ring on left nostril, silver jhumka earrings')\n\n"
            "IMPORTANT: For unnamed characters, smartly derive a contextual name by linking them to a named character. "
            "For example: \"Priya's Boyfriend\", \"Ravi's Mother\", \"[Name]'s Boss\" etc. "
            "Never leave a character as \"Unknown\" or \"Unnamed\".\n\n"
            "ADDITIONALLY, analyze the script's overall context and provide a 'script_context' object with:\n"
            "- 'location': Primary location/city/region (e.g. 'Mumbai, India', 'Rural Rajasthan', 'New York')\n"
            "- 'time_period': When the story is set (e.g. '1990s', 'modern day', 'pre-independence India 1940s')\n"
            "- 'culture': Cultural context (e.g. 'middle-class Maharashtrian family', 'urban Gen-Z lifestyle')\n"
            "- 'visual_mood': Overall visual tone (e.g. 'warm earthy tones, dusty streets', 'neon-lit cyberpunk')\n"
            "- 'key_visual_elements': Important recurring visual elements from the script (e.g. 'chawl buildings, local trains, street food stalls')\n\n"
            "Respond ONLY in this exact JSON format:\n"
            '{"script_context": {"location": "...", "time_period": "...", "culture": "...", "visual_mood": "...", "key_visual_elements": "..."}, '
            '"characters": [{"name": "Character Name", "description": "short role description", "visual_spec": "detailed fixed visual identity"}]}'
        )

        user_text = (
            f"Full Script:\n{plain_script}\n\n"
            "1. First, analyze the script's setting, location, culture, time period, and visual mood to create a 'script_context'.\n"
            "2. Then detect ALL characters. For unnamed characters, derive a contextual name by linking them to a named character.\n"
            "3. For each character, use the script context to inform their visual_spec — if the story is set in Mumbai, "
            "characters should look Indian with appropriate clothing; if set in 1950s, clothing and hair should match that era.\n"
            "The visual_spec must include: age, skin tone, face shape, eyes, nose, lips, hair color/style/length, "
            "body type, signature outfit (culturally appropriate to the script's setting), accessories."
        )

        # Use AI settings for character detection model
        ai_settings = await _get_ai_settings()
        detect_model = ai_settings.get("character_detection", "gemini")

        response, model_used = await _run_text_generation_with_fallback(
            system_msg, user_text,
            preferred_model=detect_model,
            operation="character_detection",
            script_id=data.script_id,
            user_id=user["user_id"],
        )

        try:
            json_str = response
            if "```json" in json_str:
                json_str = json_str.split("```json")[1].split("```")[0].strip()
            elif "```" in json_str:
                json_str = json_str.split("```")[1].split("```")[0].strip()
            parsed = json_mod.loads(json_str)

            # Handle both new format (with script_context) and old format (array)
            if isinstance(parsed, dict):
                characters = parsed.get("characters", [])
                script_context = parsed.get("script_context", {})
            else:
                characters = parsed
                script_context = {}

            # Save script_context to DB for use in all image generation
            if script_context:
                await db.script_visual_contexts.update_one(
                    {"script_id": data.script_id},
                    {"$set": {
                        "script_id": data.script_id,
                        "context": script_context,
                        "updated_at": datetime.now(timezone.utc).isoformat(),
                    }},
                    upsert=True,
                )

        except (json_mod.JSONDecodeError, IndexError):
            characters = [{"name": "Unknown", "description": response}]
            script_context = {}

        return {"characters": characters, "script_context": script_context, "model_used": model_used}

    except Exception as e:
        logger.error(f"Character detection failed: {e}")
        raise HTTPException(status_code=500, detail=f"Character detection failed: {str(e)}")

@api_router.post("/media/scripts/{script_id}/detect-scene-characters")
async def detect_scene_characters(script_id: str, request: Request):
    """Use AI to detect which characters are present in a scene text, based on context."""
    await require_role(request, ["admin", "editor"])
    body = await request.json()
    scene_text = body.get("scene_text", "").strip()
    if not scene_text:
        return {"character_ids": []}

    # Fetch all characters for this script
    characters = await db.media_characters.find({"script_id": script_id}, {"_id": 0}).to_list(100)
    if not characters:
        return {"character_ids": []}

    # Fetch the full script for context
    script = await db.scripts.find_one({"script_id": script_id}, {"_id": 0})
    if not script:
        return {"character_ids": []}

    import re
    plain_script = re.sub(r'<[^>]+>', ' ', script.get("content", ""))[:3000]

    # Build character list for the AI
    char_list = "\n".join([f'- ID: {c["character_id"]} | Name: {c["name"]} | Description: {c["description"]}' for c in characters])

    system_msg = (
        "You are a script analysis assistant. Given a scene excerpt from a script and a list of characters, "
        "determine which characters are PRESENT or REFERENCED in the scene. "
        "A character can be referenced directly by name, by description, by role, by pronoun, or by ANY contextual hint. "
        "For example, if the script mentions 'saahukar' and there's a character called 'Moneylender', match them. "
        "If the scene says 'he handed money to the old man' and 'Great Grandfather' is a character, match them. "
        "Use the full script context to understand relationships and references.\n\n"
        "Respond with ONLY a JSON array of character_ids that are present in the scene. Example: [\"char_abc123\", \"char_def456\"]"
    )

    user_text = (
        f"FULL SCRIPT (for context):\n{plain_script}\n\n"
        f"SCENE TEXT:\n{scene_text}\n\n"
        f"CHARACTERS:\n{char_list}\n\n"
        "Which characters are present or referenced in this scene? Return ONLY a JSON array of character_ids."
    )

    try:
        ai_settings = await _get_ai_settings()
        detect_model = ai_settings.get("character_detection", "gemini")
        response, _ = await _run_text_generation_with_fallback(system_msg, user_text, preferred_model=detect_model, operation="scene_character_detection", script_id=script_id)

        # Parse the response — expect a JSON array
        import json as json_mod
        # Clean response — extract JSON array from text
        response = response.strip()
        if "```" in response:
            response = response.split("```")[1].replace("json", "").strip()
        # Find the array
        start = response.find("[")
        end = response.rfind("]") + 1
        if start >= 0 and end > start:
            char_ids = json_mod.loads(response[start:end])
            # Validate — only return IDs that actually exist
            valid_ids = {c["character_id"] for c in characters}
            matched = [cid for cid in char_ids if cid in valid_ids]
            return {"character_ids": matched}
        return {"character_ids": []}
    except Exception as e:
        logger.error(f"Scene character detection failed: {e}")
        return {"character_ids": []}

@api_router.get("/media/scripts/{script_id}/characters")
async def get_characters(script_id: str, request: Request):
    await get_current_user(request)
    chars = await db.media_characters.find({"script_id": script_id}, {"_id": 0}).sort("created_at", 1).to_list(100)
    return chars

@api_router.post("/media/scripts/{script_id}/characters")
async def save_characters(script_id: str, request: Request, characters: List[dict] = Body(...)):
    """Batch save detected characters to the library"""
    user = await require_role(request, ["admin", "editor"])
    saved = []
    for c in characters:
        name = c.get("name", "").strip()
        desc = c.get("description", "").strip()
        visual_spec = c.get("visual_spec", "").strip()
        if not name:
            continue
        existing = await db.media_characters.find_one(
            {"script_id": script_id, "name": {"$regex": f"^{re.escape(name)}$", "$options": "i"}},
            {"_id": 0}
        )
        if existing:
            update_fields = {"description": desc}
            if visual_spec:
                update_fields["visual_spec"] = visual_spec
            await db.media_characters.update_one(
                {"character_id": existing["character_id"]},
                {"$set": update_fields}
            )
            existing["description"] = desc
            if visual_spec:
                existing["visual_spec"] = visual_spec
            saved.append(existing)
        else:
            doc = {
                "character_id": f"char_{uuid.uuid4().hex[:12]}",
                "script_id": script_id,
                "name": name,
                "description": desc,
                "visual_spec": visual_spec,
                "image_url": None,
                "image_filename": None,
                "created_by": user["user_id"],
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
            await db.media_characters.insert_one(doc)
            saved.append({k: v for k, v in doc.items() if k != "_id"})
    return saved

@api_router.put("/media/characters/{character_id}")
async def update_character(character_id: str, data: CharacterUpdate, request: Request):
    await require_role(request, ["admin", "editor"])
    updates = {}
    if data.name is not None:
        updates["name"] = data.name.strip()
    if data.description is not None:
        updates["description"] = data.description.strip()
    if not updates:
        raise HTTPException(status_code=400, detail="Nothing to update")
    result = await db.media_characters.update_one({"character_id": character_id}, {"$set": updates})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Character not found")
    updated = await db.media_characters.find_one({"character_id": character_id}, {"_id": 0})
    return updated

@api_router.delete("/media/characters/{character_id}")
async def delete_character(character_id: str, request: Request):
    await require_role(request, ["admin", "editor"])
    char = await db.media_characters.find_one({"character_id": character_id}, {"_id": 0})
    if not char:
        raise HTTPException(status_code=404, detail="Character not found")
    if char.get("image_filename"):
        img_path = UPLOADS_DIR / char["image_filename"]
        if img_path.exists():
            img_path.unlink()
    await db.media_characters.delete_one({"character_id": character_id})
    return {"message": "Character deleted"}

@api_router.post("/media/characters/{character_id}/generate-image")
async def generate_character_image(character_id: str, request: Request):
    """Generate one image for a character using direct Google API, with visual_spec, style, and reference-based consistency"""
    await require_role(request, ["admin", "editor"])

    # Parse optional style_id from request body
    style = None
    try:
        body = await request.json()
        style_id = body.get("style_id")
        if style_id:
            style = await db.media_styles.find_one({"style_id": style_id}, {"_id": 0})
    except Exception:
        pass

    char = await db.media_characters.find_one({"character_id": character_id}, {"_id": 0})
    if not char:
        raise HTTPException(status_code=404, detail="Character not found")

    # Fetch script visual context for cultural/location accuracy
    script_context_doc = await db.script_visual_contexts.find_one(
        {"script_id": char.get("script_id")}, {"_id": 0}
    )
    script_ctx = script_context_doc.get("context", {}) if script_context_doc else {}

    google_key = os.environ.get("GOOGLE_API_KEY")
    if not google_key:
        raise HTTPException(status_code=500, detail="GOOGLE_API_KEY not configured")

    try:
        from google import genai
        from google.genai.types import GenerateContentConfig, Part, Content

        client = genai.Client(api_key=google_key)

        # Build style instruction
        style_instruction = ""
        if style:
            style_instruction = f"\nART STYLE (apply this style to the entire image): {style['name']} — {style.get('description', '')}\n"

        # Build script context instruction
        context_instruction = ""
        if script_ctx:
            parts_ctx = []
            if script_ctx.get("location"):
                parts_ctx.append(f"Location: {script_ctx['location']}")
            if script_ctx.get("time_period"):
                parts_ctx.append(f"Time period: {script_ctx['time_period']}")
            if script_ctx.get("culture"):
                parts_ctx.append(f"Culture: {script_ctx['culture']}")
            if parts_ctx:
                context_instruction = "\nSCRIPT CONTEXT (character must reflect this setting):\n" + "\n".join(parts_ctx) + "\n"

        # Build a highly specific prompt using visual_spec if available
        visual_spec = char.get("visual_spec", "")
        if visual_spec:
            prompt = (
                f"Generate a close-up headshot of: {char['name']}.\n\n"
                f"EXACT VISUAL SPECIFICATION (follow precisely):\n{visual_spec}\n"
                f"{context_instruction}"
                f"{style_instruction}\n"
                "STRICT Requirements:\n"
                "- ONLY head and neck visible, cropped tightly at the collarbone — absolutely NO torso, hands, or body\n"
                "- Plain solid white background, no gradients, no environment\n"
                "- Face fills 70% of the frame, centered\n"
                "- Slight 3/4 angle, eyes looking at camera\n"
                "- Professional studio lighting, sharp focus on face\n"
                "- Show facial features, hair, and any face/ear accessories (earrings, nose ring) only\n"
                "- Do NOT show any hands, arms, props, or objects\n"
                + ("- Apply the specified art style to the entire portrait\n" if style else "- Photorealistic passport-photo style headshot\n")
            )
        else:
            prompt = (
                f"Generate a close-up headshot of: {char['name']}.\n"
                f"Visual description: {char['description']}.\n"
                f"{context_instruction}"
                f"{style_instruction}\n"
                "ONLY head and neck visible, cropped at collarbone. Plain solid white background. "
                "Face fills 70% of frame, centered, 3/4 angle. NO torso, hands, arms, props, or environment. "
                "Professional studio lighting. "
                + ("Apply the specified art style to the entire portrait." if style else "Photorealistic passport-photo style headshot.")
            )

        # If character already has an image (regeneration), pass it as reference for consistency
        parts = []
        if char.get("image_url"):
            existing_path = None
            url = char["image_url"]
            if url.startswith("/api/uploads/"):
                existing_path = UPLOADS_DIR / url.replace("/api/uploads/", "")
            elif url.startswith("/uploads/"):
                existing_path = UPLOADS_DIR / url.replace("/uploads/", "")
            if existing_path and existing_path.exists():
                with open(existing_path, "rb") as f:
                    ref_bytes = f.read()
                parts.append(Part.from_bytes(data=ref_bytes, mime_type="image/png"))
                prompt += (
                    "\n\nIMPORTANT: A reference image of this character is provided. "
                    "Generate a new portrait that maintains the EXACT SAME face, skin tone, hair, "
                    "and clothing as the reference. Only improve quality and clarity."
                )

        parts.append(Part.from_text(text=prompt))

        response = await asyncio.to_thread(
            client.models.generate_content,
            model="gemini-3.1-flash-image-preview",
            contents=Content(parts=parts),
            config=GenerateContentConfig(response_modalities=["Text", "Image"]),
        )

        for part in response.candidates[0].content.parts:
            if part.inline_data and part.inline_data.mime_type.startswith("image/"):
                image_data = part.inline_data.data
                image_filename = f"char_{character_id}.png"
                await _persist_image(image_data, image_filename)

                image_url = f"/api/uploads/{image_filename}"
                await db.media_characters.update_one(
                    {"character_id": character_id},
                    {"$set": {"image_url": image_url, "image_filename": image_filename}}
                )
                char["image_url"] = image_url
                char["image_filename"] = image_filename
                await _log_api_usage(operation="character_image_generation", model="gemini-3.1-flash-image", image_count=1, script_id=char.get("script_id", ""), user_id=user["user_id"])
                return char

        raise HTTPException(status_code=500, detail="No image generated")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Character image generation failed: {e}")
        raise HTTPException(status_code=500, detail=f"Image generation failed: {str(e)}")



@api_router.post("/media/scripts/{script_id}/clear-all-characters")
async def clear_all_characters(script_id: str, request: Request):
    """Delete all characters and headshots for a script."""
    await require_role(request, ["admin", "editor"])
    # Delete headshot files
    headshots = await db.character_headshots.find({"script_id": script_id}, {"_id": 0}).to_list(500)
    for hs in headshots:
        if hs.get("image_filename"):
            p = UPLOADS_DIR / hs["image_filename"]
            if p.exists():
                p.unlink()
    # Delete character image files
    chars = await db.media_characters.find({"script_id": script_id}, {"_id": 0}).to_list(100)
    for c in chars:
        if c.get("image_filename"):
            p = UPLOADS_DIR / c["image_filename"]
            if p.exists():
                p.unlink()
    await db.character_headshots.delete_many({"script_id": script_id})
    await db.media_characters.delete_many({"script_id": script_id})
    await db.headshot_batches.delete_many({"script_id": script_id})
    await db.script_visual_contexts.delete_many({"script_id": script_id})
    return {"message": "All characters and headshots cleared"}

# ============== CHARACTER HEADSHOT LIBRARY ==============

@api_router.get("/media/scripts/{script_id}/headshots")
async def get_headshots(script_id: str, request: Request, style_id: Optional[str] = None):
    """Get all character headshots for a script, optionally filtered by style."""
    await get_current_user(request)
    query = {"script_id": script_id}
    if style_id:
        query["style_id"] = style_id
    headshots = await db.character_headshots.find(query, {"_id": 0}).sort("created_at", -1).to_list(500)
    return headshots

@api_router.post("/media/scripts/{script_id}/generate-headshots")
async def generate_selected_headshots(script_id: str, request: Request):
    """Generate 1:1 styled headshots for selected characters. Uses style guide images as reference."""
    await require_role(request, ["admin", "editor"])
    body = await request.json()
    style_id = body.get("style_id")
    character_ids = body.get("character_ids", [])
    if not style_id:
        raise HTTPException(status_code=400, detail="style_id is required")
    if not character_ids:
        raise HTTPException(status_code=400, detail="character_ids is required")

    style = await db.media_styles.find_one({"style_id": style_id}, {"_id": 0})
    if not style:
        raise HTTPException(status_code=404, detail="Style not found")

    characters = await db.media_characters.find(
        {"script_id": script_id, "character_id": {"$in": character_ids}}, {"_id": 0}
    ).to_list(100)
    if not characters:
        raise HTTPException(status_code=404, detail="No matching characters found")

    google_key = os.environ.get("GOOGLE_API_KEY")
    if not google_key:
        raise HTTPException(status_code=500, detail="GOOGLE_API_KEY not configured")

    force = body.get("force", False)

    if force:
        # Delete existing headshots for these characters in this style (for regeneration)
        old_hs = await db.character_headshots.find(
            {"script_id": script_id, "style_id": style_id, "character_id": {"$in": character_ids}},
            {"_id": 0}
        ).to_list(100)
        for hs in old_hs:
            if hs.get("image_filename"):
                p = UPLOADS_DIR / hs["image_filename"]
                if p.exists():
                    p.unlink()
        await db.character_headshots.delete_many(
            {"script_id": script_id, "style_id": style_id, "character_id": {"$in": character_ids}}
        )
        chars_to_generate = list(characters)
        existing_char_ids = set()
    else:
        # Skip characters that already have headshots in this style
        existing = await db.character_headshots.find(
            {"script_id": script_id, "style_id": style_id, "character_id": {"$in": character_ids}},
            {"_id": 0, "character_id": 1}
        ).to_list(100)
        existing_char_ids = {h["character_id"] for h in existing}
        chars_to_generate = [c for c in characters if c["character_id"] not in existing_char_ids]

    if not chars_to_generate:
        return {"message": "Headshots already exist for selected characters", "generated": 0, "total": len(characters)}

    batch_id = f"batch_{uuid.uuid4().hex[:12]}"
    await db.headshot_batches.insert_one({
        "_id": batch_id, "batch_id": batch_id, "script_id": script_id,
        "style_id": style_id, "total": len(chars_to_generate),
        "completed": 0, "failed": 0, "status": "generating",
        "created_at": datetime.now(timezone.utc).isoformat(),
    })

    asyncio.create_task(_generate_headshots_batch(
        batch_id, script_id, style_id, style, chars_to_generate, google_key
    ))

    return {"batch_id": batch_id, "generating": len(chars_to_generate), "skipped": len(existing_char_ids), "total": len(characters)}

@api_router.get("/media/headshot-batch/{batch_id}")
async def get_headshot_batch_status(batch_id: str, request: Request):
    """Poll the status of a headshot generation batch."""
    await get_current_user(request)
    batch = await db.headshot_batches.find_one({"batch_id": batch_id}, {"_id": 0})
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    return batch

async def _generate_headshots_batch(batch_id, script_id, style_id, style, characters, google_key):
    """Background task: generate 1:1 styled headshots using style guide images as reference.
    Generates headshots in PARALLEL (up to 3 concurrent) for speed."""
    from google import genai
    from google.genai.types import GenerateContentConfig, Part, Content

    client = genai.Client(api_key=google_key)

    style_instruction = f"ART STYLE (apply to entire image): {style['name']} — {style.get('description', '')}"

    # Load style guide images once (shared across all characters)
    guide_image_parts = []
    for guide_img in (style.get("guide_images") or []):
        try:
            guide_url = guide_img.get("url", "")
            img_bytes = await _read_image_bytes(guide_url)
            if img_bytes:
                guide_image_parts.append(Part.from_bytes(data=img_bytes, mime_type="image/png"))
        except Exception as e:
            logger.warning(f"Failed to load style guide image: {e}")

    guide_ref_text = ""
    if guide_image_parts:
        guide_ref_text = (
            "\nSTYLE GUIDE REFERENCE IMAGES are attached above. "
            "You MUST match the exact art style, rendering technique, color palette, and visual quality "
            "shown in these reference images. The headshot should look like it belongs in the same series."
        )

    # Semaphore for concurrency control (max 3 parallel headshot generations)
    sem = asyncio.Semaphore(3)
    completed = 0
    failed = 0

    async def _gen_single_headshot(char):
        nonlocal completed, failed
        async with sem:
            saved = False
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    visual_spec = char.get("visual_spec", "")
                    custom_headshot_prompt = style.get("headshot_prompt", "").strip()

                    # NEUTRALITY OVERRIDE — strip all emotional/narrative context from headshots
                    neutrality_block = (
                        "\n\nCRITICAL NEUTRALITY RULES (override everything else):\n"
                        "- NEUTRAL expression ONLY. No emotion. No smile, no frown, no sadness, no anger, no tiredness.\n"
                        "- NO dark circles, NO bags under eyes, NO wrinkles from stress, NO tears, NO sweat.\n"
                        "- NO narrative or emotional context. This is a CLEAN, NEUTRAL reference portrait.\n"
                        "- Ignore any emotional descriptors in the character description (e.g. 'tired', 'worried', 'stressed', 'weathered', 'sad').\n"
                        "- ONLY use PHYSICAL traits: face shape, skin tone, eye color, hair color/style, facial hair, age range, build.\n"
                        "- Think of this as an actor's headshot or ID photo — clean, well-lit, neutral expression, no story.\n"
                        "- Plain white or light grey background. Professional studio lighting.\n"
                    )

                    if custom_headshot_prompt:
                        char_detail = visual_spec if visual_spec else char.get("description", "")
                        prompt = (
                            f"Character: {char['name']}\n"
                            f"Physical traits ONLY from this spec (ignore emotional/mood words): {char_detail}\n\n"
                            f"{custom_headshot_prompt}\n"
                            f"{neutrality_block}"
                            "You MUST generate an image. Do not respond with text only."
                            f"{guide_ref_text}"
                        )
                    elif visual_spec:
                        prompt = (
                            f"Generate a 1:1 SQUARE close-up headshot of: {char['name']}.\n\n"
                            f"PHYSICAL TRAITS ONLY (ignore any emotional/mood words):\n{visual_spec}\n\n"
                            f"{style_instruction}\n\n"
                            "- Output MUST be a perfect SQUARE (1:1 aspect ratio).\n"
                            "- ONLY head and neck, cropped at collarbone.\n"
                            "- Face fills 70% of frame, 3/4 angle. NO torso/hands/arms/props.\n"
                            "- Apply the specified art style to the entire portrait.\n"
                            f"{neutrality_block}"
                            "You MUST generate an image. Do not respond with text only."
                            f"{guide_ref_text}"
                        )
                    else:
                        prompt = (
                            f"Generate a 1:1 SQUARE close-up headshot of: {char['name']}. {char.get('description','')}.\n"
                            f"{style_instruction}\n"
                            "Output MUST be SQUARE (1:1). ONLY head/neck, face centered, 3/4 angle. Apply art style.\n"
                            f"{neutrality_block}"
                            "You MUST generate an image. Do not respond with text only."
                            f"{guide_ref_text}"
                        )

                    parts = list(guide_image_parts) + [Part.from_text(text=prompt)]

                    response = await asyncio.to_thread(
                        client.models.generate_content,
                        model="gemini-3.1-flash-image-preview",
                        contents=Content(parts=parts),
                        config=GenerateContentConfig(response_modalities=["Text", "Image"]),
                    )

                    for part in response.candidates[0].content.parts:
                        if part.inline_data and part.inline_data.mime_type.startswith("image/"):
                            headshot_id = f"hs_{uuid.uuid4().hex[:12]}"
                            filename = f"headshot_{headshot_id}.png"
                            await _persist_image(part.inline_data.data, filename)

                            await db.character_headshots.insert_one({
                                "headshot_id": headshot_id,
                                "character_id": char["character_id"],
                                "character_name": char["name"],
                                "script_id": script_id,
                                "style_id": style_id,
                                "style_name": style["name"],
                                "image_url": f"/api/uploads/{filename}",
                                "image_filename": filename,
                                "created_at": datetime.now(timezone.utc).isoformat(),
                            })
                            saved = True
                            await _log_api_usage(operation="headshot_generation", model="gemini-3.1-flash-image", image_count=1, script_id=script_id)
                            break
                    if saved:
                        break
                    else:
                        logger.warning(f"Styled headshot attempt {attempt+1}/{max_retries} for {char['name']}: no image in response")
                        if attempt < max_retries - 1:
                            await asyncio.sleep(2)
                except Exception as e:
                    logger.error(f"Styled headshot attempt {attempt+1}/{max_retries} failed for {char['name']}: {e}")
                    if attempt < max_retries - 1:
                        await asyncio.sleep(2)

            completed += (1 if saved else 0)
            failed += (0 if saved else 1)

            # Update batch progress
            await db.headshot_batches.update_one(
                {"batch_id": batch_id},
                {"$set": {"completed": completed, "failed": failed}}
            )

    # Generate all headshots in parallel
    await asyncio.gather(*[_gen_single_headshot(char) for char in characters])

    # Mark batch as done
    await db.headshot_batches.update_one(
        {"batch_id": batch_id},
        {"$set": {"status": "completed", "completed": completed, "failed": failed}}
    )

@api_router.delete("/media/headshots/{headshot_id}")
async def delete_headshot(headshot_id: str, request: Request):
    await require_role(request, ["admin", "editor"])
    hs = await db.character_headshots.find_one({"headshot_id": headshot_id}, {"_id": 0})
    if not hs:
        raise HTTPException(status_code=404, detail="Headshot not found")
    if hs.get("image_filename"):
        p = UPLOADS_DIR / hs["image_filename"]
        if p.exists():
            p.unlink()
    await db.character_headshots.delete_one({"headshot_id": headshot_id})
    return {"message": "Headshot deleted"}

# ============== SEED DATA (continued) ==============

@api_router.post("/seed")
async def seed_data(request: Request):
    """Seed initial data for categories and statuses"""
    user = await require_role(request, ["admin"])
    
    # Seed categories if empty
    if await db.categories.count_documents({}) == 0:
        default_categories = [
            {"category_id": f"cat_{uuid.uuid4().hex[:12]}", "name": "B-Roll", "bg_color": "#DBEAFE", "text_color": "#1E40AF", "border_color": "#BFDBFE", "created_at": datetime.now(timezone.utc).isoformat()},
            {"category_id": f"cat_{uuid.uuid4().hex[:12]}", "name": "Graphics", "bg_color": "#FAE8FF", "text_color": "#86198F", "border_color": "#F0ABFC", "created_at": datetime.now(timezone.utc).isoformat()},
            {"category_id": f"cat_{uuid.uuid4().hex[:12]}", "name": "SFX", "bg_color": "#FFEDD5", "text_color": "#9A3412", "border_color": "#FED7AA", "created_at": datetime.now(timezone.utc).isoformat()},
            {"category_id": f"cat_{uuid.uuid4().hex[:12]}", "name": "Music", "bg_color": "#DCFCE7", "text_color": "#166534", "border_color": "#BBF7D0", "created_at": datetime.now(timezone.utc).isoformat()},
            {"category_id": f"cat_{uuid.uuid4().hex[:12]}", "name": "Voiceover", "bg_color": "#F3F4F6", "text_color": "#374151", "border_color": "#E5E7EB", "created_at": datetime.now(timezone.utc).isoformat()},
        ]
        await db.categories.insert_many(default_categories)
    
    # Seed statuses if empty
    if await db.statuses.count_documents({}) == 0:
        default_statuses = [
            {"status_id": f"status_{uuid.uuid4().hex[:12]}", "name": "Pending", "order": 0, "created_at": datetime.now(timezone.utc).isoformat()},
            {"status_id": f"status_{uuid.uuid4().hex[:12]}", "name": "In Progress", "order": 1, "created_at": datetime.now(timezone.utc).isoformat()},
            {"status_id": f"status_{uuid.uuid4().hex[:12]}", "name": "Done", "order": 2, "created_at": datetime.now(timezone.utc).isoformat()},
        ]
        await db.statuses.insert_many(default_statuses)
    
    return {"message": "Data seeded successfully"}

# Dynamic uploads endpoint with Google Drive fallback (replaces static mount)
@app.get("/api/uploads/{filename:path}")
async def serve_upload(filename: str):
    """Serve uploaded file from local disk, falling back to Google Drive if not found.
    Images are immutable once generated, so we set aggressive cache headers."""
    local_path = UPLOADS_DIR / filename
    if local_path.exists():
        mime = "image/png" if filename.endswith(".png") else "image/jpeg" if filename.endswith((".jpg", ".jpeg")) else "application/octet-stream"
        return FileResponse(
            str(local_path), media_type=mime,
            headers={"Cache-Control": "public, max-age=604800, immutable"}
        )
    # Fallback: look up in file_drive_map
    mapping = await db.file_drive_map.find_one({"filename": filename}, {"_id": 0})
    if mapping and mapping.get("gdrive_file_id"):
        try:
            file_id = mapping["gdrive_file_id"]
            request_obj = GDRIVE_SERVICE.files().get_media(fileId=file_id, supportsAllDrives=True)
            buffer = io.BytesIO()
            from googleapiclient.http import MediaIoBaseDownload
            downloader = MediaIoBaseDownload(buffer, request_obj)
            done = False
            while not done:
                _, done = downloader.next_chunk()
            buffer.seek(0)
            mime = "image/png" if filename.endswith(".png") else "image/jpeg"
            # Also save locally for faster subsequent loads
            try:
                with open(local_path, "wb") as f:
                    f.write(buffer.getvalue())
                buffer.seek(0)
            except Exception:
                pass
            return StreamingResponse(
                buffer, media_type=mime,
                headers={"Cache-Control": "public, max-age=604800, immutable"}
            )
        except Exception as e:
            logger.error(f"Failed to stream {filename} from Drive: {e}")
    raise HTTPException(status_code=404, detail="File not found")

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_init_gdrive():
    """Initialize Google Drive folder on startup"""
    if GDRIVE_SERVICE:
        await get_or_create_gdrive_folder()

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
