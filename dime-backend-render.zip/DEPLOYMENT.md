# Dime Magic Box — Deployment Guide

## Architecture

```
[Netlify - Frontend]  ←→  [Render/Railway - Backend API]  ←→  [MongoDB Atlas]
                                    ↕
                            [Google Drive Storage]
```

---

## Step 1: Deploy Backend on Render

### 1a. Set up MongoDB Atlas (if you don't have one)
1. Go to [MongoDB Atlas](https://cloud.mongodb.com)
2. Create a free cluster
3. Create a database user and get the connection string
4. Whitelist `0.0.0.0/0` in Network Access (allows Render to connect)
5. Your connection string will look like: `mongodb+srv://user:pass@cluster.mongodb.net/dime_magic_box`

### 1b. Deploy on Render
1. Push the `backend/` folder to a **GitHub repo** (or use Render's manual deploy)
2. Go to [Render Dashboard](https://dashboard.render.com) → **New** → **Web Service**
3. Connect your repo, set **Root Directory** to `backend`
4. Settings:
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `uvicorn server:app --host 0.0.0.0 --port $PORT`
   - **Runtime**: Python 3
5. Add these **Environment Variables**:

| Variable | Value | Notes |
|----------|-------|-------|
| `MONGO_URL` | `mongodb+srv://user:pass@cluster.mongodb.net` | Your MongoDB Atlas connection string |
| `DB_NAME` | `dime_magic_box` | Database name |
| `CORS_ORIGINS` | `https://your-app.netlify.app` | Your Netlify frontend URL (add after deploying frontend) |
| `ANTHROPIC_API_KEY` | `sk-ant-...` | Your Anthropic API key for Claude |
| `GOOGLE_API_KEY` | `AIzaSy...` | Your Google API key for Gemini |
| `GOOGLE_SERVICE_ACCOUNT_JSON_BASE64` | *(base64 string)* | See below |
| `GDRIVE_SHARED_DRIVE_NAME` | `Dime Script Flow` | Your Google Shared Drive name |

### 1c. Encode Google Service Account for Render
Run this locally to get the base64 string:
```bash
base64 -i google-service-account.json | tr -d '\n'
```
Paste the output as the value for `GOOGLE_SERVICE_ACCOUNT_JSON_BASE64`.

### 1d. Note your Render URL
After deploy, Render gives you a URL like: `https://dime-magic-box-api.onrender.com`
You'll need this for the frontend.

---

## Step 2: Deploy Frontend on Netlify

### 2a. Set Environment Variable
Before deploying, you need to set the backend URL:

**Option A — Deploy from GitHub (Recommended):**
1. Push the `frontend/` folder to GitHub
2. Go to [Netlify Dashboard](https://app.netlify.com) → **Add new site** → **Import from Git**
3. Connect your repo, set **Base directory** to `frontend`
4. Build settings should auto-detect from `netlify.toml`:
   - Build command: `yarn build`
   - Publish directory: `build`
5. Go to **Site settings** → **Environment variables** → Add:
   - `REACT_APP_BACKEND_URL` = `https://dime-magic-box-api.onrender.com` *(your Render URL from Step 1d)*
6. Trigger a redeploy

**Option B — Deploy pre-built zip:**
1. Build locally with your backend URL:
   ```bash
   cd frontend
   REACT_APP_BACKEND_URL=https://your-render-url.onrender.com yarn build
   ```
2. Drag & drop the `build/` folder to [Netlify Drop](https://app.netlify.com/drop)

### 2b. Update CORS on Render
After getting your Netlify URL (e.g., `https://dime-magic-box.netlify.app`):
1. Go to Render Dashboard → your service → Environment
2. Update `CORS_ORIGINS` to: `https://dime-magic-box.netlify.app`
3. Render will auto-redeploy

---

## Step 3: Seed Admin User
After both services are running, seed the admin account:
```bash
curl -X POST https://your-render-url.onrender.com/api/seed
```
Then login with: `chandralekha@joindime.in` / `admin123`

---

## Alternative: Deploy Backend on Railway

1. Go to [Railway](https://railway.app) → **New Project** → **Deploy from GitHub**
2. Connect your repo, set root to `backend`
3. Railway auto-detects Python and uses the `Procfile`
4. Add the same environment variables as listed for Render above
5. Railway provides a URL like `https://dime-magic-box-api.up.railway.app`

---

## File Structure for Deployment

```
your-repo/
├── frontend/           ← Deploy to Netlify
│   ├── netlify.toml    ← Netlify config (included)
│   ├── public/
│   │   └── _redirects  ← SPA fallback routing (included)
│   ├── src/
│   └── package.json
│
└── backend/            ← Deploy to Render/Railway
    ├── Procfile        ← Server start command (included)
    ├── render.yaml     ← Render blueprint (included)
    ├── requirements.txt
    ├── server.py
    └── .env            ← NOT deployed, use platform env vars instead
```

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| CORS errors in browser | Update `CORS_ORIGINS` on Render to match your Netlify URL exactly |
| Images not loading | Ensure `GOOGLE_SERVICE_ACCOUNT_JSON_BASE64` is set correctly |
| Login not working | Run the seed endpoint: `POST /api/seed` |
| Backend 503 on Render free tier | Free tier sleeps after 15min inactivity — first request takes ~30s to wake |
| Build fails on Netlify | Ensure `REACT_APP_BACKEND_URL` is set before building |
